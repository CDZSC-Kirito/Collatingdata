#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <queue>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

const int DX[] = { 0, 0, 1, -1 }, DY[] = { 1, -1, 0, 0 };
class VegetableGarden {
	public:
	int dist[52][52][1100];

	vector<int> getMinDistances(vector<string> garden) {
		int n = garden.size(), m = garden[0].size();
		vector<int> rs, cs;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (garden[r][c] != '.')
					rs.push_back(r), cs.push_back(c);
			}
		}
		memset(dist, -1, sizeof dist);
		dist[0][0][0] = 0;
		queue<int> que;
		que.push(0), que.push(0), que.push(0);

		while (!que.empty()) {
			int r = que.front();
			que.pop();
			int c = que.front();
			que.pop();
			int msk = que.front();
			que.pop();
//			cout << r << " " << c << " " << msk << endl;
			for (int d = 0; d < 4; ++d) {
				int nr = DX[d] + r, nc = DY[d] + c;
				if (nr < 0 || nr > n || nc < 0 || nc > m)
					continue;
				int nmsk = msk;
				if (nr == r) {
					int mc = min(c, nc);
					for (int i = 0; i < rs.size(); ++i) {
						if (r <= rs[i] && cs[i] == mc)
							nmsk ^= 1 << i;
					}
				}
				if (dist[nr][nc][nmsk] == -1) {
					dist[nr][nc][nmsk] = dist[r][c][msk] + 1;
					que.push(nr), que.push(nc), que.push(nmsk);
				}
			}
		}

		int cnt = 0;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (garden[r][c] == 'I')
					++cnt;
			}
		}

		vector<int> ans(cnt, INT_MAX);

		for (int msk = 0; msk < (1 << rs.size()); ++msk) {
			int num = 0;
			bool chk = true;
			for (int i = 0; i < rs.size(); ++i) {
				if (msk >> i & 1) {
					++num;
					if (garden[rs[i]][cs[i]] == 'X')
						chk = false;
				}
			}
			if (num == 0)
				continue;
			if (chk) {
				ans[num - 1] = min(ans[num - 1], dist[0][0][msk]);
			}
		}

		return ans;
	}
};


double test0() {
	string t0[] = {"I"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	VegetableGarden * obj = new VegetableGarden();
	clock_t start = clock();
	vector <int> my_answer = obj->getMinDistances(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {4 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"XX", 
 "XI"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	VegetableGarden * obj = new VegetableGarden();
	clock_t start = clock();
	vector <int> my_answer = obj->getMinDistances(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {8 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"III", 
 "IXI",
 "III"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	VegetableGarden * obj = new VegetableGarden();
	clock_t start = clock();
	vector <int> my_answer = obj->getMinDistances(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {4, 6, 8, 10, 12, 14, 16, 18 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"X.I", 
 ".I.", 
 "I.."};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	VegetableGarden * obj = new VegetableGarden();
	clock_t start = clock();
	vector <int> my_answer = obj->getMinDistances(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {8, 10, 14 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"IIXIIXIXII"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	VegetableGarden * obj = new VegetableGarden();
	clock_t start = clock();
	vector <int> my_answer = obj->getMinDistances(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {4, 6, 12, 14, 20, 26, 28 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
