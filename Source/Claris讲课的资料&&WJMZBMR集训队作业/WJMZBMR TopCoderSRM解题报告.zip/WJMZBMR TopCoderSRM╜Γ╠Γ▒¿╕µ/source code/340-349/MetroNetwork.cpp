#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class MetroNetwork {
public:
	double minimizeTime(int sta, int tar, vector<string> _ls, vector<string> _ts, vector<int> _prob,
			int ct, int dy) {
		int nL = _ls.size();
		vector<int> ls[nL], ts[nL];
		int nV = 0;
		for (int i = 0; i < nL; ++i) {
			{
				istringstream sin(_ls[i]);
				int x;
				while (sin >> x) {
					ls[i].push_back(x);
					nV = max(nV, x + 1);
				}
			}
			{
				istringstream sin(_ts[i]);
				int x;
				while (sin >> x) {
					ts[i].push_back(x);
				}
			}
		}

		vector<int> myL[nV];
		for (int i = 0; i < nL; ++i) {
			for (vector<int>::iterator e = ls[i].begin(); e != ls[i].end(); ++e) {
				myL[*e].push_back(i);
			}
		}

		double pb[nL];
		for (int i = 0; i < nL; ++i) {
			pb[i] = _prob[i] / 100.0;
		}

		int nS = 1;
		for (int i = 0; i < nL; ++i) {
			nS *= 3;
		}
		int p3[nL];
		p3[0] = 1;
		for (int i = 1; i < nL; ++i) {
			p3[i] = p3[i - 1] * 3;
		}

		const double INF = 1e9;
		vector<vector<double> > dp(nS, vector<double>(nV, INF));
		//0:don't delay 1:delay 2:don't know
		for (int s = 0; s < nS; ++s) {
			int cur[nL];
			for (int i = 0; i < nL; ++i) {
				cur[i] = s / p3[i] % 3;
			}

			int ds[nV][nV];
			for (int i = 0; i < nV; ++i) {
				for (int j = 0; j < nV; ++j) {
					if (i == j)
						ds[i][j] = 0;
					else
						ds[i][j] = INF;
				}
			}

			for (int i = 0; i < nL; ++i) {
				if (cur[i] != 2) {
					int ad = cur[i] == 0 ? 0 : dy;
					for (int j = 0; j < ls[i].size(); ++j) {
						int c = 0;
						for (int nj = j + 1; nj < ls[i].size(); ++nj) {
							c += ts[i][nj - 1] + ad;
							int a = ls[i][j], b = ls[i][nj];
							ds[a][b] = min(ds[a][b], ct * 2 + c);
							ds[b][a] = ds[a][b];
						}
					}
				}
			}

			for (int i = 0; i < nV; ++i) {
				double p = 0;
				if (i != tar) {
					int newK = -1;
					for (vector<int>::iterator e = myL[i].begin(); e != myL[i].end(); ++e) {
						if (cur[*e] == 2)
							newK = *e;
					}
					if (newK == -1)
						continue;
					p = pb[newK] * dp[s - p3[newK]][i] + (1 - pb[newK]) * dp[s - 2 * p3[newK]][i];
				}
				dp[s][i] = min(dp[s][i], p);
			}

			bool mark[nV];
			fill(mark, mark + nV, false);
			for (int i = 0; i < nV; ++i) {
				double mi = INF;
				int mid = -1;
				for (int j = 0; j < nV; ++j) {
					if (!mark[j] && dp[s][j] < mi) {
						mi = dp[s][j];
						mid = j;
					}
				}
				if (mid < 0)
					break;
				for (int j = 0; j < nV; ++j) {
					dp[s][j] = min(dp[s][j], dp[s][mid] + ds[mid][j]);
				}
				mark[mid] = true;
			}
		}

		double ret = dp[nS - 1][sta];
		if (ret > 1e8)
			return -1;
		else
			return ret;
	}
};

//
double test0() {
	int p0 = 0;
	int p1 = 7;
	string t2[] = {"0 1 2 3 4 5 6 7"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"2 2 2 2 2 2 2"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int t4[] = {50};
	vector <int> p4(t4, t4+sizeof(t4)/sizeof(int));
	int p5 = 5;
	int p6 = 5;
	MetroNetwork * obj = new MetroNetwork();
	clock_t start = clock();
	double my_answer = obj->minimizeTime(p0, p1, p2, p3, p4, p5, p6);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p7 = 41.5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p7 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p7 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 0;
	int p1 = 3;
	string t2[] = {"0 1","0 2","1 3","2 3"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"5","5","5","5"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int t4[] = {0,0,50,50};
	vector <int> p4(t4, t4+sizeof(t4)/sizeof(int));
	int p5 = 5;
	int p6 = 20;
	MetroNetwork * obj = new MetroNetwork();
	clock_t start = clock();
	double my_answer = obj->minimizeTime(p0, p1, p2, p3, p4, p5, p6);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p7 = 40.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p7 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p7 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 0;
	int p1 = 3;
	string t2[] = {"0 1","0 2","0 1 3","2 3"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"5","5","100 5","5"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int t4[] = {0,0,50,50};
	vector <int> p4(t4, t4+sizeof(t4)/sizeof(int));
	int p5 = 5;
	int p6 = 20;
	MetroNetwork * obj = new MetroNetwork();
	clock_t start = clock();
	double my_answer = obj->minimizeTime(p0, p1, p2, p3, p4, p5, p6);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p7 = 35.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p7 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p7 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 0;
	int p1 = 4;
	string t2[] = {"0 1 2 3","1 3 4","2 4"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"10 10 20","100 10","80"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int t4[] = {0,50,0};
	vector <int> p4(t4, t4+sizeof(t4)/sizeof(int));
	int p5 = 5;
	int p6 = 100;
	MetroNetwork * obj = new MetroNetwork();
	clock_t start = clock();
	double my_answer = obj->minimizeTime(p0, p1, p2, p3, p4, p5, p6);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p7 = 105.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p7 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p7 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int p0 = 12;
	int p1 = 9;
	string t2[] = {"0 30 1 2 3 4 31 5 6 7",
"38 6 8 32 9 33 10 34 11 0 12 13 14 15 16 36 5 38",
"17 39 18 19 5 8 9 20 21",
"17 39 22 16 23 24 3 25 20 21",
"28 9 20 25 2 27 14 17",
"12 13 27 26 24 4 9 28",
"29 10 1 27 15 22 19",
"11 10 2 26 23 16 22 18"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"3 3 2 3 2 3 2 2 5",
"2 1 3 4 3 2 4 2 4 5 1 4 4 2 4 5 4",
"2 4 4 2 2 6 2 4",
"2 8 2 1 1 2 3 1 6",
"6 1 2 2 2 2 6",
"1 7 1 2 2 4 8",
"7 2 3 2 2 4",
"4 4 2 2 1 2 9"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int t4[] = {20,5,15,50,45,5,10,5};
	vector <int> p4(t4, t4+sizeof(t4)/sizeof(int));
	int p5 = 3;
	int p6 = 10;
	MetroNetwork * obj = new MetroNetwork();
	clock_t start = clock();
	double my_answer = obj->minimizeTime(p0, p1, p2, p3, p4, p5, p6);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p7 = 23.228506624999994;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p7 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p7 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	int p0 = 0;
	int p1 = 3;
	string t2[] = {"0 1","2 3"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"2","2"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int t4[] = {50,50};
	vector <int> p4(t4, t4+sizeof(t4)/sizeof(int));
	int p5 = 5;
	int p6 = 5;
	MetroNetwork * obj = new MetroNetwork();
	clock_t start = clock();
	double my_answer = obj->minimizeTime(p0, p1, p2, p3, p4, p5, p6);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p7 = -1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p7 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p7 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test6() {
	int p0 = 31;
	int p1 = 8;
	string t2[] = {"35 38 1 3 4 7 9 10 12 14 16 18 19 20 21 24 25 26"
,"7 10 11 13 15 16 19 22 23 25 26 27 30 33 35 38 1"
,"35 38 1 3 5 6 9 11 13 16 17 19 22 25 26 29 30 32"
,"24 26 28 29 32 34 37 39 1 4 6 8 11 13 16 17 18 19"
,"13 15 17 20 22 25 26 29 30 32 35 37 0 2 3 6 7 8"
,"20 22 24 26 29 31 32 33 36 38 0 3 6 8 9 12 13 14"
,"12 15 16 18 19 21 22 24 25 26 28 30 31 32 33 35"
,"32 34 37 38 39 0 2 4 7 9 12 15 17 20 22 23 24 27"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"2 4 9 9 4 4 2 9 7 5 8 3 3 6 7 4 1"
,"1 6 6 8 8 10 7 1 8 10 9 8 9 3 3 2"
,"2 2 7 9 9 1 9 7 9 6 4 4 1 1 10 2 3"
,"10 10 6 5 1 9 9 6 10 5 4 7 5 3 1 2 2"
,"5 1 3 9 2 5 5 6 5 6 3 5 8 8 5 1 6"
,"4 10 4 1 7 1 9 3 5 3 6 9 2 10 3 9 7"
,"9 3 6 6 6 3 5 6 10 10 2 2 5 2 6"
,"1 7 3 6 1 10 2 1 7 4 7 9 7 10 7 3 2"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int t4[] = {81,5,54,32,6,12,80,38};
	vector <int> p4(t4, t4+sizeof(t4)/sizeof(int));
	int p5 = 4;
	int p6 = 88;
	MetroNetwork * obj = new MetroNetwork();
	clock_t start = clock();
	double my_answer = obj->minimizeTime(p0, p1, p2, p3, p4, p5, p6);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p7 = 56.38865447903488;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p7 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p7 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	time = test6();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}
