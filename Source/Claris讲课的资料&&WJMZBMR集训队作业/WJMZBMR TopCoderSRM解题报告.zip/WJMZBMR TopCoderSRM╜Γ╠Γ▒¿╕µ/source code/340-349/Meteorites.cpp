#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
const double PI = acos(-1.0);

const double EPS = 1e-6;
inline int sign(double a) {
	return a < -EPS ? -1 : a > EPS;
}

struct Point {
	double x, y;
	Point() {
	}
	Point(double _x, double _y) :
			x(_x), y(_y) {
	}
	Point operator+(const Point&p) const {
		return Point(x + p.x, y + p.y);
	}
	Point operator-(const Point&p) const {
		return Point(x - p.x, y - p.y);
	}
	Point operator*(double d) const {
		return Point(x * d, y * d);
	}
	Point operator/(double d) const {
		return Point(x / d, y / d);
	}
	bool operator<(const Point&p) const {
		int c = sign(x - p.x);
		if (c)
			return c == -1;
		return sign(y - p.y) == -1;
	}
	double dot(const Point&p) const {
		return x * p.x + y * p.y;
	}
	double det(const Point&p) const {
		return x * p.y - y * p.x;
	}
	double alpha() const {
		return atan2(y, x);
	}
	double distTo(const Point&p) const {
		double dx = x - p.x, dy = y - p.y;
		return hypot(dx, dy);
	}
	double alphaTo(const Point&p) const {
		double dx = x - p.x, dy = y - p.y;
		return atan2(dy, dx);
	}
	void read() {
		scanf("%lf%lf", &x, &y);
	}
	double abs() {
		return hypot(x, y);
	}
	double abs2() {
		return x * x + y * y;
	}
	void write() {
		cout << "(" << x << "," << y << ")" << endl;
	}
};

#define cross(p1,p2,p3) ((p2.x-p1.x)*(p3.y-p1.y)-(p3.x-p1.x)*(p2.y-p1.y))

#define crossOp(p1,p2,p3) sign(cross(p1,p2,p3))

Point isSS(Point p1, Point p2, Point q1, Point q2) {
	double a1 = cross(q1,q2,p1), a2 = -cross(q1,q2,p2);
	return (p1 * a2 + p2 * a1) / (a1 + a2);
}

void normal(double&x) {
	for (; x > PI * 2; x -= PI * 2)
		;
	for (; x < 0; x += PI * 2)
		;
}

class Meteorites {
public:
	double perimeter(vector<int> x, vector<int> y, vector<int> r) {
		int n = x.size();
		vector<Point> ps;
		for (int i = 0; i < n; ++i) {
			ps.push_back(Point(x[i], y[i]));
		}

		double ans = 0;
		for (int i = 0; i < n; ++i) {
			bool covered = false;

			vector<double> left, right;
			for (int j = 0; j < n; ++j) {
				if (j != i) {
					if (ps[i].distTo(ps[j]) + r[i] <= r[j] + EPS) {
						covered = true;
						break;
					}
					if (ps[j].distTo(ps[i]) + r[j] <= r[i] + EPS)
						continue;
					if (ps[i].distTo(ps[j]) >= r[i] + r[j] - EPS)
						continue;
					double d = ps[i].distTo(ps[j]);
					double c = ps[j].alphaTo(ps[i]);
					double b = acos(
							(1.0 * r[i] * r[i] + d * d - 1.0 * r[j] * r[j]) / (2 * r[i] * d));
					left.push_back(c - b);
					right.push_back(c + b);
				}
			}
			if (covered)
				continue;

			vector<double> all;
			all.insert(all.end(), left.begin(), left.end());
			all.insert(all.end(), right.begin(), right.end());
			for (vector<double>::iterator e = all.begin(); e != all.end(); ++e) {
				normal(*e);
			}
			if (all.empty())
				all.push_back(0);
			sort(all.begin(), all.end());
			all.push_back(all[0] + PI * 2);

			for (int j = 0; j + 1 < all.size(); ++j) {
				double L = all[j], R = all[j + 1];
				double M = (L + R) / 2;
				bool bad = false;
				for (int k = 0; k < left.size(); ++k) {
					double x = M;
					while (x < left[k])
						x += PI * 2;
					while (x > right[k])
						x -= PI * 2;
					if (x > left[k] && x < right[k]) {
						bad = true;
						break;
					}
				}
				if (!bad)
					ans += (R - L) * r[i];
			}
		}
		return ans;
	}
};


double test0() {
	int t0[] = {0,10};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,0};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {6,7};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	Meteorites * obj = new Meteorites();
	clock_t start = clock();
	double my_answer = obj->perimeter(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 63.72326520248748;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {-10,-10,-10,0,0,0,10,10,10};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {-10,0,10,-10,0,10,-10,0,10};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {7,7,7,7,7,7,7,7,7};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	Meteorites * obj = new Meteorites();
	clock_t start = clock();
	double my_answer = obj->perimeter(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 135.3757009200326;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {-100,100,100,-100};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {-100,-100,100,100};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {110,110,110,110};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	Meteorites * obj = new Meteorites();
	clock_t start = clock();
	double my_answer = obj->perimeter(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 2008.3301227325105;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {0,0,0,0};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,0,0,0};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1,2,3,100000};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	Meteorites * obj = new Meteorites();
	clock_t start = clock();
	double my_answer = obj->perimeter(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 628318.5307179586;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
