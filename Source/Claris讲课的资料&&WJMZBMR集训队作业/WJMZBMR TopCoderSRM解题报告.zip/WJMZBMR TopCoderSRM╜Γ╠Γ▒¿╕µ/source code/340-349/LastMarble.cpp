#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class LastMarble {
	public:
	double memo[200][200][4];
	double comb(int n, int m) {
		if (m > n)
			return 0;
		double ret = 1;
		for (int i = 0; i < m; ++i) {
			ret *= n - i;
			ret /= i + 1;
		}
		return ret;
	}
	double prob(int R, int B, int r, int b) {
		return comb(R, r) * comb(B, b) / comb(R + B, r + b);
	}

	double calc(int r, int b, int st/*0:me,1:op,2:none*/, int removed) {
		double&ret = memo[r][b][st];
		if (ret > -0.5)
			return ret;
		if (r + b == removed) {
			return ret = (st == 0 ? 0 : 1);
		}
		ret = 0;
		for (int take = 1; take <= 3 && r + b - take >= removed; ++take) {
			double tmp = 0;
			for (int rr = 0; rr <= take; ++rr) {
				int bb = take - rr;
				if (rr <= r && bb <= b) {
					double p = prob(r, b, rr, bb);
					int nst;
					if (rr > 0) {
						nst = 1;
					} else {
						if (st == 2)
							nst = 2;
						else
							nst = 1 + st & 1;
					}
					tmp += (1 - calc(r - rr, b - bb, nst, removed)) * p;
				}
			}
			ret = max(ret, tmp);
		}
		return ret;
	}
	double winningChance(int red, int blue, int removed) {
		memset(memo, -1, sizeof memo);
		return calc(red, blue, 2, removed);
	}
};


double test0() {
	int p0 = 1;
	int p1 = 1;
	int p2 = 0;
	LastMarble * obj = new LastMarble();
	clock_t start = clock();
	double my_answer = obj->winningChance(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 1;
	int p1 = 2;
	int p2 = 0;
	LastMarble * obj = new LastMarble();
	clock_t start = clock();
	double my_answer = obj->winningChance(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.3333333333333333;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 2;
	int p1 = 1;
	int p2 = 0;
	LastMarble * obj = new LastMarble();
	clock_t start = clock();
	double my_answer = obj->winningChance(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.6666666666666666;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 2;
	int p1 = 2;
	int p2 = 1;
	LastMarble * obj = new LastMarble();
	clock_t start = clock();
	double my_answer = obj->winningChance(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
