#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

typedef long long int64;
const int64 LIMIT = INT_MAX;

typedef vector<int64> vec;
typedef vector<vec> mat;

mat zero(int n) {
	return mat(n, vec(n, 0));
}

mat unit(int n) {
	mat a = zero(n);
	for (int i = 0; i < n; ++i) {
		a[i][i] = 1;
	}
	return a;
}

mat operator*(mat a, mat b) {
	int n = a.size();
	mat c = zero(n);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			for (int k = 0; k < n; ++k) {
				c[i][j] += a[i][k] * b[k][j];
				c[i][j] = min(c[i][j], LIMIT);
			}
		}
	}
	return c;
}

mat operator+(mat a, mat b) {
	int n = a.size();
	mat c = zero(n);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			c[i][j] = a[i][j] + b[i][j];
			c[i][j] = min(c[i][j], LIMIT);
		}
	}
	return c;
}

vec operator*(vec a, mat m) {
	int n = a.size();
	vec c(n, 0);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			c[j] += a[i] * m[i][j];
			c[j] = min(c[j], LIMIT);
		}
	}
	return c;
}

mat matPow(mat a, int e) {
	if (!e)
		return unit(a.size());
	return (e & 1) ? matPow(a, e - 1) * a : matPow(a * a, e >> 1);
}

mat matPowSum(mat a, mat&ae, int e) {
	//a^0+a^1+a^2+..a^e
	if (!e) {
		ae = unit(a.size());
		return ae;
	}
	if (e % 2 == 0) {
		mat ret = matPowSum(a, ae, e - 1);
		ae = ae * a;
		return ret + ae;
	} else {
		mat tmp = matPowSum(a * a, ae, e >> 1);
		ae = ae * a;
		mat ret = tmp + a * (tmp);
		return ret;
	}
}

mat matPowSum(mat a, int e) {
	mat ae;
	return matPowSum(a, ae, e);
}

class ValidPlates {
public:

	bool can[10][10];

	int64 eval(int L) { //length <= L
		vec init(10);
		for (int i = 1; i < 10; ++i) {
			init[i] = 1;
		}

		mat m = zero(10);
		for (int i = 0; i < 10; ++i) {
			for (int j = 0; j < 10; ++j) {
				m[i][j] = can[i][j];
			}
		}

		vec ret = init * matPowSum(m, L - 1);
		return accumulate(ret.begin(), ret.end(), 0LL);
	}

	int64 eval(int s, int L) {
		vec init(10);
		init[s] = 1;

		mat m = zero(10);
		for (int i = 0; i < 10; ++i) {
			for (int j = 0; j < 10; ++j) {
				m[i][j] = can[i][j];
			}
		}

		vec ret = init * matPow(m, L);
		return accumulate(ret.begin(), ret.end(), 0LL);
	}

	string getPlate(vector<string> profane, int k) {
		if (k < 10) {
			string ret = "";
			ret += char('0' + k);
			return ret;
		}

		for (int i = 0; i < 10; ++i) {
			for (int j = 0; j < 10; ++j) {
				can[i][j] = true;
			}
		}
		for (vector<string>::iterator e = profane.begin(); e != profane.end(); ++e) {
			istringstream sin(*e);
			string s;
			while (sin >> s) {
				can[s[0] - '0'][s[1] - '0'] = false;
			}
		}

		int64 l = 1, r = k + 3;
		cout << eval(r) << endl;
		if (eval(r) < k)
			return "";
		while (l + 1 < r) {
			int64 m = (l + r) / 2;
			if (eval(m) >= k)
				r = m;
			else
				l = m;
		}

		int w[100];
		k -= eval(r - 1);
		for (int i = 1; i < 10; ++i) {
			if (eval(i, r - 1) >= k) {
				w[0] = i;
				break;
			} else {
				k -= eval(i, r - 1);
			}
		}
		for (int i = 1; i < r && i < 50; ++i) {
			for (int d = 0; d < 10; ++d) {
				if (can[w[i - 1]][d]) {
					if (eval(d, r - 1 - i) >= k) {
						w[i] = d;
						break;
					} else {
						k -= eval(d, r - 1 - i);
					}
				}
			}
		}
		if (r <= 50) {
			string ans = "";
			for (int i = 0; i < r; ++i) {
				ans += char(w[i] + '0');
			}
			return ans;
		}
		string ans = "";
		for (int i = 0; i < 47; ++i) {
			ans += char(w[i] + '0');
		}
		return ans + "...";
	}
};

//
double test0() {
	vector <string> p0;
	int p1 = 1000;
	ValidPlates * obj = new ValidPlates();
	clock_t start = clock();
	string my_answer = obj->getPlate(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "1000";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"10"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 10;
	ValidPlates * obj = new ValidPlates();
	clock_t start = clock();
	string my_answer = obj->getPlate(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "11";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"10"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 2000000000;
	ValidPlates * obj = new ValidPlates();
	clock_t start = clock();
	string my_answer = obj->getPlate(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "2277659869";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"00 01 02 03 04 05 06 07 08 09 11 12 13 14 15 16 17",
 "18 19 22 23 24 25 26 27 28 29 33 34 35 36 37 38 39",
 "44 45 46 47 48 49 55 56 57 58 59 66 67 68 69 77 78",
 "79 88 89 99 99 99 99 99"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 1023;
	ValidPlates * obj = new ValidPlates();
	clock_t start = clock();
	string my_answer = obj->getPlate(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"00 01 02 03 04 05 07 08 09",
 "10 11 12 13 14 15 17 18 19",
 "20 21 22 24 25 26 27 28 29",
 "30 31 32 33 34 36 37 38 39",
 "41 43 45 46 48",
 "52 53 54 55 56 58 59",
 "60 61 63 64 66 67 68 69",
 "70 72 73 74 75 76 77 78",
 "80 81 82 83 84 86 87 88 89",
 "90 91 92 94 95 96 97 98"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 2000000000;
	ValidPlates * obj = new ValidPlates();
	clock_t start = clock();
	string my_answer = obj->getPlate(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "79999999351623516571657999935799993";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {"00 01 02 03 04 05 06 07 08 09",
 "10 11 12 13 14 16 17 19",
 "20 21 22 23 24 25 26 27 28 29",
 "30 31 32 33 34 35 36 38 39",
 "41 42 43 44 45 46 49",
 "50 52 53 54 55 57 58 59",
 "60 61 62 63 64 65 66 67 68 69",
 "70 72 73 74 75 76 77 78 79",
 "80 81 82 83 84 85 86 87 88 89",
 "90 91 92 93 94 95 98 99"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 2000000000;
	ValidPlates * obj = new ValidPlates();
	clock_t start = clock();
	string my_answer = obj->getPlate(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "37151515151515151515151515151515151515151515151...";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
