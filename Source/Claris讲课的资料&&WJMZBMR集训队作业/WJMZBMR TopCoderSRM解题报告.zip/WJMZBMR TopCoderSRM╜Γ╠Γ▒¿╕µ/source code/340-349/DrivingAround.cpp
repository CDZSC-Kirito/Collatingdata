/*
 * DrivingAround.cpp
 *
 *  Created on: 2011-10-30
 *      Author: mac
 */
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <climits>
#include <numeric>
#include <vector>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
#define REP(i,n) for(int i=0;i<n;++i)
using namespace std;
typedef long long int64;

const int MOD = 1000003;

typedef vector<int> vec;
typedef vector<vec> mat;

mat zero(int n) {
	return mat(n, vec(n, 0));
}

mat unit(int n) {
	mat a = zero(n);
	for (int i = 0; i < n; ++i) {
		a[i][i] = 1;
	}
	return a;
}

mat operator*(mat a, mat b) {
	int n = a.size();
	mat c = zero(n);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			int64 t = 0;
			for (int k = 0; k < n; ++k) {
				t += 1LL * a[i][k] * b[k][j];
			}
			c[i][j] = t % MOD;
		}
	}
	return c;
}

mat matPow(mat a, int e) {
	if (!e)
		return unit(a.size());
	return (e & 1) ? matPow(a, e - 1) * a : matPow(a * a, e >> 1);
}

struct DrivingAround {
	static const int MAX_STAY = 5;
	int numberOfWays(vector<string> adj, int start, int finish, int time) {
		int id[10][MAX_STAY];
		int nId = 0, nV = adj.size();
		for (int i = 0; i < nV; ++i) {
			for (int j = 0; j < MAX_STAY; ++j) {
				id[i][j] = nId++;
			}
		}

		mat m = zero(nId);
		for (int i = 0; i < nV; ++i) {
			for (int j = 0; j < MAX_STAY; ++j) {
				if (j > 0) {
					m[id[i][j]][id[i][j - 1]]++;
				} else {
					for (int k = 0; k < nV; ++k) {
						if (adj[i][k] != '.') {
							int d = adj[i][k] - '0';
							m[id[i][j]][id[k][d - 1]]++;
						}
					}
				}
			}
		}

		mat ret = matPow(m, time);
		return ret[id[start][0]][id[finish][0]];
	}
};


double test0() {
	string t0[] = {".12",
 "2.1",
 "12."};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 0;
	int p2 = 2;
	int p3 = 5;
	DrivingAround * obj = new DrivingAround();
	clock_t start = clock();
	int my_answer = obj->numberOfWays(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 8;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"....52....",
 "..5.......",
 "..........",
 ".......1..",
 "......42.2",
 "5...4.....",
 ".5...4...1",
 "......5...",
 ".3244.....",
 ".........."};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 2;
	int p2 = 2;
	int p3 = 10;
	DrivingAround * obj = new DrivingAround();
	clock_t start = clock();
	int my_answer = obj->numberOfWays(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"...14....1",
 "......13..",
 ".2...4....",
 "....52.5..",
 "1.3..4....",
 ".3....35.5",
 "4......1.1",
 "..4.4.1.54",
 "....4.11.5",
 "31144.2.4."};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 7;
	int p2 = 2;
	int p3 = 100;
	DrivingAround * obj = new DrivingAround();
	clock_t start = clock();
	int my_answer = obj->numberOfWays(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 316984;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
