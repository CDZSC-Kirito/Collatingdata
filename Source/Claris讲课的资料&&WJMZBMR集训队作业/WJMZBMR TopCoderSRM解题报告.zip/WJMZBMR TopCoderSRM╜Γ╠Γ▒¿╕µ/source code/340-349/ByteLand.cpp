#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

struct Edge {
	int t, c;
	Edge(int _t, int _c) :
			t(_t), c(_c) {
	}
};

class ByteLand {
	public:
	vector<Edge> E[50];
	int n;

	bool isCastle[50];
	bool used[50];
	int maxd;

	vector<int> road, distance;
	int dist[50][50];

	void dfs(int u, int fa, int d[], int di) {
		if (d[u] != INT_MAX
			)
			return;
		d[u] = di;
		for (vector<Edge>::iterator e = E[u].begin(); e != E[u].end(); ++e) {
			if (e->t != fa) {
				dfs(e->t, u, d, di + e->c);
			}
		}
	}

	int dp[50][50], best[50];
	void rec(int u, int fa) {
		used[u] = true;
		for (int i = 0; i < n; ++i) {
			if (dist[u][i] <= maxd)
				dp[u][i] = 0;
			else
				dp[u][i] = INT_MAX / 2;
		}
		for (vector<Edge>::iterator e = E[u].begin(); e != E[u].end(); ++e) {
			if (e->t != fa) {
				rec(e->t, u);
				for (int i = 0; i < n; ++i) {
					dp[u][i] += min(dp[e->t][i], best[e->t]);
				}
			}
		}
		best[u] = INT_MAX;
		for (int i = 0; i < n; ++i) {
			int by = dp[u][i] + (isCastle[i] ? 0 : 1);
			best[u] = min(best[u], by);
		}
	}

	bool check(int maxd, int k) {
		this->maxd = maxd;
		memset(used, false, sizeof used);
		for (int i = 0; i < n; ++i) {
			if (!used[i]) {
				cout << i << endl;
				int t = i;
				//find the cycle
				bool mark[50] = { };
				while (!mark[t]) {
					mark[t] = true;
					t = road[t];
				}
				vector<int> cyc;
				memset(mark, false, sizeof mark);
				while (!mark[t]) {
					cyc.push_back(t);
					mark[t] = true;
					t = road[t];
				}
				cout << "HI" << endl;

				int ret = INT_MAX;
				for (int j = 0; j < cyc.size(); ++j) {
					for (int k = 0; k < n; ++k) {
						E[k].clear();
					}
					for (int k = 0; k < n; ++k) {
						if (k != cyc[j]) {
							int t = road[k], c = distance[k];
							E[k].push_back(Edge(t, c));
							E[t].push_back(Edge(k, c));
						}
					}
					fill(dist[0], dist[n], INT_MAX);
					for (int k = 0; k < n; ++k) {
						dfs(k, -1, dist[k], 0);
					}
					cout << "HAHA" << endl;
					rec(cyc[0], -1);
					ret = min(ret, best[cyc[0]]);
				}

				cout << maxd << " " << ret << endl;

				k -= ret;
				if (k < 0)
					return false;
			}
		}
		return true;
	}

	int buildCastles(vector<int> road, vector<int> distance, vector<int> castle, int k) {
		n = road.size();
		this->road = road;
		this->distance = distance;
		//		for (int i = 0; i < n; ++i) {
//		}
		memset(isCastle, false, sizeof isCastle);
		for (vector<int>::iterator e = castle.begin(); e != castle.end(); ++e) {
			isCastle[*e] = true;
		}

		int l = -1, r = INT_MAX / 4;
		while (l + 1 < r) {
			int m = l + r >> 1;
			if (check(m, k))
				r = m;
			else
				l = m;
		}
		return r;
	}
};
