#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <queue>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class NormalizingTrees {
public:
	vector<vector<int> > adj;
	vector<vector<int> > ord;

	int n;

	vector<int> solve(int t, int par) {
		vector<pair<vector<int>, int> > chs;
		for (vector<int>::iterator e = adj[t].begin(); e != adj[t].end(); ++e) {
			if (*e != par)
				chs.push_back(make_pair(solve(*e, t), *e));
		}
		if (!chs.empty())
			sort(chs.begin(), chs.end());
		ord[t].clear();
		for (int i = 0; i < chs.size(); ++i) {
			ord[t].push_back(chs[i].second);
		}

		vector<int> mark(n, -1);
		queue<int> que;

		vector<int> ret;
		mark[t] = 0;
		que.push(t);
		ret.push_back(-1);

		int cur = 1;

		while (!que.empty()) {
			int u = que.front();
			que.pop();

			for (vector<int>::iterator e = ord[u].begin(); e != ord[u].end(); ++e) {
				que.push(*e);
				mark[*e] = cur++;
				ret.push_back(mark[u]);
			}
		}

		ret.push_back(INT_MAX);
		return ret;
	}

	vector<int> normalize(vector<int> tree) {
		n = tree.size();
		adj.resize(n);
		ord.resize(n);
		for (int i = 0; i < n; ++i) {
			int p = tree[i];
			if (p != -1)
				adj[p].push_back(i), adj[i].push_back(p);
		}

		vector<int> ans(1, INT_MAX);
		for (int i = 0; i < n; ++i) {
			vector<int> t = solve(i, -1);
			t.pop_back();
			ans = min(ans, t);
		}

		return ans;
	}
};


double test0() {
	int t0[] = {2,0,-1,4,2,4};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NormalizingTrees * obj = new NormalizingTrees();
	clock_t start = clock();
	vector <int> my_answer = obj->normalize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {-1, 0, 0, 0, 1, 4 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {-1,0,1,2,3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NormalizingTrees * obj = new NormalizingTrees();
	clock_t start = clock();
	vector <int> my_answer = obj->normalize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {-1, 0, 0, 1, 2 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {3,3,3,4,-1,3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NormalizingTrees * obj = new NormalizingTrees();
	clock_t start = clock();
	vector <int> my_answer = obj->normalize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {-1, 0, 0, 0, 0, 0 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {10,9,6,10,6,9,7,-1,9,7,7,10,6};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NormalizingTrees * obj = new NormalizingTrees();
	clock_t start = clock();
	vector <int> my_answer = obj->normalize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {-1, 0, 0, 0, 0, 1, 1, 5, 5, 5, 6, 6, 6 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int t0[] = {-1, 0, 0, 0, 0, 1, 1, 5, 5, 5, 6, 6, 6};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NormalizingTrees * obj = new NormalizingTrees();
	clock_t start = clock();
	vector <int> my_answer = obj->normalize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {-1, 0, 0, 0, 0, 1, 1, 5, 5, 5, 6, 6, 6 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
