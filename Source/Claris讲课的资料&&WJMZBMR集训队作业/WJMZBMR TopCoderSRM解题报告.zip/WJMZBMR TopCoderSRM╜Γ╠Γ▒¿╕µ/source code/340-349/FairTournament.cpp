#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

const int MOD = 100000000;
const int L = 30;
struct BigInt {
	int a[L];
	BigInt() {
		memset(a, 0, sizeof a);
	}
	void set(int x) {
		a[0] = x;
	}
	void operator+=(const BigInt&o) {
		int c = 0;
		for (int i = 0; i < L; ++i) {
			c += a[i] + o.a[i];
			a[i] = c % MOD;
			c /= MOD;
		}
	}
	string toString() {
		static char buf[100000];
		string ret = "";
		for (int i = L - 1; i >= 0; --i) {
			if (a[i] > 0 || i == 0) {
				sprintf(buf, "%d", a[i]);
				ret += string(buf);
				for (int j = i - 1; j >= 0; --j) {
					sprintf(buf, "%08d", a[j]);
					ret += string(buf);
				}
				return ret;
			}
		}
	}
};

class FairTournament {
public:
	string countPermutations(int n, int k) {
		int total = 1 << (2 * k);
		BigInt* am = new BigInt[total];
		am[0].set(1);
		for (int i = 0; i < n; ++i) {
			BigInt*nam = new BigInt[total];
			for (int j = 0; j < total; ++j) {
				for (int w = -k; w <= k; ++w) {
					if (i + w >= 0 && i + w < n && (~j >> (w + k) & 1)) {
						int nj = j | (1 << (w + k));
						nam[nj >> 1] += am[j];
					}
				}
			}
			delete[] am;
			am = nam;
		}
		BigInt ans;
		for (int i = 0; i < total; ++i) {
			ans += am[i];
		}
		return ans.toString();
	}
};

//
double test0() {
	int p0 = 3;
	int p1 = 1;
	FairTournament * obj = new FairTournament();
	clock_t start = clock();
	string my_answer = obj->countPermutations(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "3";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 3;
	int p1 = 2;
	FairTournament * obj = new FairTournament();
	clock_t start = clock();
	string my_answer = obj->countPermutations(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "6";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 10;
	int p1 = 3;
	FairTournament * obj = new FairTournament();
	clock_t start = clock();
	string my_answer = obj->countPermutations(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "19708";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 100;
	int p1 = 1;
	FairTournament * obj = new FairTournament();
	clock_t start = clock();
	string my_answer = obj->countPermutations(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "573147844013817084101";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
