#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

int mat[12][12], n, m;

typedef long long int64;
const int NONE = 15;

struct State {
	int64 code;
	State() :
			code(0) {
	}
	int get(int i) {
		return code >> (i * 4) & 15;
	}
	void set(int i, int x) {
		code += (1LL * (x - get(i))) << (i * 4);
	}
	void norm() {
		static int mark[20];
		memset(mark, -1, sizeof mark);
		int cur = 0;
		for (int i = 0; i < m; ++i) {
			if (get(i) != NONE) {
				int u = get(i);
				if (mark[u] == -1)
					mark[u] = cur++;
				set(i, mark[u]);
			}
		}
	}

	void merge(int a, int b) {
		int oa = get(a), ob = get(b);
		for (int i = 0; i < m; ++i) {
			if (get(i) == ob) {
				set(i, oa);
			}
		}
		norm();
	}

	bool isSingleSet(int a) {
		int ga = get(a);
		for (int i = 0; i < m; ++i) {
			if (get(i) == ga && i != a)
				return false;
		}
		return true;
	}

	bool operator<(const State&o) const {
		return code < o.code;
	}

	bool canEnd() {
		int a = -1;
		for (int i = 0; i < m; ++i) {
			int gi = get(i);
			if (gi != NONE) {
				if (a == -1)
					a = gi;
				else {
					if (a != gi)
						return false;
				}
			}
		}
		return true;
	}
};

class CheapestIsland {
	public:
	int minCost(vector<string> cells) {
		int ans = 0;
		n = cells.size();
		for (int r = 0; r < n; ++r) {
			istringstream sin(cells[r]);
			m = 0;
			while (sin >> mat[r][m])
				m++;
		}
		State init;
		for (int c = 0; c < m; ++c) {
			init.set(c, NONE);
		}
		map<State, int> am;
		am[init] = 0;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				map<State, int> nam;
				cout << am.size() << endl;
				for (map<State, int>::iterator it = am.begin(); it != am.end(); ++it) {
					State s = it->first;
					int cost = it->second;
					//don't chose
					if (s.get(c) == NONE || !s.isSingleSet(c)) {
						State ns = s;
						ns.set(c, NONE);
						ns.norm();
						if (nam.count(ns) == 0) {
							nam[ns] = cost;
						} else {
							nam[ns] = min(nam[ns], cost);
						}
					}
					//chose
					State ns = s;
					if (ns.get(c) == NONE) {
						ns.set(c, NONE - 1);
					}
					if (c > 0 && ns.get(c - 1) != NONE)
						ns.merge(c, c - 1);
					ns.norm();
					if (ns.canEnd()) {
						ans = min(ans, cost + mat[r][c]);
					}
					if (nam.count(ns) == 0) {
						nam[ns] = cost + mat[r][c];
					} else {
						nam[ns] = min(nam[ns], cost + mat[r][c]);
					}
				}
				am = nam;
			}
		}
		return ans;
	}
};


double test0() {
	string t0[] = {"-10 1", 
"2 -10"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CheapestIsland * obj = new CheapestIsland();
	clock_t start = clock();
	int my_answer = obj->minCost(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -19;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"1 2 3", 
"4 5 6", 
"7 8 9"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CheapestIsland * obj = new CheapestIsland();
	clock_t start = clock();
	int my_answer = obj->minCost(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"-5 100 -5", 
"-5 100 -5"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CheapestIsland * obj = new CheapestIsland();
	clock_t start = clock();
	int my_answer = obj->minCost(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -10;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"-1 -1 1 -1 -1",
"-1 -1 1 -1 -1",
"-1 -1 1 -1 -1",
"99 99 99 99 99",
"-1 -1 -1 -1 -1",
"-1 -1 -1 -1 -1"}
;
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CheapestIsland * obj = new CheapestIsland();
	clock_t start = clock();
	int my_answer = obj->minCost(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -11;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
