#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

const double EPS = 1e-6;
inline int sign(double a) {
	return a < -EPS ? -1 : a > EPS;
}

struct Point {
	double x, y;
	Point() {
	}
	Point(double _x, double _y) :
			x(_x), y(_y) {
	}
	Point operator+(const Point&p) const {
		return Point(x + p.x, y + p.y);
	}
	Point operator-(const Point&p) const {
		return Point(x - p.x, y - p.y);
	}
	Point operator*(double d) const {
		return Point(x * d, y * d);
	}
	Point operator/(double d) const {
		return Point(x / d, y / d);
	}
	bool operator<(const Point&p) const {
		int c = sign(x - p.x);
		if (c)
			return c == -1;
		return sign(y - p.y) == -1;
	}
	double dot(const Point&p) const {
		return x * p.x + y * p.y;
	}
	double det(const Point&p) const {
		return x * p.y - y * p.x;
	}
	double alpha() const {
		return atan2(y, x);
	}
	double distTo(const Point&p) const {
		double dx = x - p.x, dy = y - p.y;
		return hypot(dx, dy);
	}
	double alphaTo(const Point&p) const {
		double dx = x - p.x, dy = y - p.y;
		return atan2(dy, dx);
	}
	void read() {
		scanf("%lf%lf", &x, &y);
	}
	double abs() {
		return hypot(x, y);
	}
	double abs2() {
		return x * x + y * y;
	}
	void write() {
		cout << "(" << x << "," << y << ")" << endl;
	}
};

#define cross(p1,p2,p3) ((p2.x-p1.x)*(p3.y-p1.y)-(p3.x-p1.x)*(p2.y-p1.y))

#define crossOp(p1,p2,p3) sign(cross(p1,p2,p3))

Point isSS(Point p1, Point p2, Point q1, Point q2) {
	double a1 = cross(q1,q2,p1), a2 = -cross(q1,q2,p2);
	return (p1 * a2 + p2 * a1) / (a1 + a2);
}

bool inMid(Point a, Point m, Point b, bool inc = false) {
	return crossOp(a,m,b) == 0 && sign((m - a).dot(m - b)) < (inc ? 1 : 0);
}

bool crsSS(Point p1, Point p2, Point q1, Point q2) { //strict
	return crossOp(p1,p2,q1) * crossOp(p1,p2,q2) < 0 && crossOp(q1,q2,p1) * crossOp(q1,q2,p2) < 0;
}

bool crsII(double l, double r, double L, double R) {
	if (l > r)
		swap(l, r);
	if (L > R)
		swap(L, R);
	return r + EPS > L && R + EPS > l;
}

bool crsTSS(Point p1, Point p2, Point q1, Point q2) {
	return crossOp(p1,p2,q1) * crossOp(p1,p2,q2) <= 0 && crossOp(q1,q2,p1) * crossOp(q1,q2,p2) <= 0
			&& crsII(p1.x, p2.x, q1.x, q2.x) && crsII(p1.y, p2.y, q1.y, q2.y);
}

Point proj(Point p1, Point p2, Point q) {
	return p1 + (p2 - p1) * (p2 - p1).dot(q - p1) / (p2 - p1).abs2();
}

class BasketballStrategy {
public:
	double scoreProbability(vector<string> team, vector<string> rivals, double Cp, double Cs) {
		int n = team.size();
		Point my[n], op[n];
		for (int i = 0; i < n; ++i) {
			istringstream sin(team[i]);
			double x, y;
			sin >> x >> y;
			my[i] = Point(x, y);
		}
		for (int i = 0; i < n; ++i) {
			istringstream sin(rivals[i]);
			double x, y;
			sin >> x >> y;
			op[i] = Point(x, y);
		}

		double pb[n][n];
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				//i -> j
				if (i == j) {
					pb[i][j] = 1;
				} else {
					double dr = 1e100;
					for (int k = 0; k < n; ++k) {
						Point pj = proj(my[i], my[j], op[k]);
						if (!inMid(my[i], pj, my[j], true)) {
							continue;
						}
						double d = op[k].distTo(pj);
						dr = min(dr, d);
					}
					double ls = my[i].distTo(my[j]);
					double t = Cp * (1 - (ls / 150) * (ls / 150));
					if (dr < 1e99) {
						t *= dr / (dr + 1);
					}
					pb[i][j] = t;
				}
			}
		}

		for (int k = 0; k < n; ++k) {
			for (int i = 0; i < n; ++i) {
				for (int j = 0; j < n; ++j) {
					pb[i][j] = max(pb[i][j], pb[i][k] * pb[k][j]);
				}
			}
		}

		double ret = 0;

		Point tar(50, 0);

		for (int shotAt = 0; shotAt < n; ++shotAt) {
			double tmp = 1;
			Point p = my[shotAt];
			double ls = my[shotAt].distTo(tar);
			double dr = 1e100;
			for (int k = 0; k < n; ++k) {
				Point pj = proj(p, tar, op[k]);
				if (!inMid(p, pj, tar, true))
					continue;
				dr = min(dr, op[k].distTo(pj));
			}
			tmp *= Cs;
			if (dr < 1e99)
				tmp *= dr / (dr + 1);
			tmp = pow(tmp, log(ls));
			tmp *= pb[0][shotAt];
			ret = max(ret, tmp);
		}

		return ret;
	}
};


double test0() {
	string t0[] = {"50 50","35 60","70 15"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"75 5","72 25","45 17"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	double p2 = 1;
	double p3 = 1;
	BasketballStrategy * obj = new BasketballStrategy();
	clock_t start = clock();
	double my_answer = obj->scoreProbability(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 0.6100612919616956;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"50 4"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"50 5"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	double p2 = 0.99;
	double p3 = 0.5;
	BasketballStrategy * obj = new BasketballStrategy();
	clock_t start = clock();
	double my_answer = obj->scoreProbability(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 0.3825461314703953;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"50 4"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"50 3"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	double p2 = 0.5;
	double p3 = 0.5;
	BasketballStrategy * obj = new BasketballStrategy();
	clock_t start = clock();
	double my_answer = obj->scoreProbability(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 0.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"50 50","40 50","40 40","40 30","50 20"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"50 41","44 29","48 27","45 41","48 64"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	double p2 = 0.999999;
	double p3 = 0.8;
	BasketballStrategy * obj = new BasketballStrategy();
	clock_t start = clock();
	double my_answer = obj->scoreProbability(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 0.25546407305110735;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"50 50","50 25"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"40 40","60 20"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	double p2 = 1;
	double p3 = 0.7;
	BasketballStrategy * obj = new BasketballStrategy();
	clock_t start = clock();
	double my_answer = obj->scoreProbability(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 0.20631213370921644;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
