#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class BoxTower {
	public:
	pair<int, int> make(int a, int b) {
		if (a > b)
			swap(a, b);
		return make_pair(a, b);
	}

	bool can(pair<int, int> a,pair<int, int> b) {
		return a.first >= b.first && a.second >= b.second;
	}
	int tallestTower(vector<int> x, vector<int> y, vector<int> z) {
		int n = x.size();
		pair<int, int> ss[20][3];
		int h[20][3];
		for (int i = 0; i < n; ++i) {
			ss[i][0] = make(x[i], y[i]);
			h[i][0] = z[i];
			ss[i][1] = make(x[i], z[i]);
			h[i][1] = y[i];
			ss[i][2] = make(y[i], z[i]);
			h[i][2] = x[i];
		}
		const int MAX_N_S = 1 << 16;
		static int dp[MAX_N_S][16][3];
		memset(dp, -1, sizeof dp);
		int ans = 0;
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < 3; ++j) {
				dp[1 << i][i][j] = h[i][j];
			}
		}
		for (int i = 1; i < (1 << n); ++i) {
			for (int j = 0; j < n; ++j) {
				if (~i >> j & 1)
					continue;
				for (int k = 0; k < 3; ++k) {
					int c = dp[i][j][k];
					if (c == -1)
						continue;
					ans = max(ans, c);
					for (int l = 0; l < n; ++l) {
						if (i >> l & 1)
							continue;
						for (int lk = 0; lk < 3; ++lk) {
							if (can(ss[j][k], ss[l][lk])) {
								dp[i | (1 << l)][l][lk] = max(dp[i | (1 << l)][l][lk], c + h[l][lk]);
							}
						}
					}
				}
			}
		}
		return ans;
	}
};


double test0() {
	int t0[] = {10, 50, 40, 20, 30};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {10, 50, 40, 20, 30};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {10, 50, 40, 20, 30};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	BoxTower * obj = new BoxTower();
	clock_t start = clock();
	int my_answer = obj->tallestTower(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 150;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {20, 30};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {20, 30};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {20, 10};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	BoxTower * obj = new BoxTower();
	clock_t start = clock();
	int my_answer = obj->tallestTower(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 30;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {20, 30};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {20, 33};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {20, 10};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	BoxTower * obj = new BoxTower();
	clock_t start = clock();
	int my_answer = obj->tallestTower(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 33;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {100, 100};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {10, 12};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {10, 8};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	BoxTower * obj = new BoxTower();
	clock_t start = clock();
	int my_answer = obj->tallestTower(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 110;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
