#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class BiggestRectangleHard {
	public:
	int findArea(vector<int> lengths) {
		int n = lengths.size();
		vector<bool> can(1 << n, false);
		vector<int> sum(1 << n, 0);
		for (int i = 0; i < sum.size(); ++i) {
			for (int j = 0; j < n; ++j) {
				if (i >> j & 1)
					sum[i] += lengths[j];
			}
		}
		for (int i = 0; i < can.size(); ++i) {
			if (sum[i] & 1)
				continue;
			for (int j = i; j > 0; (--j) &= i) {
				if (sum[j] + sum[j] == sum[i]) {
					can[i] = true;
					break;
				}
			}
		}

		int ans = -1;
		for (int i = 0; i < can.size(); ++i) {
			if (!can[i])
				continue;
			int mask = (1 << n) - 1 - i;
			for (int j = mask; j > 0; (--j) &= mask) {
				if (can[j]) {
					int by = sum[i] * sum[j] / 4;
					ans = max(ans, by);
				}
			}
		}

		return ans;
	}
}
;


double test0() {
	int t0[] = {1, 3, 3, 4, 5, 7};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	BiggestRectangleHard * obj = new BiggestRectangleHard();
	clock_t start = clock();
	int my_answer = obj->findArea(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 15;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {9, 9, 5, 6, 2, 10};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	BiggestRectangleHard * obj = new BiggestRectangleHard();
	clock_t start = clock();
	int my_answer = obj->findArea(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {3, 4, 7, 8, 10, 2, 9};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	BiggestRectangleHard * obj = new BiggestRectangleHard();
	clock_t start = clock();
	int my_answer = obj->findArea(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 70;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {9, 2, 7, 9, 4, 9, 7, 10, 3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	BiggestRectangleHard * obj = new BiggestRectangleHard();
	clock_t start = clock();
	int my_answer = obj->findArea(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 224;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int t0[] = {9, 9, 10, 7, 7, 8, 7, 5, 8, 6, 9, 7, 7, 10, 9, 6};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	BiggestRectangleHard * obj = new BiggestRectangleHard();
	clock_t start = clock();
	int my_answer = obj->findArea(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 961;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	int t0[] = {2, 6, 4, 10, 2, 8, 1, 8, 2, 1, 4, 8, 10};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	BiggestRectangleHard * obj = new BiggestRectangleHard();
	clock_t start = clock();
	int my_answer = obj->findArea(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 272;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
