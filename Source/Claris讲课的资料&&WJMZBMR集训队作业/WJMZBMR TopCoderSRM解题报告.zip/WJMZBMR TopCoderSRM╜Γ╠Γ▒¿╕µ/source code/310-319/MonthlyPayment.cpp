#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
typedef long long int64;
int64 toInt64(string s) {
	istringstream sin(s);
	int64 x;
	sin >> x;
	return x;
}

class MonthlyPayment {
	public:
	long long minimalPayment(string totalSMS, string pack1, string pay1, string pack2, string pay2) {
		int64 total = toInt64(totalSMS);
		int64 pk1 = toInt64(pack1), py1 = toInt64(pay1);
		int64 pk2 = toInt64(pack2), py2 = toInt64(pay2);

		int64 ret = 10 * total;
		for (int64 a = 0; a <= 5000000; ++a) {
			int64 b = max(0LL, (total - a * pk1) / pk2), c = max(0LL, total - a * pk1 - b * pk2);
			ret = min(ret, a * py1 + b * py2 + c * 10);
			++b;
			c = max(0LL, total - a * pk1 - b * pk2);
			ret = min(ret, a * py1 + b * py2 + c * 10);
		}

		swap(pk1, pk2);
		swap(py1, py2);
		for (int64 a = 0; a <= 5000000; ++a) {
			int64 b = max(0LL, (total - a * pk1) / pk2), c = max(0LL, total - a * pk1 - b * pk2);
			ret = min(ret, a * py1 + b * py2 + c * 10);
			++b;
			c = max(0LL, total - a * pk1 - b * pk2);
			ret = min(ret, a * py1 + b * py2 + c * 10);
		}
		return ret;
	}
};


double test0() {
	string p0 = "92";
	string p1 = "10";
	string p2 = "90";
	string p3 = "20";
	string p4 = "170";
	MonthlyPayment * obj = new MonthlyPayment();
	clock_t start = clock();
	long long my_answer = obj->minimalPayment(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 790LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string p0 = "90";
	string p1 = "10";
	string p2 = "90";
	string p3 = "20";
	string p4 = "170";
	MonthlyPayment * obj = new MonthlyPayment();
	clock_t start = clock();
	long long my_answer = obj->minimalPayment(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 770LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string p0 = "99";
	string p1 = "10";
	string p2 = "90";
	string p3 = "20";
	string p4 = "170";
	MonthlyPayment * obj = new MonthlyPayment();
	clock_t start = clock();
	long long my_answer = obj->minimalPayment(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 850LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string p0 = "10";
	string p1 = "1";
	string p2 = "11";
	string p3 = "20";
	string p4 = "300";
	MonthlyPayment * obj = new MonthlyPayment();
	clock_t start = clock();
	long long my_answer = obj->minimalPayment(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 100LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string p0 = "0";
	string p1 = "10";
	string p2 = "80";
	string p3 = "50";
	string p4 = "400";
	MonthlyPayment * obj = new MonthlyPayment();
	clock_t start = clock();
	long long my_answer = obj->minimalPayment(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 0LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string p0 = "28";
	string p1 = "1";
	string p2 = "10";
	string p3 = "1";
	string p4 = "8";
	MonthlyPayment * obj = new MonthlyPayment();
	clock_t start = clock();
	long long my_answer = obj->minimalPayment(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 224LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test6() {
	string p0 = "450702146848";
	string p1 = "63791";
	string p2 = "433956";
	string p3 = "115281";
	string p4 = "666125";
	MonthlyPayment * obj = new MonthlyPayment();
	clock_t start = clock();
	long long my_answer = obj->minimalPayment(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 2604279739220LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test7() {
	string p0 = "45";
	string p1 = "6";
	string p2 = "12";
	string p3 = "7";
	string p4 = "14";
	MonthlyPayment * obj = new MonthlyPayment();
	clock_t start = clock();
	long long my_answer = obj->minimalPayment(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 90LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	time = test6();
	if (time < 0)
		errors = true;
	
	time = test7();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
