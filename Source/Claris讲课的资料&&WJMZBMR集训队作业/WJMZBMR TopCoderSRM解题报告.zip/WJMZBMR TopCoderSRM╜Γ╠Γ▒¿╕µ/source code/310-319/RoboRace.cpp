#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

string C;
vector<string> M;
int memo[51][52][2501];
int n, m;
int rec(int r, int c, int at) {
	if (r < 0 || r >= n || c < 0 || c >= m || M[r][c] == '#')
		return INT_MAX / 4;
	if (M[r][c] == 'X')
		return 0;
	if (at == C.size()) {
		return INT_MAX / 4;
	}
	int&ret = memo[r][c][at];
	if (ret != -1)
		return ret;
	//skip
	ret = INT_MAX / 4;
	ret = min(ret, rec(r, c, at + 1) + 1);
	//follow
	switch (C[at]) {
		case 'N': {
			ret = min(ret, rec(r - 1, c, at + 1) + 1);
			break;
		}
		case 'E': {
			ret = min(ret, rec(r, c + 1, at + 1) + 1);
			break;
		}
		case 'S': {
			ret = min(ret, rec(r + 1, c, at + 1) + 1);
			break;
		}
		case 'W': {
			ret = min(ret, rec(r, c - 1, at + 1) + 1);
			break;
		}
	}
	return ret;
}

class RoboRace {
	public:
	int startTime(vector<string> board, vector<string> commands) {
		C = accumulate(commands.begin(), commands.end(), string());
		M = board;
		n = M.size(), m = M[0].size();
		memset(memo, -1, sizeof memo);
		int mr, mc, opr, opc;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (M[r][c] == 'Y') {
					mr = r, mc = c;
				} else if (M[r][c] == 'F') {
					opr = r, opc = c;
				}
			}
		}
		for (int start = 0; start < C.size(); ++start) {
			cout << rec(mr, mc, start) << " " << rec(opr, opc, start) << endl;
			if (rec(mr, mc, start) < rec(opr, opc, start)) {
				return start;
			}
		}

		return -1;
	}
};


double test0() {
	string t0[] = {"#F",
 "YX"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"NES"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	RoboRace * obj = new RoboRace();
	clock_t start = clock();
	int my_answer = obj->startTime(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"########",
 "#......#",
 "#.Y....#",
 "#.F.#..#",
 "#...X..#",
 "#...#..#",
 "#......#",
 "########"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"SSEEESSW"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	RoboRace * obj = new RoboRace();
	clock_t start = clock();
	int my_answer = obj->startTime(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"########",
 "#......#",
 "#.Y....#",
 "#.F.#..#",
 "#...X..#",
 "#...#..#",
 "#......#",
 "########"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"ESSEESSW"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	RoboRace * obj = new RoboRace();
	clock_t start = clock();
	int my_answer = obj->startTime(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"##.#.#.",
 "..##...",
 "..#...X",
 "Y...##.",
 "#...#.#",
 "..#..F."};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"SSSNWSSSEWNSENENENNNNENWNEWESE"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	RoboRace * obj = new RoboRace();
	clock_t start = clock();
	int my_answer = obj->startTime(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"#..#.........#...X##....",
 "#........#..........##.#",
 ".#.#........#.....#.#...",
 "..###...#..##.##...#....",
 "..#.#.....#....#.#.####.",
 "#...##.##.##..#.....##..",
 ".##...#.#....#.......#.#",
 "....##.#..#....#....#...",
 "....###.##.....###...#..",
 "#.#.......#.#......#..#.",
 ".##....##.#.##.......#.#",
 "......###...####......#.",
 "..#.##.#..#.#...#...#...",
 ".....#.#..........#...#.",
 "##.#....##F#.....#.##.#.",
 ".##....#.......##.##.##.",
 "..#...#..##....#..#...Y.",
 "#...........#...###..###",
 ".....#...#..#.........#.",
 ".#...##..#.#...#..#.##..",
 "#..#...######....###.#..",
 "#.#.....#.......#.##....",
 "#..#....###....#.#..#...",
 "..#...#.##.##.#.##.##..#",
 "#....##.##..........#..#"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"NWWSEWSSNWESSWES",
 "ESEEENSNWNNWSNSNWWNWWNNNWE",
 "NSNENENNSEENWWNSNNNNWWSSN",
 "EENEWNWESESEEESNNNSEENNEWNNESNEESSEESEEENENNNWSSW",
 "NWNNWSNWSWSSSSEEWSSWSESWWNNWWENSNNWWSSWWNNE",
 "NWEWNEWSNEN",
 "NNNEWNSWSNWESWNNNSWWNNNWWWNNEWNEEWSSWNSSWWNNWESEWS",
 "WSSSEESSEEEEENNSWEWWWENSENWNSEENES",
 "NNSNESESWNESNENSEESESWSENNESESNESNESEEW",
 "ESNENEENWSNS"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	RoboRace * obj = new RoboRace();
	clock_t start = clock();
	int my_answer = obj->startTime(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 18;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
