#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class ThreeMines {
	public:
	int n, m;
	int dp[31][31][31][31][4];
	bool have[31][31][31][31][4];
	int val[31][31];
	int calc(int x1, int y1, int x2, int y2, int num) {
		if (!num)
			return 0;
		int&ret = dp[x1][y1][x2][y2][num];
		if (have[x1][y1][x2][y2][num]) {
			return ret;
		}
		have[x1][y1][x2][y2][num] = true;
		ret = INT_MIN / 2;
		//cut x
		for (int x = x1 + 1; x < x2; ++x) {
			for (int i = 0; i <= num; ++i) {
				ret = max(ret, calc(x1, y1, x, y2, i) + calc(x, y1, x2, y2, num - i));
			}
		}
		//cut y
		for (int y = y1 + 1; y < y2; ++y) {
			for (int i = 0; i <= num; ++i) {
				ret = max(ret, calc(x1, y1, x2, y, i) + calc(x1, y, x2, y2, num - i));
			}
		}
		if (num == 1) {
			int sum = 0;
			for (int x = x1; x < x2; ++x) {
				for (int y = y1; y < y2; ++y) {
					sum += val[x][y];
				}
			}
			ret = max(ret, sum);
		}
		return ret;
	}
	int maximumProfit(vector<string> field) {
		n = field.size(), m = field[0].size();
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < m; ++j) {
				if (field[i][j] >= 'a' && field[i][j] <= 'z')
					val[i][j] = field[i][j] - 'a';
				else
					val[i][j] = -(field[i][j] - 'B' + 1);
			}
		}
		memset(have, false, sizeof have);
		return calc(0, 0, n, m, 3);
	}
};


double test0() {
	string t0[] = {
"bbbb",
"bBBB",
"BBbb",
"BBBB"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	ThreeMines * obj = new ThreeMines();
	clock_t start = clock();
	int my_answer = obj->maximumProfit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 7;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"cfCBDCbcdZb"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	ThreeMines * obj = new ThreeMines();
	clock_t start = clock();
	int my_answer = obj->maximumProfit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 14;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"d", "c", "B", "m", "Z", "h", "g", "B", "z", "G", "H", "b", "Y"}
;
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	ThreeMines * obj = new ThreeMines();
	clock_t start = clock();
	int my_answer = obj->maximumProfit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 54;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {
"hBhh", 
"BBBB",
"BBBB", 
"hBhh", 
"hBhh"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	ThreeMines * obj = new ThreeMines();
	clock_t start = clock();
	int my_answer = obj->maximumProfit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 62;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {
"BB", 
"BB"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	ThreeMines * obj = new ThreeMines();
	clock_t start = clock();
	int my_answer = obj->maximumProfit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {
"ZcabcaacacabcbbbcababacaccbZaa",
"acaaccccacbccbaaccabaccaacbZbc",
"bcbaacbcbbccbbcbabbbbaZcbcbccb",
"cccacbabccbZbcbabaacbbZcbacbab",
"cacbabbcabbabbcacbcbbcaacaabbc",
"bacZcacaaccbabbcccccabcaacbaca",
"cbcccacabcabacaccacaZbbcbcacbb",
"cZbbbcaacbaacaabZcaccbcZccbbab",
"Zcababaacbbbbccbcbbaccacacbbcc",
"cZcccaaabbcbcbccccbcbaabbbccbb",
"bbcaacacabccababacbccacccbbaba",
"cccbbcaZabccacabbccccabbabbbab",
"bbbacbccbbcaabaaabccbcaabcacaa",
"cbbababbccccbcccbaacacccaabaac",
"aaccaccaccbabbccaaaacbacccacca",
"bbbcabcabZZcabcabbaacZbaaabaZb",
"aaabbabcabaaacbcccccbbcabcccbc",
"bbbaccbacacaccbbaccabacbbbaaac",
"acaaacccbabbccbcbabbcbaaaccabb",
"bcaaaaabcbabaaabccacccbaacbbbc",
"bZcbcbcccaabccaabbccbababbbcca",
"cbbbbcccabcabcbacaaaaabbbbbcac",
"ccbbcbacacbbcacacbaabcbbacbaba",
"cbbbaabaabbbbaccabbcbcaccaaaac",
"abZcabaacbbcacbaaabccbabacacaa",
"aabccacbabaacaccccbbbbcccccaca",
"aabcbaaacbabcaccbaabbbabbabbca",
"ababcabaccaaaacccacbcbcabacbcb",
"bcaaaacabcabbbaccccccacabccacb",
"cbbabbbccaaaaacbccaabcbbccbacc"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	ThreeMines * obj = new ThreeMines();
	clock_t start = clock();
	int my_answer = obj->maximumProfit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 671;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
