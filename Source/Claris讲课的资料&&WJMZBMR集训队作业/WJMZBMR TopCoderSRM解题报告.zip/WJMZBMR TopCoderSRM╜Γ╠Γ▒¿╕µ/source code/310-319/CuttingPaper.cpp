#include <vector>
#include <list>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

int n, m, nv;

vector<int> edge[100000];
vector<bool> mark[100000];

int id(int r, int c) {
	return r * (m + 1) + c;
}

void add(int a, int b) {
	edge[a].push_back(b);
	mark[a].push_back(false);
	edge[b].push_back(a);
	mark[b].push_back(false);
}

bool ok(char a, char b) {
	return a != ' ' && b != ' ' && a != b;
}

bool can[100000];

void set(int a, int b) {
	for (int i = 0; i < edge[a].size(); ++i) {
		if (edge[a][i] == b)
			mark[a][i] = true;
	}
}

bool dfs(int u, bool first) {
	if (can[u] && !first)
		return true;
	can[u] = true;
	for (int i = 0; i < edge[u].size(); ++i) {
		if (!mark[u][i]) {
			int v = edge[u][i];
			set(u, v), set(v, u);
			dfs(v, false);
			return true;
		}
	}
	return false;
}

class CuttingPaper {
public:
	int minCuts(vector<string> map) {
		m = 0;
		for (vector<string>::iterator e = map.begin(); e != map.end(); ++e) {
			m = max(m, (int) e->size());
		}
		n = map.size();
		for (int r = 0; r < n; ++r) {
			map[r].insert(map[r].end(), m - map[r].size(), ' ');
		}
		nv = (n + 1) * (m + 1);
		for (int i = 0; i < nv; ++i) {
			edge[i].clear();
			mark[i].clear();
			can[i] = false;
		}
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (r + 1 < n && ok(map[r][c], map[r + 1][c])) {
					add(id(r + 1, c), id(r + 1, c + 1));
				}
				if (c + 1 < m && ok(map[r][c], map[r][c + 1])) {
					add(id(r, c + 1), id(r + 1, c + 1));
				}
				if (map[r][c] == ' ') {
					can[id(r, c)] = can[id(r + 1, c)] = can[id(r, c + 1)] = can[id(r + 1, c + 1)] =
							true;
				}
			}
		}
		for (int r = 0; r <= n; ++r) {
			can[id(r, 0)] = can[id(r, m)] = true;
		}
		for (int c = 0; c <= m; ++c) {
			can[id(0, c)] = can[id(n, c)] = true;
		}

		int ret = 0;
		for (;;) {
			cout << ret << endl;
			bool chg = false;
			for (int i = 0; i < nv; ++i) {
				if (can[i] && dfs(i, true)) {
					++ret;
					chg = true;
				}
			}
			if (!chg)
				break;
		}

		for (int i = 0; i < nv; ++i) {
			if (find(mark[i].begin(), mark[i].end(), false) != mark[i].end())
				return -1;
		}

		return ret;
	}
};


double test0() {
	string t0[] = {"AABB",
 "AABB",
 "BBDD",
 "BBDD"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CuttingPaper * obj = new CuttingPaper();
	clock_t start = clock();
	int my_answer = obj->minCuts(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"  X",
 " XXX A Y",
 "XX XX YYY",
 " XXX B Y",
 "  X"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CuttingPaper * obj = new CuttingPaper();
	clock_t start = clock();
	int my_answer = obj->minCuts(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"AAA",
 "ABA",
 "AAA"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CuttingPaper * obj = new CuttingPaper();
	clock_t start = clock();
	int my_answer = obj->minCuts(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"ABBBB",
 "AABBB",
 "AAABB",
 "AAAAB"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CuttingPaper * obj = new CuttingPaper();
	clock_t start = clock();
	int my_answer = obj->minCuts(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"AABB",
 "A BB",
 "CCDD",
 "CCDD"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CuttingPaper * obj = new CuttingPaper();
	clock_t start = clock();
	int my_answer = obj->minCuts(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 4;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {"BAA",
 "ABA",
 "AAA"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CuttingPaper * obj = new CuttingPaper();
	clock_t start = clock();
	int my_answer = obj->minCuts(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test6() {
	string t0[] = {"BBB CCCC",
 "BAB CD C",
 "BB  CCCC"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	CuttingPaper * obj = new CuttingPaper();
	clock_t start = clock();
	int my_answer = obj->minCuts(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	time = test6();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
