#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
#define CLR(x,c) memset(x,c,sizeof x)
#define FOR(i,a,b) for(int i=a;i<b;i++)
#define ALL(x) x.begin(),x.end()
#define RREP(i,n) for(int i=n-1;i>=0;i--)
#define RFOR(i,a,b) for(int i=b-1;i>=a;i--)
#define REPS(i,x) REP(i,x.size())
using namespace std;
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef istringstream ISS;
typedef ostringstream OSS;
typedef long long int64;
template<class T> void checkmax(T&x, T c) {
	if (c > x)
		x = c;
}
template<class T> void checkmin(T&x, T c) {
	if (c < x)
		x = c;
}

class PubTrivia {
	public:
	long long maximumScore(int, int, vector<int>, vector<int>);
};

typedef long long int64;

vector<int64> gen(vector<int> X, int N, int G) {
	int k = 0, s;
	int M = X.size();
	vector<int64> ret(N);
	for (int i = 0; i < N; ++i) {
		ret[i] = X[k];
		s = (k + 1) % M;
		X[k] = ((X[k] ^ X[s]) + 13) % G;
		k = s;
	}
	return ret;
}

long long PubTrivia::maximumScore(int N, int T, vector<int> _p, vector<int> _b) {
	vector<int64> p = gen(_p, N, 1001);
	vector<int64> b = gen(_b, N, 10001);
	vector<int64> dp(N + 1), end(N + 1);
	vector<int64> sum(N + 1);
	partial_sum(p.begin(), p.end(), sum.begin() + 1);
	end[0] = dp[0] = 0;
	for (int i = 1; i <= N; ++i) {
		end[i] = dp[i - 1] - p[i - 1];
		if (i >= T)
			end[i] = max(end[i], end[i - T] + sum[i] - sum[i - T] + b[i - 1]);
		dp[i] = max(dp[i - 1] + p[i - 1], end[i]);
	}
	return dp.back();
}


double test0() {
	int p0 = 5;
	int p1 = 5;
	int t2[] = {1, 2, 3, 4, 5};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {0, 0, 0, 2, 5};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	PubTrivia * obj = new PubTrivia();
	clock_t start = clock();
	long long my_answer = obj->maximumScore(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p4 = 20LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 5;
	int p1 = 3;
	int t2[] = {1, 2, 3, 4, 5};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {0, 0, 0, 2, 5};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	PubTrivia * obj = new PubTrivia();
	clock_t start = clock();
	long long my_answer = obj->maximumScore(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p4 = 16LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 5;
	int p1 = 3;
	int t2[] = {1, 2, 3};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {7, 0};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	PubTrivia * obj = new PubTrivia();
	clock_t start = clock();
	long long my_answer = obj->maximumScore(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p4 = 98LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 4;
	int p1 = 4;
	int t2[] = {998, 1};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {9998, 1};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	PubTrivia * obj = new PubTrivia();
	clock_t start = clock();
	long long my_answer = obj->maximumScore(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p4 = 1056LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
