#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
class MoreNim {
	public:
	long long bestSet(vector<string>);
};

typedef long long int64;

long long MoreNim::bestSet(vector<string> heaps) {
	vector<int64> v;
	for (int i = 0; i < heaps.size(); ++i) {
		istringstream sin(heaps[i]);
		int64 x;
		sin >> x;
		v.push_back(x);
	}
	sort(v.rbegin(), v.rend());
	vector<int64> have;
	vector<int> bit;
	int64 ans = 0;
	for (vector<int64>::iterator e = v.begin(); e != v.end(); ++e) {
		int64 u = *e;
		for (int i = 0; i < have.size(); ++i) {
			if (u >> bit[i] & 1) {
				u ^= have[i];
			}
		}
		if (u) {
			for (int j = 0;; ++j) {
				if (u >> j & 1) {
					have.push_back(u);
					bit.push_back(j);
					break;
				}
			}
			ans += *e;
		}
	}
	return accumulate(v.begin(), v.end(), 0LL) - ans;
}


double test0() {
	string t0[] = {"5","5","6","6","5","5"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	MoreNim * obj = new MoreNim();
	clock_t start = clock();
	long long my_answer = obj->bestSet(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 21LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"1","2","3"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	MoreNim * obj = new MoreNim();
	clock_t start = clock();
	long long my_answer = obj->bestSet(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 1LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"1","2","3","4","5","6","7","8","9"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	MoreNim * obj = new MoreNim();
	clock_t start = clock();
	long long my_answer = obj->bestSet(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 16LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"1","2","4","8","16","32","64","128","256"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	MoreNim * obj = new MoreNim();
	clock_t start = clock();
	long long my_answer = obj->bestSet(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 0LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"12","13","16","121","13","14","52","23","1","29"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	MoreNim * obj = new MoreNim();
	clock_t start = clock();
	long long my_answer = obj->bestSet(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 27LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
