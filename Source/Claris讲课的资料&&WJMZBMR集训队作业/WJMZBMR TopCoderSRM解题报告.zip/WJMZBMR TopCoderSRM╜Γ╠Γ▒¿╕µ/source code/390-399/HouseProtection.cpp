#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

struct Maxflow {
	struct Edge {
		int t, c;
		Edge*n, *r;
		Edge(int _t, int _c, Edge*_n) :
				t(_t), c(_c), n(_n) {
		}
	};
	vector<Edge*> E;

	int addV() {
		E.push_back((Edge*) 0);
		return E.size() - 1;
	}

	void clear() {
		E.clear();
	}

	Edge* makeEdge(int s, int t, int c) {
		return E[s] = new Edge(t, c, E[s]);
	}

	void addEdge(int s, int t, int c) {
		Edge*e1 = makeEdge(s, t, c), *e2 = makeEdge(t, s, 0);
		e1->r = e2, e2->r = e1;
	}

	int calcMaxFlow(int vs, int vt, int INF = ~0U >> 2) {
		int nV = E.size();
		int totalFlow = 0;

		vector<int> am(nV, 0), h(nV, 0), cnt(nV + 1, 0);
		vector<Edge*> prev(nV, (Edge*) 0), cur(nV, (Edge*) 0);
		cnt[0] = nV;

		int u = vs;
		Edge*e;
		am[u] = INF;
		while (h[vs] < nV) {
			for (e = cur[u]; e; e = e->n)
				if (e->c > 0 && h[u] == h[e->t] + 1)
					break;
			if (e) {
				int v = e->t;
				cur[u] = prev[v] = e;
				am[v] = min(am[u], e->c);
				u = v;
				if (u == vt) {
					int by = am[u];
					while (u != vs) {
						prev[u]->c -= by;
						prev[u]->r->c += by;
						u = prev[u]->r->t;
					}
					totalFlow += by;
					am[u] = INF;
				}
			} else {
				if (!--cnt[h[u]])
					break;
				h[u] = nV;
				for (e = E[u]; e; e = e->n)
					if (e->c > 0 && h[e->t] + 1 < h[u]) {
						h[u] = h[e->t] + 1;
						cur[u] = e;
					}
				++cnt[h[u]];
				if (u != vs)
					u = prev[u]->r->t;
			}
		}

		return totalFlow;
	}

	~Maxflow() {
		for (int i = 0; i < E.size(); ++i) {
			for (Edge*e = E[i]; e;) {
				Edge*ne = e->n;
				delete e;
				e = ne;
			}
		}
	}
};

class HouseProtection {
	public:
	double safetyFactor(vector<int>, vector<int>, vector<int>, vector<int>, int);
};

const double EPS = 1e-8;
inline int sign(double a) {
	return a < -EPS ? -1 : a > EPS;
}

typedef long long int64;

struct Point {
	int64 x, y;
	Point() {
	}
	Point(int64 _x, int64 _y) :
			x(_x), y(_y) {
	}
	int64 distTo(const Point&p) const {
		int64 dx = x - p.x, dy = y - p.y;
		return dx * dx + dy * dy;
	}
};

double HouseProtection::safetyFactor(vector<int> bx, vector<int> by, vector<int> rx, vector<int> ry, int R) {
	int n = bx.size(), m = rx.size();
	vector<Point> bs(n), rs(m);
	for (int i = 0; i < n; ++i) {
		bs[i] = Point(bx[i], by[i]);
	}
	for (int i = 0; i < m; ++i) {
		rs[i] = Point(rx[i], ry[i]);
	}
	vector<int64> need;
	need.push_back(R * R * 4);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < m; ++j) {
			need.push_back(bs[i].distTo(rs[j]));
		}
	}
	double ans = 0;
	for (vector<int64>::iterator e = need.begin(); e != need.end(); ++e) {
		int64 C = *e;
		if (C > R * R * 4)
			continue;
		Maxflow sol;
		int vs = sol.addV(), vt = sol.addV();
		vector<int> L(n), R(m);
		for (int i = 0; i < n; ++i) {
			L[i] = sol.addV();
			sol.addEdge(vs, L[i], 1);
		}
		for (int i = 0; i < m; ++i) {
			R[i] = sol.addV();
			sol.addEdge(R[i], vt, 1);
		}
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < m; ++j) {
				if (bs[i].distTo(rs[j]) < C) {
					sol.addEdge(L[i], R[j], INT_MAX);
				}
			}
		}
		int ret = n + m - sol.calcMaxFlow(vs, vt);
		ans = max(ans, ret * M_PI * C / 4);
	}
	return ans;
}

//Powered by [KawigiEdit] 2.0!


double test0() {
	int t0[] = { 0, 4 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = { 0, 0 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = { 2, 1 };
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = { 2, -1 };
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	int p4 = 1;
	HouseProtection * obj = new HouseProtection();
	clock_t start = clock();
	double my_answer = obj->safetyFactor(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 9.42477796076938;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = { 1 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = { 1 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = { 1 };
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = { 1 };
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	int p4 = 5;
	HouseProtection * obj = new HouseProtection();
	clock_t start = clock();
	double my_answer = obj->safetyFactor(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 78.53981633974483;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = { 0 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = { 0 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = { 100 };
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = { 0 };
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	int p4 = 51;
	HouseProtection * obj = new HouseProtection();
	clock_t start = clock();
	double my_answer = obj->safetyFactor(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 15707.963267948966;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = { 23, 29, 29, 35 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = { 77, 79, 75, 77 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = { 26, 26, 32 };
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = { 78, 76, 76 };
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	int p4 = 3;
	HouseProtection * obj = new HouseProtection();
	clock_t start = clock();
	double my_answer = obj->safetyFactor(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 113.09733552923255;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
