#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class EquiDigitNumbers {
	public:
	long long findNext(string);
};

typedef long long int64;

string n, ans;

void rec(string cur, int at, bool already) {
//	cout << cur << endl;
	int cnt[10] = { };
	for (int i = 0; i < at; ++i) {
		cnt[cur[i] - '0']++;
	}
	int maxCnt = *max_element(cnt, cnt + 10);
	int num = 0;
	for (int i = 0; i < 10; ++i) {
		if (cnt[i])
			++num;
	}
	int L = n.size();

	bool ok = false;
	for (int part = max(maxCnt, 1); part <= L; ++part) {
		if (L % part == 0 && L / part >= num && L / part <= 10) {
			ok = true;
		}
	}
	if (!ok)
		return;
	if (already) {
		int L = n.size();
		for (int part = max(maxCnt, 1); part <= L; ++part) {
			if (L % part == 0 && L / part >= num && L / part <= 10) {
				int tmp[10];
				memcpy(tmp, cnt, sizeof cnt);
				int rem = L - at;
				for (int i = 0; i < 10; ++i) {
					if (cnt[i] > 0) {
						rem -= part - cnt[i];
						cnt[i] = part;
					}
				}
				for (int i = 0; i < 10; ++i) {
					if (rem > 0 && cnt[i] == 0) {
						cnt[i] = part;
						rem -= part;
					}
				}
				for (int i = 0; i < at; ++i) {
					cnt[cur[i] - '0']--;
				}
				string t = cur;
				for (int i = 0; i < 10; ++i) {
					while (cnt[i] > 0) {
						t += char('0' + i);
						--cnt[i];
					}
				}
				if (ans.empty() || t < ans) {
					ans = t;
				}

				memcpy(cnt, tmp, sizeof cnt);
			}
		}
		throw 1;
	}
	if (at == L)
		return;
	for (int thisDigit = 0; thisDigit < 10; ++thisDigit) {
		if (at == 0 && thisDigit == 0)
			continue;
		if (thisDigit < n[at] - '0')
			continue;
		rec(cur + char('0' + thisDigit), at + 1, thisDigit > n[at] - '0');
	}
}

long long EquiDigitNumbers::findNext(string n) {
	istringstream sin(n);
	int64 x;
	sin >> x;
	ostringstream oss;
	oss << x - 1;
	::n = oss.str();
	ans = "";
	cout << ::n << endl;
	for (;;) {
		try {
			rec("", 0, false);
		} catch (int e) {
			istringstream sin(ans);
			int64 x;
			sin >> x;
			return x;
		}
		::n = "0" + ::n;
	}
	return -1;
}

//
double test0() {
	string p0 = "42";
	EquiDigitNumbers * obj = new EquiDigitNumbers();
	clock_t start = clock();
	long long my_answer = obj->findNext(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 42LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string p0 = "2008";
	EquiDigitNumbers * obj = new EquiDigitNumbers();
	clock_t start = clock();
	long long my_answer = obj->findNext(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 2013LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string p0 = "987654322";
	EquiDigitNumbers * obj = new EquiDigitNumbers();
	clock_t start = clock();
	long long my_answer = obj->findNext(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 987778899LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string p0 = "12345678910";
	EquiDigitNumbers * obj = new EquiDigitNumbers();
	clock_t start = clock();
	long long my_answer = obj->findNext(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 22222222222LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
