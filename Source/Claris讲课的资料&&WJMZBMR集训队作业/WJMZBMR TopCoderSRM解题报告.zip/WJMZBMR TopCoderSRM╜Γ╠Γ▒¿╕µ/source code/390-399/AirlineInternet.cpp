#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class AirlineInternet {
	public:
	double minimumRange(vector<string>, vector<string>);
};

const double EPS = 1e-10;
inline int sign(double a) {
	return a < -EPS ? -1 : a > EPS;
}

struct Point {
	double x, y;
	Point() {
	}
	Point(double _x, double _y) :
			x(_x), y(_y) {
	}
	Point operator+(const Point&p) const {
		return Point(x + p.x, y + p.y);
	}
	Point operator-(const Point&p) const {
		return Point(x - p.x, y - p.y);
	}
	Point operator*(double d) const {
		return Point(x * d, y * d);
	}
	Point operator/(double d) const {
		return Point(x / d, y / d);
	}
	bool operator<(const Point&p) const {
		int c = sign(x - p.x);
		if (c)
			return c == -1;
		return sign(y - p.y) == -1;
	}
	double dot(const Point&p) const {
		return x * p.x + y * p.y;
	}
	double det(const Point&p) const {
		return x * p.y - y * p.x;
	}
	double alpha() const {
		return atan2(y, x);
	}
	double distTo(const Point&p) const {
		double dx = x - p.x, dy = y - p.y;
		return hypot(dx, dy);
	}
	double alphaTo(const Point&p) const {
		double dx = x - p.x, dy = y - p.y;
		return atan2(dy, dx);
	}
	void read() {
		scanf("%lf%lf", &x, &y);
	}
	double abs() {
		return hypot(x, y);
	}
	double abs2() {
		return x * x + y * y;
	}
	Point unit() {
		return *this / abs();
	}
	void write() {
		cout << "(" << x << "," << y << ")" << endl;
	}
};

#define cross(p1,p2,p3) ((p2.x-p1.x)*(p3.y-p1.y)-(p3.x-p1.x)*(p2.y-p1.y))

#define crossOp(p1,p2,p3) sign(cross(p1,p2,p3))

Point isSS(Point p1, Point p2, Point q1, Point q2) {
	double a1 = cross(q1,q2,p1), a2 = -cross(q1,q2,p2);
	return (p1 * a2 + p2 * a1) / (a1 + a2);
}

bool inMid(Point a, Point m, Point b, bool inc = false) {
	return crossOp(a,m,b) == 0 && sign((m - a).dot(m - b)) < (inc ? 1 : 0);
}

bool crsSS(Point p1, Point p2, Point q1, Point q2) { //strict
	return crossOp(p1,p2,q1) * crossOp(p1,p2,q2) < 0 &&
			crossOp(q1,q2,p1) * crossOp(q1,q2,p2) < 0;
}

bool crsII(double l, double r, double L, double R) {
	if (l > r)
		swap(l, r);
	if (L > R)
		swap(L, R);
	return r + EPS > L && R + EPS > l;
}

bool crsTSS(Point p1, Point p2, Point q1, Point q2) {
	return crossOp(p1,p2,q1) * crossOp(p1,p2,q2) <= 0 && crossOp(q1,q2,p1) * crossOp(q1,q2,p2) <= 0 &&
			crsII(p1.x, p2.x, q1.x, q2.x) && crsII(p1.y, p2.y, q1.y, q2.y);
}

Point proj(Point p1, Point p2, Point q) {
	return p1 + (p2 - p1) * (p2 - p1).dot(q - p1) / (p2 - p1).abs2();
}

vector<Point> isCL(Point c, double r, Point p1, Point p2) {
	Point q1 = proj(p1, p2, c);
	double d = c.distTo(q1);
	vector<Point> ret;
	if (d > r + EPS) {
		return ret;
	}
	d = min(d, r);
	double h = sqrt(r * r - d * d);
	Point q2 = (p2 - p1).unit() * h;
	ret.push_back(q1 - q2);
	ret.push_back(q1 + q2);
	return ret;
}

double div(Point a, Point b) {
	if (sign(b.x))
		return a.x / b.x;
	else
		return a.y / b.y;
}

bool g[30][30], v[30];
int nV;

void dfs(int u) {
	v[u] = true;
	for (int v = 0; v < nV; ++v) {
		if (g[u][v] && !::v[v])
			dfs(v);
	}
}

double AirlineInternet::minimumRange(vector<string> airportLocations, vector<string> flights) {
	int n = airportLocations.size(), m = flights.size();
	vector<Point> airport(n);
	for (int i = 0; i < n; ++i) {
		istringstream sin(airportLocations[i]);
		double x, y;
		sin >> x >> y;
		airport[i] = Point(x, y);
	}

	vector<Point> start(m), target(m), pp(m), vv(m);
	vector<double> begin(m), end(m);
	for (int i = 0; i < m; ++i) {
		istringstream sin(flights[i]);
		int is, it;
		sin >> is >> it >> begin[i] >> end[i];
		start[i] = airport[is];
		target[i] = airport[it];

		Point p1 = start[i];
		Point v1 = (target[i] - start[i]) / (end[i] - begin[i]);
		p1 = p1 - v1 * begin[i];
		pp[i] = p1, vv[i] = v1;

	}

	double L = 0, R = 1e5;
	while (L + 1e-10 < R) {
		double M = (L + R) / 2;
		//check all the important times;
		vector<double> needCheck;
		//for which a flight start or end
		for (int i = 0; i < m; ++i) {
			needCheck.push_back(begin[i]);
			needCheck.push_back(end[i]);
		}
		//for which a flight disconnect from airport
		for (int i = 0; i < m; ++i) {
			for (int j = 0; j < n; ++j) {
				Point p1 = start[i], p2 = target[i];
				vector<Point> is = isCL(airport[j], M, p1, p2);
				for (vector<Point>::iterator e = is.begin(); e != is.end(); ++e) {
					Point p = *e;
					double t = div((p - p1), (p2 - p1));
					if (t > 0 && t < 1) {
						needCheck.push_back(begin[i] * (1 - t) + end[i] * t);
					}
				}
			}
		}
		//for which two flight disconnect from each other
		for (int i = 0; i < m; ++i) {
			for (int j = 0; j < i; ++j) {
				Point p1 = pp[i], p2 = pp[j];
				Point v1 = vv[i], v2 = vv[j];

				Point p = p1 - p2, v = v1 - v2;
				if (v.abs() <= EPS)
					continue;
				vector<Point> is = isCL(Point(0, 0), M, p, p + v);
				for (vector<Point>::iterator e = is.begin(); e != is.end(); ++e) {
					Point w = *e;
					double t = div(w - p, v);
					if (t >= begin[i] && t >= begin[j] && t <= end[i] && t <= end[j]) {
						needCheck.push_back(t);
					}
				}
			}
		}

		bool can = true;

		for (vector<double>::iterator e = needCheck.begin(); e != needCheck.end(); ++e) {
			double T = *e;
			nV = n + m;
			memset(g, false, sizeof g);
			for (int i = 0; i < n; ++i) {
				for (int j = 0; j < m; ++j) {
					if (begin[j] <= T && end[j] >= T) {
						Point at = pp[j] + vv[j] * T;
						if (airport[i].distTo(at) <= M - EPS) {
							g[i][j + n] = g[j + n][i] = true;
						}
					}
				}
			}
			for (int i = 0; i < m; ++i)
				if (begin[i] <= T && end[i] >= T) {
					for (int j = 0; j < m; ++j)
						if (begin[j] <= T && end[j] >= T) {
							Point ai = pp[i] + vv[i] * T, aj = pp[j] + vv[j] * T;
							if (ai.distTo(aj) <= M - EPS)
								g[i + n][j + n] = g[j + n][i + n] = true;
						}
				}

			memset(v, 0, sizeof v);
			for (int i = 0; i < n; ++i) {
				dfs(i);
			}

			bool check = true;
			for (int i = 0; i < m; ++i) {
				if (begin[i] <= T && T <= end[i]) {
					if (!v[i + n]) {
						check = false;
						break;
					}
				}
			}
			if (!check) {
				can = false;
				break;
			}
		}

		if (can)
			R = M;
		else
			L = M;
	}
	return (L + R) / 2;
}


double test0() {
	string t0[] = {"0 0","100 0"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"0 1 0 100"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	AirlineInternet * obj = new AirlineInternet();
	clock_t start = clock();
	double my_answer = obj->minimumRange(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p2 = 50.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"0 0","100 0"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"0 1 0 100","0 1 25 125","0 1 50 150","0 1 75 175"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	AirlineInternet * obj = new AirlineInternet();
	clock_t start = clock();
	double my_answer = obj->minimumRange(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p2 = 25.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"25 100","0 50","90 150","22 22","60 1","95 8","12 40"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"0 1 0 500","2 5 10 300","2 0 100 200"
,"3 6 150 400","4 5 50 450","5 1 0 300"
,"2 6 10 100"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	AirlineInternet * obj = new AirlineInternet();
	clock_t start = clock();
	double my_answer = obj->minimumRange(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p2 = 64.28201130009927;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"0 0","50 0","100 0"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"0 1 0 100"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	AirlineInternet * obj = new AirlineInternet();
	clock_t start = clock();
	double my_answer = obj->minimumRange(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p2 = 25.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"417 262","519 592","941 778"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"0 1 376 534","0 2 603 763","1 0 137 431"
,"0 1 525 583","2 1 367 551","0 1 953 996"
,"0 1 668 886"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	AirlineInternet * obj = new AirlineInternet();
	clock_t start = clock();
	double my_answer = obj->minimumRange(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p2 = 246.618769031594;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {"101 591","283 183","346 696","436 638","738 46"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"3 0 855 890","2 0 260 698","3 4 229 743"
,"1 2 519 898","3 1 863 955","4 0 407 993"
,"2 4 872 969","0 3 320 663"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	AirlineInternet * obj = new AirlineInternet();
	clock_t start = clock();
	double my_answer = obj->minimumRange(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p2 = 298.18759041416865;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test6() {
	string t0[] = {"152 998","656 487","75 999","913 535"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"1 0 347 530","0 3 75 819","3 1 893 935"
,"1 0 971 992","2 0 471 887","2 0 924 955"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	AirlineInternet * obj = new AirlineInternet();
	clock_t start = clock();
	double my_answer = obj->minimumRange(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p2 = 358.8652253980556;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	time = test6();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
