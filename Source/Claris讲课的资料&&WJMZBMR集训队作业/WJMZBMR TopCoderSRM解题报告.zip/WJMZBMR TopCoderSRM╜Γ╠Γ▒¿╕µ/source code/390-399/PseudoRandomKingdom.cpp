#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class PseudoRandomKingdom {
	public:
	double probabilityOfHappiness(vector<string>, int, int);
};

int n, C, S;
bool E[100][100];

vector<double> dfs(int u, int fa) {
	vector<double> ret(S + 1, 0);
	ret[0] = 1;
	for (int v = 0; v < n; ++v) {
		if (E[u][v] && v != fa) {
			vector<double> ch = dfs(v, u);
			vector<double> nch(S + 1, 0);
			for (int i = 0; i <= S; ++i) {
				for (int j = 0; j <= C && i + j <= S; ++j) {
					nch[i + j] += ch[i] / (C + 1);
				}
			}
			ch = nch;

			vector<double> nret(S + 1, 0);
			for (int i = 0; i <= S; ++i) {
				for (int j = 0; i + j <= S; ++j) {
					nret[max(i, j)] += ret[i] * ch[j];
				}
			}

			ret = nret;
		}
	}
	return ret;
}

double PseudoRandomKingdom::probabilityOfHappiness(vector<string> g, int cost, int savings) {
	n = g.size();
	C = cost;
	S = savings;
	memset(E, false, sizeof E);
	for (int i = 0; i < n; ++i) {
		istringstream sin(g[i]);
		int x;
		while (sin >> x) {
			E[i][x] = true;
		}
	}
	vector<double> ret = dfs(0, -1);
	return accumulate(ret.begin(), ret.end(), 0.0);
}


double test0() {
	string t0[] = {"1 2",
 "0",
 "0 3",
 "2"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 1;
	int p2 = 2;
	PseudoRandomKingdom * obj = new PseudoRandomKingdom();
	clock_t start = clock();
	double my_answer = obj->probabilityOfHappiness(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.875;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"1 2 3 4 5 6",
 "0",
 "0",
 "0",
 "0",
 "0",
 "0"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 10;
	int p2 = 19;
	PseudoRandomKingdom * obj = new PseudoRandomKingdom();
	clock_t start = clock();
	double my_answer = obj->probabilityOfHappiness(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.903158288086044;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"1 2 3 4 5 6",
 "0",
 "0",
 "0",
 "0",
 "0",
 "0"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 10;
	int p2 = 0;
	PseudoRandomKingdom * obj = new PseudoRandomKingdom();
	clock_t start = clock();
	double my_answer = obj->probabilityOfHappiness(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 5.644739300537775E-7;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"1",
 "0"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 10;
	int p2 = 500;
	PseudoRandomKingdom * obj = new PseudoRandomKingdom();
	clock_t start = clock();
	double my_answer = obj->probabilityOfHappiness(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 1.0000000000000002;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"9 6",
 "6 4",
 "8",
 "5",
 "7 1",
 "8 3",
 "1 0 8",
 "4",
 "2 5 6",
 "0"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 9;
	int p2 = 26;
	PseudoRandomKingdom * obj = new PseudoRandomKingdom();
	clock_t start = clock();
	double my_answer = obj->probabilityOfHappiness(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.350862063;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
