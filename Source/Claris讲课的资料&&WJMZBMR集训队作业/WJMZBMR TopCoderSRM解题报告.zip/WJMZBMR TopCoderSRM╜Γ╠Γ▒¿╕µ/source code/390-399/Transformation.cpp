#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
class Transformation {
	public:
	vector<string> transform(vector<string>);
};

typedef long long int64;

vector<int64> a, b;

void tryIt(int64 x) {
	int atIdx = 0, maxPow = 0;
	for (int i = 0; i < a.size(); ++i) {
		int cur = 0;
		int64&t = a[i];
		while (t % x == 0) {
			++cur;
			t /= x;
		}
		if (cur >= maxPow) {
			maxPow = cur;
			atIdx = i;
		}
	}
	for (int i = 0; i < maxPow; ++i) {
		b[atIdx] *= x;
	}
}

int64 gcd(int64 a, int64 b) {
	return b ? gcd(b, a % b) : a;
}

vector<string> Transformation::transform(vector<string> A) {
	a.clear();
	for (int i = 0; i < A.size(); ++i) {
		istringstream sin(A[i]);
		int64 x;
		sin >> x;
		a.push_back(x);
	}
	copy(a.begin(), a.end(), ostream_iterator<int>(cout, " "));
	b.assign(a.size(), 1LL);

	const int MAX_VALUE = int(1e6);
	vector<bool> is(MAX_VALUE + 1, true);
	for (int i = 2; i * i <= MAX_VALUE; ++i) {
		if (!is[i])
			continue;
		for (int j = i * i; j <= MAX_VALUE; j += i)
			is[j] = false;
	}
	for (int p = 2; p <= MAX_VALUE; ++p) {
		if (is[p])
			tryIt(p);
	}
	//then a[i] = p^2 or pq or p
	for (int i = 0; i < a.size(); ++i) {
		if (a[i] == 1)
			continue;
		int64 rt = sqrt(a[i]) - 2;
		if (rt < 0)
			rt = 0;
		while (rt * rt < a[i])
			++rt;
		if (a[i] == rt * rt) {
			tryIt(rt);
		}
	}
	//then a[i] = pq or p
	for (int i = 0; i < a.size(); ++i) {
		for (int j = 0; j < i; ++j) {
			int64 g = gcd(a[i], a[j]);
			if (g > 1 && (g < a[i] || g < a[j])) {
				tryIt(g);
			}
		}
	}
	for (int i = 0; i < a.size(); ++i) {
		if (a[i] > 1)
			tryIt(a[i]);
	}
	vector<string> ret;
	for (int i = 0; i < b.size(); ++i) {
		ostringstream oss;
		oss << b[i];
		ret.push_back(oss.str());
	}
	return ret;
}


double test0() {
	string t0[] = {"1","2"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	Transformation * obj = new Transformation();
	clock_t start = clock();
	vector <string> my_answer = obj->transform(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"1", "2" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"2","3","6"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	Transformation * obj = new Transformation();
	clock_t start = clock();
	vector <string> my_answer = obj->transform(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"1", "1", "6" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"210","2","3","5","7"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	Transformation * obj = new Transformation();
	clock_t start = clock();
	vector <string> my_answer = obj->transform(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"1", "2", "3", "5", "7" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"6","2","3","4","9"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	Transformation * obj = new Transformation();
	clock_t start = clock();
	vector <string> my_answer = obj->transform(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"1", "1", "1", "4", "9" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"6","2","3","4","9","8"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	Transformation * obj = new Transformation();
	clock_t start = clock();
	vector <string> my_answer = obj->transform(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"1", "1", "1", "1", "9", "8" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {"3637","260","26122993443584","47715564111559878","2","871126696052836","3492829317","83024857214176826"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	Transformation * obj = new Transformation();
	clock_t start = clock();
	vector <string> my_answer = obj->transform(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"3637", "5", "26122993443584", "7952594018593313", "1", "217781674013209", "3492829317", "41512428607088413" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
