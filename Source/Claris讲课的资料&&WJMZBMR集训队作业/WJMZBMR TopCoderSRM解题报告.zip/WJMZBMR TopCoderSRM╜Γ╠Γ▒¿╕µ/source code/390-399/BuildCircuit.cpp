#include <vector>
#include <list>
#include <map>
#include <set>
#include <algorithm>
#include <utility>
#include <sstream>
#include <iostream>
#include <cmath>
#include <cstring>
#include <cstdlib>
#include <cctype>
#include <cstdio>
#include <numeric>
#include <climits>
#include <complex>
#define REP(i,n) for(int i=0;i<n;i++)
#define PB push_back
#define ALL(x) x.begin(),x.end()
#define FOREACH(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();e++)
#define FOR(i,a,b) for(int i=a;i<b;i++)//for i in [a,b)
#define MP make_pair
#define SIZE(x) int(x.size())
#define SORT(x) sort(ALL(x))
#define UNIQUE(x) x.resize(unique(ALL(x))-x.begin())
#define CLR(x,t) memset(x,t,sizeof x)
#define ACM accumulate
#define MC(a,b) memcpy(a,b,sizeof a) //memcpy
#define two(a) (1<<(a))
#define contain(s,a) (((s)&TWO(a))!=0)
using namespace std;
typedef long long int64;
typedef pair<int,int> ipair;
typedef vector<int> vi;
typedef stringstream SS;
template<class T> inline void checkmin(T&x,T c){if(c<x)x=c;}
template<class T> inline void checkmax(T&x,T c){if(c>x)x=c;}
//Finished

template<class It>
string toString(It l,It r){
	SS ss;
	ss<<"[";
	for(It i=l;i!=r;i++)
	{
		ss<<*i;
		if(i+1!=r)
			ss<<",";
	}
	ss<<"]";
	return ss.str();
}

class BuildCircuit {
public:
	int minimalCount(int, int);
};

int64 gcd(int64 a,int64 b){
	return b?gcd(b,a%b):a;
}
struct Frac{
	int64 p,q;//p/q
	Frac(){}
	Frac(int64 _p,int64 _q){
		p=_p;q=_q;
		if(p<=0)
			return;
		int64 g=gcd(p,q);
		p/=g;q/=g;
	}
	Frac reciprocal(){
		return Frac(q,p);
	}
	bool valid(){
		return p>0&&q>0;
	}
	bool operator< (const Frac&frac)const{
		if(p!=frac.p)
			return p<frac.p;
		return q<frac.q;
	}
};

Frac operator+(Frac a,Frac b){
	return Frac(a.p*b.q+a.q*b.p,a.q*b.q);
}

Frac operator-(Frac a,Frac b){
	return Frac(a.p*b.q-a.q*b.p,a.q*b.q);
}

Frac serial(Frac a,Frac b){
	return a+b;
}

Frac unSerial(Frac a,Frac b){
	return a-b;
}

Frac parallel(Frac a,Frac b){
	Frac c=a.reciprocal()+b.reciprocal();
	return c.reciprocal();
}

Frac unParallel(Frac a,Frac b){
	Frac c=a.reciprocal()-b.reciprocal();
	return c.reciprocal();
}

set<Frac> Set[12];
bool check(Frac x,int r){
	if(!x.valid())
		return false;
	if(r<=10)
		return Set[r].count(x);
	for(int i=r/2;i>=1;i--){
		FOREACH(it,Set[i]){
			Frac u=*it;
			if(check(unSerial(x,u),r-i))
				return true;
			if(check(unParallel(x,u),r-i))
				return true;
		}
	}
	return false;
}
int BuildCircuit::minimalCount(int a, int b) {
	Set[1].clear();
	Set[1].insert(Frac(1,1));
	Set[1].insert(Frac(2,1));
	for(int i=2;i<=10;i++){
		Set[i].clear();
		for(int u=i/2;u>=1;u--){
			int v=i-u;
			FOREACH(uIt,Set[u])
				FOREACH(vIt,Set[v]){
					Set[i].insert(serial(*uIt,*vIt));
					Set[i].insert(parallel(*uIt,*vIt));
				}
		}
	}
	Frac x(a,b);
	for(int i=1;i<=16;i++){
		if(check(x,i))
			return i;
	}
	return -1;
}


//Powered by [KawigiEdit] 2.0!


//Powered by [KawigiEdit] 2.0!
