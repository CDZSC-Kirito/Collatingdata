#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class MyFriends {
	public:
	string calcFriends(vector<int>, int);
};

string MyFriends::calcFriends(vector<int> sumF, int k) {
	int n = sumF.size();
	int sum = accumulate(sumF.begin(), sumF.end(), 0);
	if (sum % (n - 2) != 0)
		return "IMPOSSIBLE";
	sum /= n - 2;
	if (sum % 2 != 0)
		return "IMPOSSIBLE";
	for (int i = 0; i < n; ++i) {
		sumF[i] = sum - sumF[i];
	}
	vector<int> F(n);
	vector<bool> mark(n, false);
	for (int i = 0; i < n; ++i) {
		if (mark[i])
			continue;
		vector<int> v;
		int u = i;
		while (!mark[u]) {
			mark[u] = true;
			v.push_back(u);
			(u += k) %= n;
		}
		vector<int> ret;
		for (int firstDeg = 0; firstDeg < n; ++firstDeg) {
			vector<int> deg(v.size());
			for (int i = 0; i < v.size(); ++i) {
				if (!i)
					deg[i] = firstDeg;
				else
					deg[i] = sumF[v[i - 1]] - deg[i - 1];
			}
			if (deg.back() + deg[0] == sumF[v.back()]) {
				ret = deg;
				break;
			}
		}
		if (ret.empty())
			return "IMPOSSIBLE";
		for (int i = 0; i < v.size(); ++i) {
			F[v[i]] = ret[i];
		}
	}
	copy(F.begin(), F.end(), ostream_iterator<int>(cout, " "));

	//then check F
	while (!F.empty()) {
		sort(F.rbegin(), F.rend());
		for (int i = 1; i <= F.front(); ++i) {
			if (i >= F.size())
				return "IMPOSSIBLE";
			--F[i];
			if (F[i] < 0)
				return "IMPOSSIBLE";
		}
		F.erase(F.begin());
	}
	return "POSSIBLE";
}


double test0() {
	int t0[] = {8, 9, 8, 8, 9};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 2;
	MyFriends * obj = new MyFriends();
	clock_t start = clock();
	string my_answer = obj->calcFriends(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "POSSIBLE";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {7, 6, 5, 4, 4};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 2;
	MyFriends * obj = new MyFriends();
	clock_t start = clock();
	string my_answer = obj->calcFriends(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "IMPOSSIBLE";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {5, 6, 5, 4, 4};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 1;
	MyFriends * obj = new MyFriends();
	clock_t start = clock();
	string my_answer = obj->calcFriends(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "POSSIBLE";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {1, 2, 3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 1;
	MyFriends * obj = new MyFriends();
	clock_t start = clock();
	string my_answer = obj->calcFriends(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "IMPOSSIBLE";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
