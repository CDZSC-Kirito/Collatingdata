#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class TheXGame {
	public:
	int firstMove(string board) {
		vector<int> a;
		for (int i = 0; i < board.size();) {
			if (board[i] == '-') {
				int j;
				for (j = i + 1; j < board.size(); ++j) {
					if (board[j] == 'X')
						break;
				}
				a.push_back(j - i);
				i = j;
			} else {
				++i;
			}
		}
		if (count(board.begin(), board.end(), '-') <= 2)
			return -1;

		int xorSum = 0;
		for (vector<int>::iterator e = a.begin(); e != a.end(); ++e) {
			xorSum ^= *e;
		}

		int ret = INT_MAX;
		for (int i = 0; i < a.size(); ++i) {
			int cur = xorSum ^ a[i];
			for (int j = 0; j < a[i]; ++j) {
				for (int k = 0; j + k < a[i]; ++k) {
					if (!(cur ^ j ^ k)) {
						ret = min(ret, a[i] - j - k);
					}
				}
			}
		}

		if (ret == INT_MAX
		)
			ret = -1;
		return ret;
	}
};


//Powered by [KawigiEdit] 2.0!
