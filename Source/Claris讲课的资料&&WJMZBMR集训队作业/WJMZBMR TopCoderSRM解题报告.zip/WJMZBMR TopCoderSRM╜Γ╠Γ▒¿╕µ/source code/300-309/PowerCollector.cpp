#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

typedef long long int64;

class PowerCollector {
	public:
	vector<int> ps;
	int64 n, ans;

	int64 mul(int64 a, int64 b) {
		if (a > n / b)
			return n + 1;
		return a * b;
	}

	int64 power(int64 a, int64 e) {
		if (!e)
			return 1;
		return e & 1 ? mul(power(a, e - 1), a) : power(mul(a, a), e >> 1);
	}

	void rec(int at, int p, int sign) {
		if (p >= 64)
			return;
		if (at == ps.size()) {
			if (p == 1)
				return;
			int64 x = pow(1.0 * n, 1.0 / p) - 2;
			if (x < 0)
				x = 0;
			while (power(x + 1, p) <= n)
				++x;
			cout << p << " " << x << endl;
			ans += sign * (x - 1);
			return;
		}
		rec(at + 1, p * ps[at], -sign);
		rec(at + 1, p, sign);
	}
	string countPowers(string N) {
		istringstream sin(N);
		sin >> n;
		for (int i = 2; i <= 64; ++i) {
			bool chk = true;
			for (int j = 2; j < i; ++j) {
				if (i % j == 0) {
					chk = false;
				}
			}
			if (chk)
				ps.push_back(i);
		}
		ans = 0;
		rec(0, 1, -1);
		ostringstream oss;
		oss << ans + 1;
		return oss.str();
	}
};


double test0() {
	string p0 = "10";
	PowerCollector * obj = new PowerCollector();
	clock_t start = clock();
	string my_answer = obj->countPowers(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "4";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string p0 = "36";
	PowerCollector * obj = new PowerCollector();
	clock_t start = clock();
	string my_answer = obj->countPowers(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "9";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string p0 = "1000000000000000000";
	PowerCollector * obj = new PowerCollector();
	clock_t start = clock();
	string my_answer = obj->countPowers(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "1001003332";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
