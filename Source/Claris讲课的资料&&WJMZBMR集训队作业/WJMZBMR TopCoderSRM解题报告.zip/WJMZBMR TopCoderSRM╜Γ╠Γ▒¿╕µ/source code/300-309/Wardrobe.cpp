#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

typedef int Arr[51][51][51][2][2][2];
typedef int(*Ptr)[51][51][2][2][2];
Arr dp[2];

int cnt[110];

int&get(Ptr p, int a[3], bool f[3]) {
	return p[a[0]][a[1]][a[2]][f[0]][f[1]][f[2]];
}

void update(Ptr cur, int v, int am[3], bool ful[3], Ptr nxt, int nv, int cst) {
	int nam[3] = { };
	bool nful[3] = { };

	int offset = nv - v;
	for (int i = 0; i < 3; ++i) {
		if (i - offset < 0) {
			if (ful[i] && am[i] > 0)
				return;
		} else {
			nam[i - offset] = am[i];
			nful[i - offset] = ful[i];
		}
	}

	for (int i = 0; i < 3; ++i) {
		if (i + offset >= 3) {
			nam[i] = nv + i - 1 < 0 ? 0 : cnt[nv + i - 1];
			nful[i] = false;
		}
	}

	int&ref = get(nxt, nam, nful);
	ref = max(ref, cst);
}

void clear(Ptr p) {
	memset(p, -1, sizeof dp[0]);
}

class Wardrobe {
public:
	int countUnscrewedHoles(vector<int> a) {
		sort(a.begin(), a.end());
		memset(cnt, 0, sizeof cnt);
		for (vector<int>::iterator e = a.begin(); e != a.end(); ++e) {
			cnt[*e]++;
		}
		Ptr cur = dp[0], nxt = dp[1];
		clear(cur), clear(nxt);
		cur[0][0][0][0][0][0] = 0;
		int am[3] = { };
		bool ful[3] = { };
		update(cur, -100, am, ful, nxt, a[0], 0);
		swap(cur, nxt), clear(nxt);

		for (int i = 0; i < a.size(); ++i) {
			int v = a[i], nv = (i + 1 == a.size() ? 104 : a[i + 1]);
			for (int a = 0; a <= 50; ++a) {
				for (int b = 0; b <= 50; ++b) {
					for (int c = 0; c <= 50; ++c) {
						for (int d = 0; d < 2; ++d) {
							for (int e = 0; e < 2; ++e) {
								for (int f = 0; f < 2; ++f) {
									int am[] = { a, b, c };
									bool ful[] = { d, e, f };
									int cst = get(cur, am, ful);
									if (cst == -1)
										continue;
									cout << a << " " << b << " " << c << " " << d << " " << e << " "
											<< f << endl;
									//put it
									for (int w = 0; w < 3; ++w) {
										if (am[w] > 0) {
											--am[w];
											update(cur, v, am, ful, nxt, nv, cst);
											++am[w];
										}
									}
									//neglect it
									fill(ful, ful + 3, true);
									update(cur, v, am, ful, nxt, nv, cst + 1);
								}
							}
						}
					}
				}
			}
			swap(cur, nxt);
			clear(nxt);
		}

		return cur[0][0][0][0][0][0];
	}
};


double test0() {
	int t0[] = {1, 2, 3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	Wardrobe * obj = new Wardrobe();
	clock_t start = clock();
	int my_answer = obj->countUnscrewedHoles(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {1, 2, 3, 2, 4};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	Wardrobe * obj = new Wardrobe();
	clock_t start = clock();
	int my_answer = obj->countUnscrewedHoles(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {1, 2, 3, 3, 4, 2, 5, 4};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	Wardrobe * obj = new Wardrobe();
	clock_t start = clock();
	int my_answer = obj->countUnscrewedHoles(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {12, 14, 12, 25, 15, 22, 19, 13, 26, 19, 24, 18, 14};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	Wardrobe * obj = new Wardrobe();
	clock_t start = clock();
	int my_answer = obj->countUnscrewedHoles(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int t0[] = {26, 26, 26, 14, 13, 28, 27, 15, 27, 28, 28, 26};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	Wardrobe * obj = new Wardrobe();
	clock_t start = clock();
	int my_answer = obj->countUnscrewedHoles(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
