#include <vector>
#include <list>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <queue>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

const int MAX_N = 8;
const int MAX_M = 60;
const int INF = INT_MAX / 4;

class FourBears {
public:
	int clearPassages(vector<string> map) {
		int dp[MAX_N][MAX_M][16];
		int n = map.size(), m = map[0].size();
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				for (int k = 0; k < 16; ++k) {
					dp[r][c][k] = INF;
				}
			}
		}
		int cost[MAX_N][MAX_M];
		int id[MAX_N][MAX_M];
		memset(id, -1, sizeof id);
		int cur = 0;

		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (map[r][c] == 'B') {
					id[r][c] = cur++;
					cost[r][c] = 0;
				} else if (c == 0 || c == m - 1)
					cost[r][c] = INF;
				else {
					cost[r][c] = map[r][c] == '.';
				}
			}
		}

		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				dp[r][c][0] = cost[r][c];
			}
		}

		for (int mask = 0; mask < 16; ++mask) {
			priority_queue<pair<int, pair<int, int> > > pq;

			bool used[MAX_N][MAX_M] = { };

			for (int r = 0; r < n; ++r) {
				for (int c = 0; c < m; ++c) {
					for (int nmask = mask; nmask > 0; (--nmask) &= mask) {
						if (nmask != mask)
							dp[r][c][mask] = min(dp[r][c][mask],
									dp[r][c][nmask] + dp[r][c][mask ^ nmask] - cost[r][c]);
					}
				}
			}

			for (int r = 0; r < n; ++r) {
				for (int c = 0; c < m; ++c) {
					pq.push(make_pair(-dp[r][c][mask], make_pair(r, c)));
				}
			}

			while (!pq.empty()) {
				int r = pq.top().second.first, c = pq.top().second.second;
				int cst = -pq.top().first;
				pq.pop();
				if (used[r][c])
					continue;
				used[r][c] = true;

				int nr, nc;

				nr = r - 1, nc = c;
				if (nr >= 0 && nr < n && nc >= 0 && nc < m) {
					int ncst = cst + cost[nr][nc];
					if (ncst < dp[nr][nc][mask]) {
						dp[nr][nc][mask] = ncst;
						pq.push(make_pair(-ncst, make_pair(nr, nc)));
					}
				}

				nr = r + 1, nc = c;
				if (nr >= 0 && nr < n && nc >= 0 && nc < m) {
					int ncst = cst + cost[nr][nc];
					if (ncst < dp[nr][nc][mask]) {
						dp[nr][nc][mask] = ncst;
						pq.push(make_pair(-ncst, make_pair(nr, nc)));
					}
				}

				nr = r, nc = c - 1;
				if (nr >= 0 && nr < n && nc >= 0 && nc < m) {
					int ncst = cst + cost[nr][nc];
					if (ncst < dp[nr][nc][mask]) {
						dp[nr][nc][mask] = ncst;
						pq.push(make_pair(-ncst, make_pair(nr, nc)));
					}
				}

				nr = r, nc = c + 1;
				if (nr >= 0 && nr < n && nc >= 0 && nc < m) {
					int ncst = cst + cost[nr][nc];
					if (ncst < dp[nr][nc][mask]) {
						dp[nr][nc][mask] = ncst;
						pq.push(make_pair(-ncst, make_pair(nr, nc)));
					}
				}
			}

			for (int r = 0; r < n; ++r) {
				for (int c = 0; c < m; ++c) {
					if (id[r][c] != -1) {
						dp[r][c][mask | (1 << id[r][c])] = min(dp[r][c][mask | (1 << id[r][c])],
								dp[r][c][mask]);
					}
				}
			}
		}

		int ans = INF;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				ans = min(ans, dp[r][c][15]);
			}
		}

		return ans;
	}
};


double test0() {
	string t0[] = {
 "B.X...............",
 "..X..XXXXXXXXXX..B",
 "B.X..X........X...",
 ".....X........X...",
 "..XXXX........X..B"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FourBears * obj = new FourBears();
	clock_t start = clock();
	int my_answer = obj->clearPassages(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 7;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {
 "..................",
 "B..........XXXX..B",
 "..........X.......",
 "....XXXXXX........",
 "..........XX......",
 "B............XX..B",
 ".................."
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FourBears * obj = new FourBears();
	clock_t start = clock();
	int my_answer = obj->clearPassages(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 15;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {
 "B.B",
 "...",
 "B.B"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FourBears * obj = new FourBears();
	clock_t start = clock();
	int my_answer = obj->clearPassages(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {
 "..B",
 "B.B",
 "B.."
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FourBears * obj = new FourBears();
	clock_t start = clock();
	int my_answer = obj->clearPassages(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {
 "B..................XX.................XX.XXX.....B",
 "...XXXXX.....XXXX......XXXXX.....XXXX..XXX.XXXX...",
 "............XX..................XX................",
 ".......XXX........XX..X....XXX...........XXX......",
 "............XXX......X.XXX......XXX.XXX..X.XXX....",
 "....XXXX......XXX...X...XXXX......XXX.XXXX........",
 "B..XX..............XX............................B"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FourBears * obj = new FourBears();
	clock_t start = clock();
	int my_answer = obj->clearPassages(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 28;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
