#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

vector<string> split(string s, string del = " ") {
	s += del[0];
	string w = "";
	vector<string> ret;
	for (string::iterator e = s.begin(); e != s.end(); ++e) {
		if (del.find(*e) == string::npos)
			w += *e;
		else {
			if (w != "")
				ret.push_back(w);
			w = "";
		}
	}
	return ret;
}

const int MAX = int(1e9);
typedef long long int64;

inline void rex(int64&x) {
	if (x > MAX)
		x = MAX + 1;
}

int64 dp[30][40][40];
int64 am[55][55];

class ContextFreeGrammars {
public:
	int countParsingTrees(vector<string> rules, char seed, string word) {
		vector<string> by[30];
		for (int i = 0; i < rules.size(); ++i) {
			string s = rules[i];
			vector<string> ps = split(s, ":=| ");
			for (int j = 1; j < ps.size(); ++j) {
				by[ps[0][0] - 'A'].push_back(ps[j]);
			}
		}
		memset(dp, 0, sizeof dp);
		int n = word.size();
		for (int l = n - 1; l >= 0; --l) {
			for (int r = l; r < n; ++r) {
				string cur = word.substr(l, r - l + 1);
				for (int ch = 0; ch < 26; ++ch) {
					for (int k = 0; k < by[ch].size(); ++k) {
						string&s = by[ch][k];
						for (int i = 0; i <= cur.size(); ++i) {
							for (int j = 0; j <= s.size(); ++j) {
								am[i][j] = 0;
							}
						}
						am[0][0] = 1;
						for (int i = 1; i <= cur.size(); ++i) {
							for (int j = 1; j <= s.size(); ++j) {
								if (islower(s[j - 1]) && s[j - 1] == cur[i - 1])
									rex(am[i][j] += am[i - 1][j - 1]);
								if (isupper(s[j - 1]))
									for (int pi = 0; pi < i; ++pi) {
										am[i][j] += am[pi][j - 1]
												* dp[s[j - 1] - 'A'][l + pi][l + i - 1];
										rex(am[i][j]);
									}
							}
						}
						rex(dp[ch][l][r] += am[cur.size()][s.size()]);
					}
				}
			}
		}

		int64 ans = dp[seed - 'A'][0][n - 1];
		if (ans > MAX)
			return -1;
		return ans;
	}
};


double test0() {
	string t0[] = {"A ::= BD",
 "B ::= bB | b | Bb",
 "D ::= dD",
 "D ::= d"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	char p1 = 'A';
	string p2 = "bdd";
	ContextFreeGrammars * obj = new ContextFreeGrammars();
	clock_t start = clock();
	int my_answer = obj->countParsingTrees(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"A ::= BD",
 "B ::= bB | b | Bb",
 "D ::= dD",
 "D ::= d"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	char p1 = 'A';
	string p2 = "bbd";
	ContextFreeGrammars * obj = new ContextFreeGrammars();
	clock_t start = clock();
	int my_answer = obj->countParsingTrees(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"A ::= BD",
 "B ::= bB | b | Bb",
 "D ::= dD",
 "D ::= d"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	char p1 = 'A';
	string p2 = "ddbb";
	ContextFreeGrammars * obj = new ContextFreeGrammars();
	clock_t start = clock();
	int my_answer = obj->countParsingTrees(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"B ::= topcoder | topcoder",
 "B ::= topcoder"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	char p1 = 'B';
	string p2 = "topcoder";
	ContextFreeGrammars * obj = new ContextFreeGrammars();
	clock_t start = clock();
	int my_answer = obj->countParsingTrees(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"A ::= BCD",
 "Z ::= z",
 "B ::= Cz | Dz | Zz",
 "C ::= Bz | Dz",
 "D ::= Cz | Bz"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	char p1 = 'X';
	string p2 = "zzz";
	ContextFreeGrammars * obj = new ContextFreeGrammars();
	clock_t start = clock();
	int my_answer = obj->countParsingTrees(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {"B ::= bB | bB | bB | bB | b" };
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	char p1 = 'B';
	string p2 = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbb";
	ContextFreeGrammars * obj = new ContextFreeGrammars();
	clock_t start = clock();
	int my_answer = obj->countParsingTrees(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
