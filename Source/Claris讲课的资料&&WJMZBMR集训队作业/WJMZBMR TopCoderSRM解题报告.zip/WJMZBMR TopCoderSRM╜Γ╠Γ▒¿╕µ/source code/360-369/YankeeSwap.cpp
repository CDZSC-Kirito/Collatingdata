#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class YankeeSwap {
	public:
	vector<int> match;
	int N;

	bool check(string done) {
		vector<int> p(N);
		for (int i = 0; i < N; ++i) {
			p[i] = i;
		}
		for (int i = 0; i < done.size(); ++i) {
			if (done[i] == '-')
				continue;
			swap(p[i], p[done[i] - 'a']);
		}
		for (int i = done.size(); i < N; ++i) {
			for (int j = 0; j < N; ++j) {
				if (p[j] == match[i]) {
					swap(p[i], p[j]);
					break;
				}
			}
		}
		for (int i = 0; i < N; ++i) {
			if (p[i] != match[i])
				return false;
		}
		return true;
	}

	string sequenceOfSwaps(vector<string> pref) {
		N = pref.size();
		match.assign(N, -1);
		vector<bool> used(N, false);
		for (int i = N - 1; i >= 0; --i) {
			for (int j = 0; j < N; ++j) {
				if (!used[pref[i][j] - 'A']) {
					match[i] = pref[i][j] - 'A';
					break;
				}
			}
			used[match[i]] = true;
		}

		string ans = "";
		for (int i = 0; i < N; ++i) {
			ans += " ";
			ans[i] = '-';
			if (check(ans))
				continue;
			for (char j = 'a'; j <= 'z'; ++j) {
				ans[i] = j;
				if (check(ans))
					break;
			}
		}

		return ans;
	}
};


double test0() {
	string t0[] = {"BAC",
 "ACB",
 "BCA"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	YankeeSwap * obj = new YankeeSwap();
	clock_t start = clock();
	string my_answer = obj->sequenceOfSwaps(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "-aa";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"ABC",
 "BCA",
 "CAB"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	YankeeSwap * obj = new YankeeSwap();
	clock_t start = clock();
	string my_answer = obj->sequenceOfSwaps(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "---";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"AECDBF",
 "BAEDCF",
 "DEBACF",
 "BEDCAF",
 "CEABDF",
 "CBDEAF"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	YankeeSwap * obj = new YankeeSwap();
	clock_t start = clock();
	string my_answer = obj->sequenceOfSwaps(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "-aac-a";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"FDBHMAIELGKNJC",
 "KGMDJBAFLECNHI",
 "FKLJCADBEHNGIM",
 "JMHNICABFKEGDL",
 "IKFCDNJBLEGAMH",
 "FDNLJGCKHMBIEA",
 "MBKJAHDNIGECLF",
 "KNADLFGBJIMHCE",
 "AIFMGEBDHKJNCL",
 "MCDALIJGNKBFHE",
 "AJHMDLEIFKNCGB",
 "IJLKBCMDGNHFEA",
 "EAKFLJBDGMHCIN",
 "JEMANBDFGICHKL"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	YankeeSwap * obj = new YankeeSwap();
	clock_t start = clock();
	string my_answer = obj->sequenceOfSwaps(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "--acacbdcahcja";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
