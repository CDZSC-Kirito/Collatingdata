#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

typedef long long int64;

const int MOD = 12345678;

class MountainMap {
	public:
	vector<string> data;
	vector<vector<bool> > is;
	int ans;

	int n, m;

	int cntBit(int x) {
		int ret = 0;
		for (; x; x -= x & -x)
			++ret;
		return ret;
	}

	inline void add(int&x, int c) {
		x += c;
		if (x >= MOD)
			x -= MOD;
	}

	void eval() {
		int cnt = 0;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (is[r][c])
					++cnt;
			}
		}

		vector<int> block;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (is[r][c]) {
					int x = 0;
					int id = r * m + c;
					if (r > 0)
						x |= 1 << (id - m);
					if (r + 1 < n)
						x |= 1 << (id + m);
					if (c > 0)
						x |= 1 << (id - 1);
					if (c + 1 < m)
						x |= 1 << (id + 1);
					if (r > 0 && c > 0)
						x |= 1 << (id - m - 1);
					if (r > 0 && c + 1 < m)
						x |= 1 << (id - m + 1);
					if (r + 1 < n && c > 0)
						x |= 1 << (id + m - 1);
					if (r + 1 < n && c + 1 < m)
						x |= 1 << (id + m + 1);
					block.push_back(x);
				}
			}
		}

		vector<int> num(1 << cnt);
		vector<int> bc(1 << cnt);
		for (int s = 0; s < num.size(); ++s) {
			int mask = (1 << (n * m)) - 1;
			for (int j = 0; j < cnt; ++j) {
				if (~s >> j & 1) {
					mask &= ~block[j];
				}
			}
			num[s] = cntBit(mask) - cnt;
			bc[s] = cntBit(s);
		}

		vector<int> am(1 << cnt, 0);
		am[0] = 1;
		for (int it = 0; it < n * m; ++it) {
			vector<int> nam(1 << cnt, 0);
			for (int s = 0; s < am.size(); ++s) {
				if (!am[s])
					continue;
				//put a local min
				for (int k = 0; k < cnt; ++k) {
					if (~s >> k & 1) {
						add(nam[s | (1 << k)], am[s]);
					}
				}
				//put a usual
				int rem = num[s] - it + bc[s];
				if (rem) {
					add(nam[s], 1LL * am[s] * rem % MOD);
				}
			}
			am = nam;
		}

		int ret = am.back();

		int o = 0;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (data[r][c] == 'X')
					++o;
			}
		}
		cout << ret << endl;

		if ((cnt - o) % 2 == 0)
			add(ans, ret);
		else
			add(ans, MOD - ret);
	}

	void rec(int r, int c) {
		if (c == m) {
			rec(r + 1, 0);
			return;
		}
		if (r == n) {
			eval();
			return;
		}
		bool can = true;
		if ((r > 0 && is[r - 1][c]) || (c > 0 && is[r][c - 1])) {
			can = false;
		}
		if ((r > 0 && c > 0 && is[r - 1][c - 1])) {
			can = false;
		}
		if ((r > 0 && c + 1 < m && is[r - 1][c + 1])) {
			can = false;
		}
		if (can) {
			is[r][c] = true;
			rec(r, c + 1);
		}
		is[r][c] = false;
		if (data[r][c] != 'X')
			rec(r, c + 1);
	}

	int count(vector<string> data) {
		this->data = data;
		n = data.size(), m = data[0].size();
		is.assign(n, vector<bool>(m, false));
		ans = 0;
		rec(0, 0);
		return ans;
	}
};
