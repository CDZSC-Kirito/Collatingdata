#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

vector<int> ans;

struct Point {
	int x, y;
	Point(int _x, int _y) :
			x(_x), y(_y) {
	}
	Point operator+(const Point&p) const {
		return Point(x + p.x, y + p.y);
	}
	Point operator-(const Point&p) const {
		return Point(x - p.x, y - p.y);
	}
	Point operator*(int d) const {
		return Point(x * d, y * d);
	}
	Point operator/(int d) const {
		return Point(x / d, y / d);
	}
	int det(const Point&p) const {
		return x * p.y - y * p.x;
	}
	int dot(const Point&p) const {
		return x * p.x + y * p.y;
	}
};

inline int sign(int a) {
	return a < 0 ? -1 : a > 0;
}

#define cross(p1,p2,p3) ((p2.x-p1.x)*(p3.y-p1.y)-(p3.x-p1.x)*(p2.y-p1.y))

#define crossOp(p1,p2,p3) sign(cross(p1,p2,p3))

bool crsSS(Point p1, Point p2, Point q1, Point q2) { //strict
	return crossOp(p1,p2,q1) * crossOp(p1,p2,q2) < 0 &&
			crossOp(q1,q2,p1) * crossOp(q1,q2,p2) < 0;
}

void rec(vector<int> v, int nPut) {
	if (v.size() % 2 == 0 && v.size() >= 6) {
		vector<Point> ps;
		for (int i = 0; i < v.size(); i += 2) {
			ps.push_back(Point(v[i], v[i + 1]));
		}
		int n = ps.size();
		int sign = cross(ps[0],ps[1],ps[2]);
		if (sign != 0) {
			sign = sign > 0 ? 1 : -1;
			bool chk = true;
			for (int i = 1; i < n; ++i) {
				int d = cross(ps[i],ps[(i+1)%n],ps[(i+2)%n]);
				if (d == 0 || (d > 0 ^ sign > 0)) {
					chk = false;
					break;
				}
			}
			if (chk) {
				for (int i = 0; i < n; ++i) {
					for (int j = i + 1; j < n; ++j) {
						Point p1 = ps[i], p2 = ps[(i + 1) % n];
						Point q1 = ps[j], q2 = ps[(j + 1) % n];
						if (p1.x == q1.x && p1.y == q1.y) {
							chk = false;
						}
						if (crsSS(p1, p2, q1, q2)) {
							chk = false;
						}
					}
				}
				if (chk) {
					if (ans.empty() || v.size() < ans.size()) {
						ans = v;
					}
					throw 1;
				}
			}
		}
		return;
	}

	for (int nxt = 1; nxt <= 50; ++nxt) {
		vector<int> nv = v;
		nv.push_back(nxt);
		rec(nv, nPut + 1);
	}
}

class ConvexArray {
	public:
	vector<int> getEnding(vector<int> beginning) {
		ans.clear();
		try {
			rec(beginning, 0);
		} catch (int e) {
			return vector<int>(ans.begin() + beginning.size(), ans.end());
		}
		ans.push_back(-1);
		return ans;
	}
};


double test0() {
	int t0[] = {1, 1, 2, 2};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	ConvexArray * obj = new ConvexArray();
	clock_t start = clock();
	vector <int> my_answer = obj->getEnding(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {1, 2 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {5, 6, 6};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	ConvexArray * obj = new ConvexArray();
	clock_t start = clock();
	vector <int> my_answer = obj->getEnding(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {1, 1, 1 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {1, 3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	ConvexArray * obj = new ConvexArray();
	clock_t start = clock();
	vector <int> my_answer = obj->getEnding(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {1, 1, 2, 1 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {2, 5, 5, 5, 4, 4, 3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	ConvexArray * obj = new ConvexArray();
	clock_t start = clock();
	vector <int> my_answer = obj->getEnding(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {4 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int t0[] = {1, 1, 2, 3, 3, 1, 1, 2, 3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	ConvexArray * obj = new ConvexArray();
	clock_t start = clock();
	vector <int> my_answer = obj->getEnding(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int t1[] = {-1 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<p1[0];
		for (int i=1; i<p1.size(); i++)
			cout <<", " <<p1[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<my_answer[0];
		for (int i=1; i<my_answer.size(); i++)
			cout <<", " <<my_answer[i];
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
