#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <queue>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
typedef long long int64;

bool used[53][53][53][53];

struct State {
	int64 cost;
	int next, manAt, carAt, remCap;
	bool&isUsed() {
		return used[next][manAt][carAt][remCap];
	}
};

struct cmp {
	bool operator()(const State&a, const State&b) const {
		return a.cost > b.cost;
	}
};

priority_queue<State, vector<State>, cmp> pq;

void tryUpdate(State s) {
	if (s.isUsed())
		return;
	pq.push(s);
}

class PackageDelivery {
public:
	long long minimalCost(vector<int> dest, int walkCost, int fuelCost,
			int parkingCost, int truckCapacity) {
		int n = dest.size();
		dest.push_back(0);
		sort(dest.begin(), dest.end());
		memset(used, 0, sizeof used);
		while (!pq.empty())
			pq.pop();
		tryUpdate((State) {0LL,1,0,0,truckCapacity});
		while (!pq.empty()) {
			State s = pq.top();
			pq.pop();
			if (s.isUsed())
				continue;
			s.isUsed() = true;
			int64 cost = s.cost;
			int next = s.next, manAt = s.manAt, carAt = s.carAt, remCap =
					s.remCap;
//			cout << next << " " << n << " " << manAt << " " << carAt << " "
//					<< remCap << endl;
			if (next == n + 1)
				return cost;
			if (manAt == carAt) { //we can move car ^_^
				for (int go = 0; go <= n; ++go) {
					if (go == 0) {
						tryUpdate(
								(State) {cost + 1LL*fuelCost*abs(dest[carAt]-dest[go]),next,go,go,truckCapacity});
					} else {
						tryUpdate(
								(State) {cost + 1LL*fuelCost*abs(dest[carAt]-dest[go])+parkingCost,next,go,go,remCap});
					}
				}
				if (remCap > 0) {
					if (manAt != 0)
						tryUpdate(
								(State) {cost+1LL*walkCost*abs(dest[manAt]-dest[next]),next+1,next,carAt,remCap-1});
					else
						tryUpdate(
								(State) {cost+1LL*walkCost*abs(dest[manAt]-dest[next]),next+1,next,carAt,truckCapacity});
				}
			} else { //we can only walk >_<
				if (manAt == 0)
					tryUpdate(
							(State) {cost+ 1LL * walkCost* abs(dest[manAt] - dest[next]),next + 1, next, carAt, remCap});
				tryUpdate((State) {cost,next,carAt,carAt,remCap});
				tryUpdate((State) {cost,next,0,carAt,remCap});
			}
		}
//		cout << "HERE" << endl;
	}
};

//
double test0() {
	int t0[] = { 1, 2, 3 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 3;
	int p2 = 2;
	int p3 = 3;
	int p4 = 3;
	PackageDelivery * obj = new PackageDelivery();
	clock_t start = clock();
	long long my_answer = obj->minimalCost(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 13LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = { 1, 2, 3, 4, 5 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 3;
	int p2 = 2;
	int p3 = 3;
	int p4 = 5;
	PackageDelivery * obj = new PackageDelivery();
	clock_t start = clock();
	long long my_answer = obj->minimalCost(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 23LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = { 1, 2, 3, 4, 5 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 11;
	int p2 = 5;
	int p3 = 9;
	int p4 = 2;
	PackageDelivery * obj = new PackageDelivery();
	clock_t start = clock();
	long long my_answer = obj->minimalCost(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 91LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = { 5, 5, 5 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 1;
	int p2 = 1;
	int p3 = 1;
	int p4 = 3;
	PackageDelivery * obj = new PackageDelivery();
	clock_t start = clock();
	long long my_answer = obj->minimalCost(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 6LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int t0[] = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 1;
	int p2 = 3;
	int p3 = 10;
	int p4 = 5;
	PackageDelivery * obj = new PackageDelivery();
	clock_t start = clock();
	long long my_answer = obj->minimalCost(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p5 = 53LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}
