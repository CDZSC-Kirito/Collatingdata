#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <climits>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)

using namespace std;

class RelabelingOfGraph {
public:
	vector<int> renumberVertices(vector<string> );
};

vector<int> res;
bool g[60][60] = { };
void rec(vector<int> cur, int l, int r) {
	if (cur.empty())
		return;
	int me = cur.front();
	vector<int> before, after;
	foreach(e,cur) {
		if (*e == me)
			continue;
		if (g[*e][me])
			before.push_back(*e);
		else
			after.push_back(*e);
	}
	res[me] = l + before.size();
	rec(before, l, res[me] - 1);
	rec(after, res[me] + 1, r);
}

vector<int> RelabelingOfGraph::renumberVertices(vector<string> m) {
	int n = m.size();
	memset(g, 0, sizeof g);
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < n; ++j) {
			g[i][j] = m[i][j] == '1';
		}
	}
	for (int k = 0; k < n; ++k) {
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				g[i][j] |= g[i][k] && g[k][j];
			}
		}
	}

	for (int i = 0; i < n; ++i) {
		if (g[i][i])
			return vector<int> ();
	}

	res.resize(n);
	vector<int> cur;
	for (int i = 0; i < n; ++i) {
		cur.push_back(i);
	}
	rec(cur, 0, n - 1);
	return res;
}


//Powered by [KawigiEdit] 2.0!
