#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <queue>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

map<vector<int>, int> memo;

class BinaryCodes {
	public:
	void clean(vector<int>&a) {
		sort(a.begin(), a.end());
//		copy(a.begin(), a.end(), ostream_iterator<int>(cout, " "));
//		cout << endl;
		int cur = 0;
		for (int i = 0; i < a.size(); ++i) {
			if (i < 3 || a[i] != a[i - 3])
				a[cur++] = a[i];
		}
//		cout << "->" << endl;
		a.resize(cur);
//		copy(a.begin(), a.end(), ostream_iterator<int>(cout, " "));
//		cout << endl;
	}

	int ambiguous(vector<string> code) {
		vector<int> p;
		for (int i = 0; i < code.size(); ++i) {
			if (code[i] == "")
				return 0;
			p.push_back(i << 8);
		}
		memo[p] = 0;
		queue<vector<int> > que;
		que.push(p);
		while (!que.empty()) {
			vector<int> p = que.front();
			que.pop();
			int c = memo[p];
			for (char ch = '0'; ch <= '1'; ++ch) {
				vector<int> q;
				int cnt = 0;
				for (int i = 0; i < p.size(); ++i) {
					int a = p[i] >> 8, b = p[i] & 255;
					if (code[a][b] != ch)
						continue;
					if (++b == code[a].size()) {
						++cnt;
						for (int j = 0; j < code.size(); ++j) {
							q.push_back(j << 8);
						}
					} else {
						q.push_back(a << 8 | b);
					}
				}
				if (cnt >= 3) {
					return c + 1;
				}
				clean(q);
				if (!q.empty() && !memo.count(q)) {
					memo[q] = c + 1;
					que.push(q);
				}
			}
		}
		return -1;
	}
};


double test0() {
	string t0[] = {"1","1010","01","10101"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	BinaryCodes * obj = new BinaryCodes();
	clock_t start = clock();
	int my_answer = obj->ambiguous(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"0","1"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	BinaryCodes * obj = new BinaryCodes();
	clock_t start = clock();
	int my_answer = obj->ambiguous(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"0","11","11","11"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	BinaryCodes * obj = new BinaryCodes();
	clock_t start = clock();
	int my_answer = obj->ambiguous(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"0000","001","01001","01010","01011"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	BinaryCodes * obj = new BinaryCodes();
	clock_t start = clock();
	int my_answer = obj->ambiguous(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"1","10","00"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	BinaryCodes * obj = new BinaryCodes();
	clock_t start = clock();
	int my_answer = obj->ambiguous(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {"","01101001001","111101011"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	BinaryCodes * obj = new BinaryCodes();
	clock_t start = clock();
	int my_answer = obj->ambiguous(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test6() {
	string t0[] = {"00011011","000110","11","0001","1011","00","011011"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	BinaryCodes * obj = new BinaryCodes();
	clock_t start = clock();
	int my_answer = obj->ambiguous(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 8;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	time = test6();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
