#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

const int dx[] = { -1, 0, 1, 0 }, dy[] = { 0, 1, 0, -1 };
class LateForConcert {
	public:
	double memo[110][60][60][5];
	double speedingTicket;
	double redLight;
	int n, m;
	vector<string> cityMap;

	double rec(int t, int r, int c, int dir) {
		if (r < 0 || r >= n || c < 0 || c >= m)
			return 1e100;
		char ch = cityMap[r][c];
		if (t == 0)
			return ch == 'C' ? 0 : 1e100;
		if (ch == 'C' || ch == 'X')
			return 1e100;
		double&ret = memo[t][r][c][dir];
		if (ret > -0.5)
			return ret;
		ret = 1e100;
		for (int d = 0; d < 4; ++d) {
			if (d != dir) {
				ret = min(ret, rec(t - 1, r + dx[d], c + dy[d], d + 2 & 3) + (ch == 'S' ? speedingTicket : 0) + (ch == 'T' ? redLight * 0.7 : 0));
				if (ch == 'T' && t > 1) {
					ret = min(ret, rec(t - 2, r + dx[d], c + dy[d], d + 2 & 3));
				}
			}
		}
		return ret;
	}

	double bestRoute(vector<string> cityMap, int timeLeft, double speedingTicket, double redLight) {
		memset(memo, -1, sizeof memo);
		this->speedingTicket = speedingTicket;
		this->redLight = redLight;
		this->cityMap = cityMap;
		int sr, sc;
		n = cityMap.size(), m = cityMap[0].size();
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (cityMap[r][c] == 'Y')
					sr = r, sc = c;
			}
		}
		double ret = rec(timeLeft, sr, sc, 4);
		if (ret < 1e99)
			return ret;
		else
			return -1;
	}
}
;


double test0() {
	string t0[] = {"XXXXXXXX",
 "XY...S.X",
 "XXXXXX.X",
 "C..S.TT."};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 14;
	double p2 = 60;
	double p3 = 93;
	LateForConcert * obj = new LateForConcert();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 185.1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"XX..XX",
 "Y....C"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 9;
	double p2 = 52;
	double p3 = 874;
	LateForConcert * obj = new LateForConcert();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 0.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"YTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTC"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 67;
	double p2 = 123.4;
	double p3 = 42.192;
	LateForConcert * obj = new LateForConcert();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 886.032;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"C.......",
 "SXXSXXX.",
 "TSSTY..."};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 12;
	double p2 = 1.23456789;
	double p3 = 123.456789;
	LateForConcert * obj = new LateForConcert();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = 0.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"Y..",
 "...",
 "..C"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 3;
	double p2 = 1.0;
	double p3 = 1.0;
	LateForConcert * obj = new LateForConcert();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p4 = -1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
