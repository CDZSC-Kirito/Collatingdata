#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

struct Index: public vector<int> {
	void doit() {
		sort(begin(), end());
		erase(unique(begin(), end()), end());
	}
	int get(int x) {
		return lower_bound(begin(), end(), x) - begin();
	}
};

typedef long long int64;
const int64 INF = LONG_LONG_MAX >> 2;
struct Network {
	static const int MAX_N_VETS = 100000;
	static const int MAX_N_EDGES = 1000000;

	int head[MAX_N_EDGES], dest[MAX_N_EDGES], next[MAX_N_EDGES],
			cap[MAX_N_EDGES];

	int64 cost[MAX_N_EDGES];
	int nVets, nEdges;
	int vs, vt;

	void clear() {
		nVets = 0;
		nEdges = 0;
	}

	int addV() {
		head[nVets] = -1;
		return nVets++;
	}

	void makeEdge(int s, int t, int f, int64 c) {
		int id = nEdges++;
		next[id] = head[s];
		dest[id] = t;
		cap[id] = f;
		cost[id] = c;
		head[s] = id;
	}

	void addEdge(int s, int t, int f, int64 c) {
		makeEdge(s, t, f, c);
		makeEdge(t, s, 0, -c);
	}

	int que[MAX_N_VETS], qh, qt;
	bool inQ[MAX_N_VETS];
	void inc(int&iter) {
		if (++iter == MAX_N_VETS)
			iter = 0;
	}
	void add(int x) {
		if (inQ[x])
			return;
		inQ[x] = true;
		que[qt] = x;
		inc(qt);
	}

	int get() {
		int t = que[qh];
		inQ[t] = false;
		inc(qh);
		return t;
	}
	int prev[MAX_N_VETS];
	int64 dist[MAX_N_VETS];
	int64 minCost;
	int totalFlow;

	bool spfa() {
		fill(dist, dist + nVets, INF);
		dist[vs] = 0;
		add(vs);
		while (qh != qt) {
			int u = get();
			for (int e = head[u]; e != -1; e = next[e])
				if (cap[e] > 0) {
					int v = dest[e];
					int64 ndist = dist[u] + cost[e];
					if (ndist < dist[v]) {
						prev[v] = e;
						dist[v] = ndist;
						add(v);
					}
				}
		}

		if (dist[vt] == INF)
			return false;

		int minCap = INT_MAX;
		{
			int at = vt;
			while (at != vs) {
				minCap = min(minCap, cap[prev[at]]);
				at = dest[prev[at] ^ 1];
			}
		}
		{
			int at = vt;
			while (at != vs) {
				cap[prev[at]] -= minCap;
				cap[prev[at] ^ 1] += minCap;
				at = dest[prev[at] ^ 1];
			}
		}
		minCost += minCap * dist[vt];
		totalFlow += minCap;
		return true;
	}

	int calcMinCostFlow(int _vs, int _vt) {
		vs = _vs, vt = _vt;
		minCost = 0;
		totalFlow = 0;
		qh = qt = 0;
		memset(inQ, false, sizeof inQ);
		while (spfa())
			;
		return minCost;
	}
};

class CoolRectangles {

	set<int> ux[100], uy[100];
	bool mark[62][62][62][62];

	Index idx, idy;

	bool chkX(int x, int ly, int ry) {
		int a = *ux[x].lower_bound(ly);
		return a >= ry;
	}

	bool chkY(int y, int lx, int rx) {
		int a = *uy[y].lower_bound(lx);
		return a >= rx;
	}

	Network s;

	public:
	int compress(vector<int> x1, vector<int> y1, vector<int> x2, vector<int> y2) {
		int n = x1.size();
		for (int i = 0; i < n; ++i) {
			idx.push_back(x1[i]), idx.push_back(x2[i]);
			idy.push_back(y1[i]), idy.push_back(y2[i]);
		}
		idx.doit(), idy.doit();
		for (int i = 0; i < n; ++i) {
			x1[i] = idx.get(x1[i]), x2[i] = idx.get(x2[i]);
			y1[i] = idy.get(y1[i]), y2[i] = idy.get(y2[i]);
		}

		for (int i = 0; i < 100; ++i) {
			for (int j = 0; j < 100; ++j) {
				ux[i].insert(j);
				uy[i].insert(j);
			}
		}

		for (int i = 0; i < n; ++i) {
			for (int y = y1[i]; y < y2[i]; ++y) {
				ux[x1[i]].erase(y);
				ux[x2[i]].erase(y);
			}
			for (int x = x1[i]; x < x2[i]; ++x) {
				uy[y1[i]].erase(x);
				uy[y2[i]].erase(x);
			}
		}

		s.clear();

		vector<int> rec(n);
		int vs = s.addV(), vt = s.addV();
		for (int i = 0; i < n; ++i) {
			rec[i] = s.addV();
			s.addEdge(vs, rec[i], 1, 0);
		}

		memset(mark, false, sizeof mark);

		for (int lx = idx.size() - 1; lx >= 0; --lx) {
			for (int rx = lx + 1; rx < idx.size(); ++rx) {
				for (int ly = idy.size() - 1; ly >= 0; --ly) {
					for (int ry = ly + 1; ry < idy.size(); ++ry) {
						if (!mark[lx][rx][ly][ry]) {
							if (chkX(lx, ly, ry) && chkX(rx, ly, ry) && chkY(ly, lx, rx) && chkY(ry, lx, rx)) {
								mark[lx][rx][ly][ry] = true;
								int me = s.addV();
								int v = (idx[rx] - idx[lx]) * (idy[ry] - idy[ly]);
								for (int i = 0; i < n; ++i) {
									if (x1[i] <= lx && x2[i] >= rx && y1[i] <= ly && y2[i] >= ry) {
										s.addEdge(rec[i], me, 1, v);
									}
								}
								s.addEdge(me, vt, 1, 0);
							}
						}
						if (mark[lx][rx][ly][ry]) {
							if (lx)
								mark[lx - 1][rx][ly][ry] = true;
							if (rx + 1 < idx.size())
								mark[lx][rx + 1][ly][ry] = true;
							if (ly)
								mark[lx][rx][ly - 1][ry] = true;
							if (ry + idy.size())
								mark[lx][rx][ly][ry + 1] = true;
						}
					}
				}
			}
		}

		int ans = s.calcMinCostFlow(vs, vt);
		if (s.totalFlow == n)
			return ans;
		else
			return -1;
	}
};


double test0() {
	int t0[] = {0,1,2};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,1,2};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1,2,3};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {1,2,3};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	CoolRectangles * obj = new CoolRectangles();
	clock_t start = clock();
	int my_answer = obj->compress(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {0,1};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {2,3};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {2,3};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	CoolRectangles * obj = new CoolRectangles();
	clock_t start = clock();
	int my_answer = obj->compress(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {1,0};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {1,2};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {3,4};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {4,3};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	CoolRectangles * obj = new CoolRectangles();
	clock_t start = clock();
	int my_answer = obj->compress(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {0,1,1};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,1,1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {2,3,2};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {2,3,2};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	CoolRectangles * obj = new CoolRectangles();
	clock_t start = clock();
	int my_answer = obj->compress(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int t0[] = {0,-1,-2,-3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,1,2,3};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1,2,3,4};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {7,6,5,4};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	CoolRectangles * obj = new CoolRectangles();
	clock_t start = clock();
	int my_answer = obj->compress(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 4;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	int t0[] = {1011,-647,134,-2009,875,819};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {189,-1504,1830,-1383,-319,825}
;
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {2530,1930,620,-805,1821,1054}
;
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {1419,1224,2476,203,1982,2943}
;
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	CoolRectangles * obj = new CoolRectangles();
	clock_t start = clock();
	int my_answer = obj->compress(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 2325650;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
