#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

struct NewMagicSquare {
	int mark[5][5];

	bool check() {
		//put 1..25 int order
		int atr[30], atc[30];
		memset(atr, -1, sizeof atr);
		memset(atc, -1, sizeof atc);
		for (int r = 0; r < 5; ++r) {
			for (int c = 0; c < 5; ++c) {
				if (mark[r][c] != -1)
					atr[mark[r][c]] = r, atc[mark[r][c]] = c;
			}
		}
		int pow[5];
		pow[0] = 1;
		for (int i = 1; i < 5; ++i) {
			pow[i] = pow[i - 1] * 6;
		}
		set<int> am;
		am.insert(0);
		for (int i = 1; i <= 25; ++i) {
			set<int> nam;
			for (set<int>::iterator e = am.begin(); e != am.end(); ++e) {
				int v = *e;
				int me[5];
				int x = v;
				for (int j = 0; j < 5; ++j) {
					me[j] = x % 6;
					x /= 6;
				}
				for (int j = 0; j < 5; ++j) {
					if (me[j] < 5) {
						if (atr[i] != -1) {
							if (atr[i] != j || atc[i] != me[j])
								continue;
						}
						nam.insert(v + pow[j]);
					}
				}
			}
			am = nam;
		}
		return !am.empty();
	}

	vector<string> completeTheSquare(vector<string> square) {
		bool used[30] = { };
		for (int r = 0; r < 5; ++r) {
			istringstream sin(square[r]);
			string s;
			for (int c = 0; c < 5; ++c) {
				sin >> s;
				if (s == "??")
					mark[r][c] = -1;
				else {
					mark[r][c] = (s[0] - '0') * 10 + (s[1] - '0');
					used[mark[r][c]] = true;
				}
			}
		}

		if (!check())
			return vector<string>();

		for (int r = 0; r < 5; ++r) {
			for (int c = 0; c < 5; ++c) {
				if (mark[r][c] == -1) {
					for (int i = 1; i <= 25; ++i) {
						if (!used[i]) {
							mark[r][c] = i;
							if (check()) {
								used[i] = true;
								break;
							}
						}
					}
				}
			}
		}

		vector<string> ret;
		for (int r = 0; r < 5; ++r) {
			string s = "";
			for (int c = 0; c < 5; ++c) {
				char buf[10];
				sprintf(buf, "%02d", mark[r][c]);
				s += buf;
				if (c < 4)
					s += " ";
			}
			ret.push_back(s);
		}
		return ret;
	}
};



double test0() {
	string t0[] = {"?? ?? ?? ?? ??", 
 "?? ?? ?? ?? ??", 
 "?? ?? ?? ?? ??", 
 "?? ?? ?? ?? ??", 
 "?? ?? ?? ?? ??"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	NewMagicSquare * obj = new NewMagicSquare();
	clock_t start = clock();
	vector <string> my_answer = obj->completeTheSquare(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"01 02 03 04 05", "06 07 08 09 10", "11 12 13 14 15", "16 17 18 19 20", "21 22 23 24 25" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"?? ?? 20 ?? ??", 
 "?? ?? ?? ?? ??", 
 "?? ?? ?? 05 ??", 
 "?? ?? ?? ?? ??", 
 "?? ?? ?? ?? ??"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	NewMagicSquare * obj = new NewMagicSquare();
	clock_t start = clock();
	vector <string> my_answer = obj->completeTheSquare(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"01 06 20 21 22", "07 08 09 10 11", "02 03 04 05 12", "13 14 15 16 17", "18 19 23 24 25" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"?? ?? ?? ?? ??", 
 "?? ?? ?? ?? 24", 
 "?? ?? ?? ?? ??", 
 "?? ?? ?? ?? ??", 
 "21 ?? ?? ?? ??"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	NewMagicSquare * obj = new NewMagicSquare();
	clock_t start = clock();
	vector <string> my_answer = obj->completeTheSquare(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	vector <string> p1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"?? ?? 15 ?? ??", 
 "02 ?? ?? ?? ??", 
 "?? ?? ?? 07 ??", 
 "?? ?? 16 ?? ??", 
 "?? ?? ?? ?? 21"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	NewMagicSquare * obj = new NewMagicSquare();
	clock_t start = clock();
	vector <string> my_answer = obj->completeTheSquare(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t1[] = {"01 03 15 17 18", "02 08 09 10 22", "04 05 06 07 23", "11 12 16 24 25", "13 14 19 20 21" };
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p1.size() > 0) {
		cout <<"\""<<p1[0]<<"\"";
		for (int i=1; i<p1.size(); i++)
			cout <<", \"" <<p1[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p1) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
