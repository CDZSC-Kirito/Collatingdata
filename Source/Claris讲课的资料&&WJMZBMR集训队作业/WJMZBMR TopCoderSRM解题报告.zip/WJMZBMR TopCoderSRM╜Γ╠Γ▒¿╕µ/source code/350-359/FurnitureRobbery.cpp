#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <queue>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
int n, m;

class FurnitureRobbery {
	public:
	void norm(vector<int>&a) {
		sort(a.begin() + 1, a.end());
	}

	int leastPushes(vector<string> plan) {
		n = plan.size(), m = plan[0].size();
		int LEFT = 0, RIGHT = 0, UP = 0, DOWN = 0;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				int msk = 1 << (r * m + c);
				if (!r)
					UP |= msk;
				if (r == n - 1)
					DOWN |= msk;
				if (c == 0)
					LEFT |= msk;
				if (c == m - 1)
					RIGHT |= msk;
			}
		}

		vector<int> init;
		for (char a = 'A'; a <= 'Z'; ++a) {
			int msk = 0;
			for (int r = 0; r < n; ++r) {
				for (int c = 0; c < m; ++c) {
					if (plan[r][c] == a)
						msk |= 1 << (r * m + c);
				}
			}
			if (msk)
				init.push_back(msk);
		}
		norm(init);
		set<vector<int> > visited;
		queue<vector<int> > que;
		queue<int> qc;

		que.push(init);
		qc.push(0);
		visited.insert(init);

		while (!que.empty()) {
			vector<int> v = que.front();
			que.pop();
			int cost = qc.front();
			qc.pop();
			if (v[0] & UP) {
				return cost;
			}
			int all = 0;
			for (vector<int>::iterator e = v.begin(); e != v.end(); ++e) {
				all |= *e;
			}

			for (int i = 0; i < v.size(); ++i) {
				int msk = v[i];
				int other = all ^ msk;
				//move up
				if (!(msk & UP)) {
					int nmsk = msk >> m;
					if (!(nmsk & other)) {
						vector<int> nv = v;
						nv[i] = nmsk;
						norm(nv);
						if (visited.insert(nv).second) {
							que.push(nv);
							qc.push(cost + 1);
						}
					}
				}
				//move down
				if (!(msk & DOWN)) {
					int nmsk = msk << m;
					if (!(nmsk & other)) {
						vector<int> nv = v;
						nv[i] = nmsk;
						norm(nv);
						if (visited.insert(nv).second) {
							que.push(nv);
							qc.push(cost + 1);
						}
					}
				}
				//move left
				if (!(msk & LEFT)) {
					int nmsk = msk >> 1;
					if (!(nmsk & other)) {
						vector<int> nv = v;
						nv[i] = nmsk;
						norm(nv);
						if (visited.insert(nv).second) {
							que.push(nv);
							qc.push(cost + 1);
						}
					}
				}
				//move right
				if (!(msk & RIGHT)) {
					int nmsk = msk << 1;
					if (!(nmsk & other)) {
						vector<int> nv = v;
						nv[i] = nmsk;
						norm(nv);
						if (visited.insert(nv).second) {
							que.push(nv);
							qc.push(cost + 1);
						}
					}
				}
			}
		}

		return -1;
	}
};


double test0() {
	string t0[] = {"......",
 ".BBB.X",
 ".B.B.X",
 "DDCC.Y",
 "..AAAY"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FurnitureRobbery * obj = new FurnitureRobbery();
	clock_t start = clock();
	int my_answer = obj->leastPushes(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 13;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"......",
 ".BBB.X",
 ".B.B.X",
 "....YY",
 "..AAAY"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FurnitureRobbery * obj = new FurnitureRobbery();
	clock_t start = clock();
	int my_answer = obj->leastPushes(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 11;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"...C.C",
 "BBBCCC",
 "B.B...",
 ".XX..Y",
 "..AAAY"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FurnitureRobbery * obj = new FurnitureRobbery();
	clock_t start = clock();
	int my_answer = obj->leastPushes(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 13;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"......",
 "ZBBBXY",
 "ZBBBXY",
 "EAAACC",
 "E.DDCC"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FurnitureRobbery * obj = new FurnitureRobbery();
	clock_t start = clock();
	int my_answer = obj->leastPushes(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 20;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"......",
 "BBB...",
 "BCBC..",
 ".CCC.Y",
 "..AAAY"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FurnitureRobbery * obj = new FurnitureRobbery();
	clock_t start = clock();
	int my_answer = obj->leastPushes(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 16;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {".C",
 "BC",
 "BC",
 "B.",
 "AA"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	FurnitureRobbery * obj = new FurnitureRobbery();
	clock_t start = clock();
	int my_answer = obj->leastPushes(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
