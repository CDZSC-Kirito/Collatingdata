#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class EscapeTheJail {
	public:
	vector<string> jail;
	int n, m;
	vector<vector<bool> > vis;

	void dfs(int r, int c) {
		if (r < 0 || r >= n || c < 0 || c >= m)
			return;
		if (vis[r][c])
			return;
		vis[r][c] = true;
		if (jail[r][c] == '#')
			return;
		if (jail[r][c] == '$')
			throw 1;
		for (int nr = r - 1; nr <= r + 1; ++nr) {
			for (int nc = c - 1; nc <= c + 1; ++nc)
				if (nr == r ^ nc == c) {
					dfs(nr, nc);
				}
		}
	}

	double findExit(vector<string> jail) {
		this->jail = jail;
		n = jail.size(), m = jail[0].size();
		int sr, sc;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				if (jail[r][c] == '@') {
					jail[r][c] = '.';
					sr = r, sc = c;
				}
			}
		}
		vis.assign(n, vector<bool>(m, false));
		try {
			dfs(sr, sc);
		} catch (int e) {
			double am[300] = { };
			vector<int> adj[300];
			for (int r = 0; r < n; ++r) {
				for (int c = 0; c < m; ++c) {
					if (jail[r][c] == '.') {
						int id = r * m + c;
						for (int nr = r - 1; nr <= r + 1; ++nr) {
							for (int nc = c - 1; nc <= c + 1; ++nc) {
								if (nr == r ^ nc == c) {
									if (nr >= 0 && nr < n && nc >= 0 && nc < m) {
										if (jail[nr][nc] != '#')
											adj[id].push_back(nr * m + nc);
									}
								}
							}
						}
					}
				}
			}

			for (int iter = 0; iter < 200000; ++iter) {
				for (int i = 0; i < n * m; ++i) {
					if (adj[i].empty())
						continue;
					am[i] = 0;
					for (vector<int>::iterator e = adj[i].begin(); e != adj[i].end(); ++e) {
						am[i] += am[*e];
					}
					am[i] = am[i] / adj[i].size() + 1;
				}
			}
			return am[sr * m + sc];
		}
		return -1;
	}
};


double test0() {
	string t0[] = {"@$"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	EscapeTheJail * obj = new EscapeTheJail();
	clock_t start = clock();
	double my_answer = obj->findExit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = 1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"$.",
 ".@"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	EscapeTheJail * obj = new EscapeTheJail();
	clock_t start = clock();
	double my_answer = obj->findExit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = 4.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"@..$"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	EscapeTheJail * obj = new EscapeTheJail();
	clock_t start = clock();
	double my_answer = obj->findExit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = 9.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"@#",
 "#$"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	EscapeTheJail * obj = new EscapeTheJail();
	clock_t start = clock();
	double my_answer = obj->findExit(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = -1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
