#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

class PlaneDivision {
public:
	int howManyFiniteParts(vector<int> , vector<int> , vector<int> ,
			vector<int> );
};

struct Point {
	double x, y;
	Point() {
	}
	Point(double _x, double _y) :
		x(_x), y(_y) {
	}
	Point operator+(const Point&p) const {
		return Point(x + p.x, y + p.y);
	}
	Point operator-(const Point&p) const {
		return Point(x - p.x, y - p.y);
	}
	Point operator*(double d) const {
		return Point(x * d, y * d);
	}
	Point operator/(double d) const {
		return Point(x / d, y / d);
	}
	double det(const Point&p) const {
		return x * p.y - y * p.x;
	}
	double dot(const Point&p) const {
		return x * p.x + y * p.y;
	}
	Point rot90() const {
		return Point(-y, x);
	}
	void read() {
		scanf("%lf%lf", &x, &y);
	}
	void write() const {
		printf("%lf %lf", x, y);
	}
};

#define cross(p1,p2,p3) ((p2.x-p1.x)*(p3.y-p1.y)-(p3.x-p1.x)*(p2.y-p1.y))

const double EPS = 1e-8;
inline int sign(double a) {
	return a < -EPS ? -1 : a > EPS;
}

#define crossOp(p1,p2,p3) (sign(cross(p1,p2,p3)))

Point getIsSS(Point p1, Point p2, Point q1, Point q2) {
	double a1 = cross(q1,q2,p1), a2 = -cross(q1,q2,p2);
	return (p1 * a2 + p2 * a1) / (a1 + a2);
}

bool checkIsSS(Point p1, Point p2, Point q1, Point q2) {
	double a1 = cross(q1,q2,p1), a2 = -cross(q1,q2,p2);
	return sign(a1 + a2) != 0;
}

bool operator<(Point p1, Point p2) {
	int c = sign(p1.x - p2.x);
	if (c != 0)
		return c == -1;
	return sign(p1.y - p2.y) == -1;
}

bool operator==(Point p1, Point p2) {
	return sign(p1.x - p2.x) == 0 && sign(p1.y - p2.y) == 0;
}

int PlaneDivision::howManyFiniteParts(vector<int> x1, vector<int> y1, vector<
		int> x2, vector<int> y2) {
	set<Point> pSet;
	int n=x1.size();
	vector<Point> p1,p2;
	for (int i = 0; i < n; ++i) {
		p1.push_back(Point(x1[i],y1[i]));
		p2.push_back(Point(x2[i],y2[i]));
	}
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < i; ++j) {
			if(checkIsSS(p1[i],p2[i],p1[j],p2[j]))
				pSet.insert(getIsSS(p1[i],p2[i],p1[j],p2[j]));
		}
	}

	int V=pSet.size();
	if(V == 0)
		return 0;
	++V;
	int E=0;
	for (int i = 0; i < n; ++i) {
		set<Point> edgePoints;
		for (int j = 0; j < n; ++j) {
			if(j == i) continue;
			if(checkIsSS(p1[i],p2[i],p1[j],p2[j]))
				edgePoints.insert(getIsSS(p1[i],p2[i],p1[j],p2[j]));
		}
		E+=edgePoints.size()+1;
	}

	int F=2+E-V;
	return F-2*n;
}


//Powered by [KawigiEdit] 2.0!
