#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
#define VAL(a,b) __typeof(b) a=b
using namespace std;

typedef long long int64;

const int MOD = int(1e6) + 1;

struct Int {
	int x;
	Int() :
			x(0) {
	}
	Int(int _x) :
			x(_x) {
		x %= MOD;
		if (x < 0)
			x += MOD;
	}
	Int(int64 _x) :
			x(_x) {
		x %= MOD;
		if (x < 0)
			x += MOD;
	}
	static Int get(int x) {
		Int a;
		a.x = x;
		return a;
	}

	Int operator+(const Int&o) const {
		int t = x + o.x;
		if (t >= MOD)
			t -= MOD;
		return get(t);
	}
	Int operator*(const Int&o) const {
		return get(1LL * x * o.x % MOD);
	}
	Int operator-(const Int&o) const {
		int t = x - o.x;
		if (t < 0)
			t += MOD;
		return get(t);
	}
	Int operator/(const Int&o) const {
		return (*this) * o.inv();
	}
	Int&operator+=(const Int&o) {
		return (*this) = *this + o;
	}
	Int&operator-=(const Int&o) {
		return (*this) = *this - o;
	}
	Int&operator*=(const Int&o) {
		return (*this) = *this * o;
	}
	Int&operator/=(const Int&o) {
		return (*this) = *this / o;
	}

	Int power(int64 n) const {
		if (!n)
			return get(1);
		const Int&a = *this;
		if (n & 1)
			return power(n - 1) * a;
		else
			return (a * a).power(n >> 1);
	}

	Int inv() const {
		return power(MOD - 2);
	}
};

class RooksPlacement {
	public:

	int countPlacements(int N, int M, int K) {

		static Int dp[2][102][52][52] = { }; //i,rem,c0,c1
		memset(dp, 0, sizeof dp);

		dp[0][K][M][0] = 1;
		for (int i = 0; i < N; ++i) {
			int cur = i & 1, next = i + 1 & 1;
			memset(dp[next], 0, sizeof dp[next]);

			for (int rem = 0; rem <= K; ++rem) {
				for (int c0 = 0; c0 <= M; ++c0) {
					for (int c1 = 0; c1 <= M; ++c1) {
						Int c = dp[cur][rem][c0][c1];
						if (c.x == 0)
							continue;
						//put nonthing
						dp[next][rem][c0][c1] += c;
						//put one rock
						if (rem >= 1) {
							if (c0 >= 1)
								dp[next][rem - 1][c0 - 1][c1 + 1] += c * c0;
							if (c1 >= 1)
								dp[next][rem - 1][c0][c1 - 1] += c * c1;
						}
						//put two rocks
						if (rem >= 2) {
							if (c0 >= 2)
								dp[next][rem - 2][c0 - 2][c1] += c * (1LL * c0 * (c0 - 1) / 2);
						}
					}
				}
			}
		}
		Int ans = 0;
		for (int c0 = 0; c0 <= M; ++c0) {
			for (int c1 = 0; c1 <= M; ++c1) {
				ans += dp[N & 1][0][c0][c1];
			}
		}
		return ans.x;
	}
};


double test0() {
	int p0 = 4;
	int p1 = 5;
	int p2 = 2;
	RooksPlacement * obj = new RooksPlacement();
	clock_t start = clock();
	int my_answer = obj->countPlacements(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 190;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 2;
	int p1 = 3;
	int p2 = 3;
	RooksPlacement * obj = new RooksPlacement();
	clock_t start = clock();
	int my_answer = obj->countPlacements(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 6;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 6;
	int p1 = 7;
	int p2 = 20;
	RooksPlacement * obj = new RooksPlacement();
	clock_t start = clock();
	int my_answer = obj->countPlacements(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 23;
	int p1 = 37;
	int p2 = 39;
	RooksPlacement * obj = new RooksPlacement();
	clock_t start = clock();
	int my_answer = obj->countPlacements(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 288688;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
