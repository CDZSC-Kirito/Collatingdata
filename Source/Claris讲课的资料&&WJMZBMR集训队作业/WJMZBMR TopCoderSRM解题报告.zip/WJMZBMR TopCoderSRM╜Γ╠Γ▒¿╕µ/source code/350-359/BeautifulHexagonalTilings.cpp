#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
int f[40][40];
bool BD[40][40];
int nV;
vector<int> adj[1000];
bool bd[1000];
int nw[1000], nb[1000];
int ans;
int B, W; //black,white
int state[1000]; //0,black:1,white:2

bool check(int u) {
	if (bd[u])
		return true;
	int rem = 6 - nw[u] - nb[u];
	int st = state[u];
	if (st != 2 && nb[u] <= B && nb[u] + rem >= B)
		return true;
	if (st != 1 && nw[u] <= W && nw[u] + rem >= W)
		return true;
	return false;
}

void rec(int at) {
	if (at == nV) {
		++ans;
		return;
	}
	//put it black
	state[at] = 1;
	if (check(at)) {
		bool chk = true;
		for (vector<int>::iterator e = adj[at].begin(); e != adj[at].end(); ++e) {
			nb[*e]++;
			if (!check(*e))
				chk = false;
		}
		if (chk) {
			rec(at + 1);
		}
		for (vector<int>::iterator e = adj[at].begin(); e != adj[at].end(); ++e) {
			nb[*e]--;
		}
	}
	state[at] = 0;
	//put it white
	state[at] = 2;
	if (check(at)) {
		bool chk = true;
		for (vector<int>::iterator e = adj[at].begin(); e != adj[at].end(); ++e) {
			nw[*e]++;
			if (!check(*e))
				chk = false;
		}
		if (chk) {
			rec(at + 1);
		}
		for (vector<int>::iterator e = adj[at].begin(); e != adj[at].end(); ++e) {
			nw[*e]--;
		}
	}
	state[at] = 0;
}

class BeautifulHexagonalTilings {
	public:
	int howMany(vector<int> s, int a, int b) {
		int x = 20, y = 20;
		memset(f, -1, sizeof f);
		memset(BD, false, sizeof BD);
		int dx[] = { -1, 0, 1, 1, 0, -1 };
		int dy[] = { 0, 1, 1, 0, -1, -1 };
		for (int i = 0; i < s.size(); ++i) {
			for (int k = 0; k < s[i] - 1; ++k) {
				f[x][y] = 1;
				BD[x][y] = true;
				x += dx[i], y += dy[i];
			}
		}
		nV = 0;
		memset(bd, false, sizeof bd);
		for (int i = 0; i < 40; ++i) {
			int l = INT_MAX, r = INT_MIN;
			for (int k = 0; k < 40; ++k) {
				if (f[i][k] != -1) {
					l = min(l, k);
					r = max(r, k);
				}
			}
			for (int k = l; k <= r; k++) {
				f[i][k] = nV;
				if (BD[i][k])
					bd[nV] = true;
				nV++;
			}
		}
		for (int i = 0; i < nV; ++i) {
			adj[i].clear();
		}

		for (int i = 0; i < 40; ++i) {
			for (int j = 0; j < 40; ++j) {
				if (f[i][j] != -1) {
					int v = f[i][j];
#define ADD(x) \
	if(x!=-1)\
		adj[v].push_back(x);
					ADD(f[i-1][j]);
					ADD(f[i+1][j]);
					ADD(f[i][j+1]);
					ADD(f[i][j-1]);
					ADD(f[i+1][j+1]);
					ADD(f[i-1][j-1]);
#undef ADD
				}
			}
		}

		memset(nw, 0, sizeof nw);
		memset(nb, 0, sizeof nb);
		ans = 0;
		B = a, W = b;
		memset(state, 0, sizeof state);
		rec(0);
		return ans;
	}
};


double test0() {
	int t0[] = {2,2,2,2,2,2};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 6;
	int p2 = 6;
	BeautifulHexagonalTilings * obj = new BeautifulHexagonalTilings();
	clock_t start = clock();
	int my_answer = obj->howMany(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {6,6,6,6,6,6};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 6;
	int p2 = 6;
	BeautifulHexagonalTilings * obj = new BeautifulHexagonalTilings();
	clock_t start = clock();
	int my_answer = obj->howMany(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {2,2,2,2,2,2};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 2;
	int p2 = 2;
	BeautifulHexagonalTilings * obj = new BeautifulHexagonalTilings();
	clock_t start = clock();
	int my_answer = obj->howMany(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 30;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {4,4,3,5,3,4};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int p1 = 4;
	int p2 = 1;
	BeautifulHexagonalTilings * obj = new BeautifulHexagonalTilings();
	clock_t start = clock();
	int my_answer = obj->howMany(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 213;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
