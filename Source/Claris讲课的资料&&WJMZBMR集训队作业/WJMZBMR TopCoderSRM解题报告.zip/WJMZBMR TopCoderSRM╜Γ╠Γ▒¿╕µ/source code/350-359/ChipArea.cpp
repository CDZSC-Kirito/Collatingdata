#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>

using namespace std;

const int MOD = 323537;

class ChipArea {
public:
	double maxArea(int, int);
};

double calc(vector<int> x,vector<int> y){
	vector<int> down(MOD+1,-1);
	vector<int> up=down;
	vector<int> where=down;
	vector<pair<int,int> > ps;
	int n=x.size();
	for (int i = 0; i < n; ++i) {
		ps.push_back(make_pair(x[i],y[i]));
	}
	sort(ps.begin(),ps.end());
	for (int i = 0; i < n; ++i) {
		x[i]=ps[i].first;
		y[i]=ps[i].second;
	}
	set<int> ys;
	up[0]=0;down[0]=MOD;
	where[0]=0;ys.insert(0);
	up[MOD]=0;down[MOD]=MOD;
	where[MOD]=0;ys.insert(MOD);
	double ret=0;
	for (int i = 0; i < n; ++i) {
		int cx=x[i],cy=y[i];
		int j=*(ys.upper_bound(cy));
		for(;;){
			ret = max(ret,(cx-where[j])*1.0*(down[j]-up[j]));
			up[j]=cy;
			if(down[j] == MOD)
				break;
			j=down[j];
		}
		j=*(--ys.lower_bound(cy));
		for(;;){
			ret = max(ret,(cx-where[j])*1.0*(down[j]-up[j]));
			down[j]=cy;
			if(up[j] == 0)
				break;
			j=up[j];
		}
		ys.insert(cy);
		where[cy]=cx;
		up[cy]=0;
		down[cy]=MOD;
	}

	for (int i = 0; i <= MOD; ++i) {
		if(where[i] >= 0){
			ret = max(ret,(MOD-where[i])*1.0*(down[i]-up[i]));
		}
	}
	return ret/MOD/MOD;
}

double ChipArea::maxArea(int skip, int n) {
	vector<int> x,y;
	int R=1;
	for (int i = 0; i < skip; ++i) {
		(R*=111)%=MOD;
	}
	for (int i = 0; i < n; ++i) {
		(R*=111)%=MOD;x.push_back(R);
		(R*=111)%=MOD;y.push_back(R);
	}
	return max(calc(x,y),calc(y,x));
}


//Powered by [KawigiEdit] 2.0!
