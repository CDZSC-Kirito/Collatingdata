#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

template<class Flow>
struct Maxflow {
	struct Edge {
		int t;
		Flow c;
		Edge*n, *r;
		Edge(int _t, Flow _c, Edge*_n) :
				t(_t), c(_c), n(_n) {
		}
	};
	vector<Edge*> E;

	int addV() {
		E.push_back((Edge*) 0);
		return E.size() - 1;
	}

	void clear() {
		E.clear();
	}

	Edge* makeEdge(int s, int t, Flow c) {
		return E[s] = new Edge(t, c, E[s]);
	}

	void addEdge(int s, int t, Flow c) {
		Edge*e1 = makeEdge(s, t, c), *e2 = makeEdge(t, s, 0);
		e1->r = e2, e2->r = e1;
	}

	int calcMaxFlow(int vs, int vt) {
		int nV = E.size();
		Flow totalFlow = 0;
		Flow MAX_FLOW = numeric_limits<Flow>::max();

		vector<Flow> am(nV, 0);
		vector<int> h(nV, 0), cnt(nV + 1, 0);
		vector<Edge*> prev(nV, (Edge*) 0), cur(nV, (Edge*) 0);
		cnt[0] = nV;

		int u = vs;
		Edge*e;
		am[u] = MAX_FLOW;
		while (h[vs] < nV) {
			for (e = cur[u]; e; e = e->n)
				if (e->c > 0 && h[u] == h[e->t] + 1)
					break;
			if (e) {
				int v = e->t;
				cur[u] = prev[v] = e;
				am[v] = min(am[u], e->c);
				u = v;
				if (u == vt) {
					Flow by = am[u];
					while (u != vs) {
						prev[u]->c -= by;
						prev[u]->r->c += by;
						u = prev[u]->r->t;
					}
					totalFlow += by;
					am[u] = MAX_FLOW;
				}
			} else {
				if (!--cnt[h[u]])
					break;
				h[u] = nV;
				for (e = E[u]; e; e = e->n)
					if (e->c > 0 && h[e->t] + 1 < h[u]) {
						h[u] = h[e->t] + 1;
						cur[u] = e;
					}
				++cnt[h[u]];
				if (u != vs)
					u = prev[u]->r->t;
			}
		}

		return totalFlow;
	}

	~Maxflow() {
		for (int i = 0; i < E.size(); ++i) {
			for (Edge*e = E[i]; e;) {
				Edge*ne = e->n;
				delete e;
				e = ne;
			}
		}
	}
};

class SharksDinner {
	public:
	int minSurvivors(vector<int> size, vector<int> speed, vector<int> intelligence) {
		int n = size.size();
		vector<vector<int> > sharks(n);
		for (int i = 0; i < n; ++i) {
			sharks[i].push_back(size[i]), sharks[i].push_back(speed[i]), sharks[i].push_back(intelligence[i]);
		}

		Maxflow<int> s;
		int vs = s.addV(), vt = s.addV();
		vector<int> in(n), out(n);
		for (int i = 0; i < n; ++i) {
			in[i] = s.addV(), out[i] = s.addV();
			s.addEdge(in[i], vt, 1);
			s.addEdge(vs, out[i], 2);
		}

		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				vector<int>&vi = sharks[i], &vj = sharks[j];
				if (vi[0] >= vj[0] && vi[1] >= vj[1] && vi[2] >= vj[2]) {
					if (vi == vj && i >= j)
						continue;
					s.addEdge(out[i], in[j], 1);
				}
			}
		}

		return n - s.calcMaxFlow(vs, vt);
	}
};


double test0() {
	int t0[] = { 1, 4, 3 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = { 2, 3, 1 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = { 1, 5, 2 };
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	SharksDinner * obj = new SharksDinner();
	clock_t start = clock();
	int my_answer = obj->minSurvivors(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = { 4, 10, 5, 8, 8 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = { 5, 10, 7, 7, 10 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = { 5, 8, 10, 7, 3 };
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	SharksDinner * obj = new SharksDinner();
	clock_t start = clock();
	int my_answer = obj->minSurvivors(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = { 1, 2, 3, 4, 100 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = { 4, 3, 2, 1, 100 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = { 2, 4, 1, 3, 100 };
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	SharksDinner * obj = new SharksDinner();
	clock_t start = clock();
	int my_answer = obj->minSurvivors(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = { 4, 4, 4, 4 };
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = { 3, 3, 3, 3 };
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = { 8, 8, 8, 8 };
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	SharksDinner * obj = new SharksDinner();
	clock_t start = clock();
	int my_answer = obj->minSurvivors(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
