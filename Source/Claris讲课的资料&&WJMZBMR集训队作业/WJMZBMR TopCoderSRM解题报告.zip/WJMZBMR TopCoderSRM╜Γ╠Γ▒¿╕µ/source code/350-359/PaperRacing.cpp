#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <queue>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
short dist[50][50][103][103];

struct Point {
	int r, c;
};

struct State {
	int r, c;
	int vr, vc;
	short&dist() {
		return ::dist[r][c][vr + 51][vc + 51];
	}
};

int n, m;
Point sta, tar;
bool bad[52][52];
queue<State> que;

void add(State s, int c) {
	if (s.dist() == -1) {
		s.dist() = c;
		que.push(s);
	}
}

int sign(int x) {
	return x < 0 ? -1 : x > 0;
}

bool moveIt(int r, int c, int vr, int vc, int dist) {
	int fr = r + vr, fc = c + vc;
	int dr = sign(vr), dc = sign(vc);
	int A = -vc;
	int B = vr;
	int C = -(A * (r * 2 + 1) + B * (c * 2 + 1));
	//Ax+By+C=0
	int sr = sign(A * (r * 2 + 1 + dr) + B * (c * 2 + 1) + C);
	int sc = sign(A * (r * 2 + 1) + B * (c * 2 + 1 + dc) + C);
	for (;;) {
		if (r < 0 || r >= n || c < 0 || c >= m || bad[r][c])
			return false;
		if (r == fr && c == fc)
			break;
		if (dr == 0) {
			c += dc;
			if (r == tar.r && c == tar.c)
				return true;
		} else if (dc == 0) {
			r += dr;
			if (r == tar.r && c == tar.c)
				return true;
		} else {
			int s = sign(A * (r * 2 + 1 + dr) + B * (c * 2 + 1 + dc) + C);
			if (s == sr) {
				c += dc;
				if (r == tar.r && c == tar.c)
					return true;
			} else if (s == sc) {
				r += dr;
				if (r == tar.r && c == tar.c)
					return true;
			} else {
				if (r + dr == tar.r && c == tar.c)
					return true;
				if (r == tar.r && c + dc == tar.c)
					return true;
				r += dr, c += dc;
				if (r == tar.r && c == tar.c)
					return true;
			}
		}
	}
	add((State) {r, c, vr, vc}, dist);
	return false;
}

class PaperRacing {
public:
	int minMoves(vector<string> track, int vRow, int vCol) {
		n = track.size(), m = track[0].size();
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				bad[r][c] = track[r][c] == 'X';
				if (track[r][c] == 'S') {
					sta = (Point) {r,c};
				}
				if (track[r][c] == 'F') {
					tar = (Point) {r,c};
				}
			}
		}
		cout << sizeof(dist) / (1.0 * (1 << 20)) << endl;
		memset(dist, -1, sizeof dist);
		while (!que.empty())
			que.pop();
		add((State) {sta.r,sta.c,vRow,vCol}, 0);
		while (!que.empty()) {
			State s = que.front();
			que.pop();
			int d = s.dist();
			for (int nvr = s.vr - 1; nvr <= s.vr + 1; ++nvr) {
				for (int nvc = s.vc - 1; nvc <= s.vc + 1; ++nvc) {
					if (moveIt(s.r, s.c, nvr, nvc, d + 1))
						return d + 1;
				}
			}
		}

		return -1;
	}
};

double test0() {
	string t0[] = {"S.................F"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 0;
	int p2 = 0;
	PaperRacing * obj = new PaperRacing();
	clock_t start = clock();
	int my_answer = obj->minMoves(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 6;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"S.................F"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 0;
	int p2 = 8;
	PaperRacing * obj = new PaperRacing();
	clock_t start = clock();
	int my_answer = obj->minMoves(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"FX",
 "X.",
 ".X",
 "X.",
 "SX"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 1;
	int p2 = 0;
	PaperRacing * obj = new PaperRacing();
	clock_t start = clock();
	int my_answer = obj->minMoves(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 8;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"S..X",
 "X..X",
 "XX.X",
 "XXFX"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 50;
	int p2 = 50;
	PaperRacing * obj = new PaperRacing();
	clock_t start = clock();
	int my_answer = obj->minMoves(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"S.......X.........F"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int p1 = 0;
	int p2 = 0;
	PaperRacing * obj = new PaperRacing();
	clock_t start = clock();
	int my_answer = obj->minMoves(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
