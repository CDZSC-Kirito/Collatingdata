/*
 * BubbleSortIterations.cpp
 *
 *  Created on: 2011-10-30
 *      Author: mac
 */
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <climits>
#include <numeric>
#include <vector>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
#define REP(i,n) for(int i=0;i<n;++i)
using namespace std;

struct BubbleSortIterations {
	int numIterations(vector<int> X, vector<int> Y, int L0, int M, int n) {
		vector<int> a(n);
		a[0] = L0;
		for (int i = 1; i < n; ++i) {
			a[i] = (1LL * a[i - 1] * X[i % X.size()] + Y[i % Y.size()]) % M;
		}
		vector<pair<int, int> > ps(n);
		for (int i = 0; i < n; ++i) {
			ps[i] = make_pair(a[i], i);
		}
		sort(ps.begin(), ps.end());
		int ret = 0;
		for (int i = 0; i < n; ++i) {
			ret = max(ret, ps[i].second - i);
		}
		return ret;
	}
};

