#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
int D[30][30];
bool G[30][30];
int f[30];
int n, m;
vector<int> S, T, path;
map<vector<int>, int> memo;

class EscapeArtist {
	public:
	double ans;

	int rec(int dep, int at, int vt) {
		if (dep < path.size() && at == path[dep])
			return 0;
		if (at == vt) {
			for (int i = dep; i < path.size(); ++i) {
				if (at == path[i])
					return 0;
			}
			return 1;
		}
		int&ret = f[at];
		if (ret != -1)
			return ret;
		ret = 0;
		for (int i = 0; i < n; ++i) {
			if (G[at][i] && D[at][i] + D[i][vt] == D[at][vt]) {
				if (dep + 1 < path.size() && i == path[dep] && at == path[dep + 1]) //meet in middle
					continue;
				ret += rec(dep + 1, i, vt);
			}
		}
		return ret;
	}

	int eval(int vs, int vt) {
		vector<int> key = path;
		key.push_back(vs), key.push_back(vt);
		if (memo.count(key))
			return memo[key];
		int&ret = memo[key];
		memset(f, -1, sizeof f);
		return ret = rec(0, vs, vt);
	}

	double calc(int vs, int vt) {
		vector<int> t = path;
		path.pop_back();
		int total = eval(vs, vt);
		path = t;
		if (!total)
			return 1;
		return 1.0 * eval(vs, vt) / total;
	}

	void dfs(int vs, int vt, double p) {
		if (p <= ans)
			return;
		if (vs == vt) {
			ans = max(ans, p);
			return;
		}
		for (int i = 0; i < n; ++i) {
			if (G[vs][i] && D[vs][i] + D[i][vt] == D[vs][vt]) {
				path.push_back(i);
				double np = p;
				for (int j = 0; j < m; ++j) {
					np *= calc(S[j], T[j]);
				}
				dfs(i, vt, np);
				path.pop_back();
			}
		}
	}

	double bestRoute(vector<string> corridors, vector<int> agentStart, vector<int> agentTarget, int start, int finish) {
		n = corridors.size();
		for (int i = 0; i < n; ++i) {
			for (int j = 0; j < n; ++j) {
				G[i][j] = corridors[i][j] == '1';
				D[i][j] = G[i][j] ? 1 : INT_MAX / 4;
				if (i == j)
					D[i][j] = 0;
			}
		}
		for (int k = 0; k < n; ++k) {
			for (int i = 0; i < n; ++i) {
				for (int j = 0; j < n; ++j) {
					D[i][j] = min(D[i][j], D[i][k] + D[k][j]);
				}
			}
		}
		S = agentStart, T = agentTarget;
		m = S.size();
		ans = 0;
		memo.clear();
		path.clear();
		path.push_back(start);
		dfs(start, finish, 1);
		return 1 - ans;
	}
};


double test0() {
	string t0[] = {
"0100",
"1011",
"0100",
"0100"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int t1[] = {3};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int p3 = 0;
	int p4 = 2;
	EscapeArtist * obj = new EscapeArtist();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {
"01000",
"10110",
"01000",
"01001",
"00010"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int t1[] = {4};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int p3 = 0;
	int p4 = 2;
	EscapeArtist * obj = new EscapeArtist();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 0.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {
"010000",
"101011",
"010111",
"001000",
"011000",
"011000"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int t1[] = {4};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {5};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int p3 = 0;
	int p4 = 3;
	EscapeArtist * obj = new EscapeArtist();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 0.5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {
"010000",
"101001",
"010110",
"001000",
"001000",
"010000"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int t1[] = {4};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {5};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int p3 = 0;
	int p4 = 3;
	EscapeArtist * obj = new EscapeArtist();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {
"01100",
"10011",
"10010",
"01100",
"01000"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int t1[] = {4,3};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1,0};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int p3 = 0;
	int p4 = 3;
	EscapeArtist * obj = new EscapeArtist();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 0.5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {
"0100",
"1010",
"0101",
"0010"
};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int t1[] = {3};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {2};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int p3 = 0;
	int p4 = 3;
	EscapeArtist * obj = new EscapeArtist();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test6() {
	string t0[] = {"0101", "1010", "0101", "1010"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int t1[] = {1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {0};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int p3 = 0;
	int p4 = 1;
	EscapeArtist * obj = new EscapeArtist();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test7() {
	string t0[] = {"011", "101", "110"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	int t1[] = {0};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int p3 = 2;
	int p4 = 1;
	EscapeArtist * obj = new EscapeArtist();
	clock_t start = clock();
	double my_answer = obj->bestRoute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p5 = 1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	time = test6();
	if (time < 0)
		errors = true;
	
	time = test7();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
