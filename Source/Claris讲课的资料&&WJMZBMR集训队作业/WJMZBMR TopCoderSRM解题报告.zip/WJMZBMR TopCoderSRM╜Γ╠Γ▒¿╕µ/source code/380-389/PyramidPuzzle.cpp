#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#include <cassert>
#define REP(i,size) for(int i=0;i<size;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
int size, n;

vector<int> unit() {
	vector<int> a(size);
	for (int i = 0; i < size; ++i) {
		a[i] = i;
	}
	return a;
}

vector<int> operator*(const vector<int>&a, const vector<int>&b) {
	vector<int> c(a.size());
	for (int i = 0; i < a.size(); ++i) {
		c[i] = b[a[i]];
	}
	return c;
}

inline int id(int r, int c) {
	return r * r + c;
}

void setRotateSide(vector<int>&ret, int a, int b, bool twice) {
	vector<int> p(n * n);
	int cur = 0;
	for (int i = 0; i < n; ++i) {
		int r = n - 1, c = i + i;
		for (int j = 0; j < i + i + 1; ++j) {
			p[cur++] = id(r, c);
			--c;
			if (j % 2 == 1)
				--r;
		}
	}
	cout << "HI" << endl;
	if (twice) {
		cout << "?" << endl;
		p = p * p;
		cout << "done" << endl;
	}
	for (int i = 0; i < n * n; ++i) {
		ret[i + a * n * n] = p[i] + b * n * n;
	}
}

vector<int> plusX(int x) {
	vector<int> ret = unit();
	for (int i = 0; i < x * x; ++i) {
		ret[i] = i + n * n;
		ret[i + n * n] = i + n * n * 2;
		ret[i + n * n * 2] = i;
	}
	if (x == n) { //rotate the down face
		setRotateSide(ret, 3, 3, true);
	}
	return ret;
}

vector<int> minusX(int x) {
	return plusX(x) * plusX(x);
}

vector<int> back() {
	vector<int> ret = unit();
	setRotateSide(ret, 0, 0, false);
	setRotateSide(ret, 1, 2, true);
	setRotateSide(ret, 2, 3, false);
	for (int i = 0; i < n * n; ++i) {
		ret[i + n * n * 3] = n * n + i;
	}
	return ret;
}

vector<int> left() {
	return minusX(n) * back() * plusX(n);
}

vector<int> right() {
	return plusX(n) * back() * minusX(n);
}

int toInt(string s) {
	istringstream sin(s);
	int x;
	sin >> x;
	return x;
}

class PyramidPuzzle {
	public:

	int repeatCount(int edgeLength, vector<string> moves) {
		n = edgeLength;
		size = 4 * n * n;
		string s = accumulate(moves.begin(), moves.end(), string());
		istringstream sin(s);
		string p;
		vector<int> cur = unit();
		while (sin >> p) {
			switch (p[0]) {
				case '+': {
					cur = cur * plusX(toInt(p.substr(1)));
					break;
				}
				case '-': {
					cur = cur * minusX(toInt(p.substr(1)));
					break;
				}
				case 'L': {
					cur = cur * left();
					break;
				}
				case 'R': {
					cur = cur * right();
					break;
				}
				case 'B': {
					cur = cur * back();
					break;
				}
			}
		}

		vector<int> maxPow(size + 1, 0);
		vector<bool> mark(size, false);
		for (int i = 0; i < size; ++i) {
			if (mark[i])
				continue;
			int u = i, cnt = 0;
			while (!mark[u]) {
				mark[u] = true;
				u = cur[u];
				++cnt;
			}

			for (int j = 2; j <= cnt; ++j) {
				int t = 0;
				while (cnt % j == 0) {
					cnt /= j;
					++t;
				}
				maxPow[j] = max(maxPow[j], t);
			}
		}

		int ans = 1;
		for (int i = 1; i < maxPow.size(); ++i) {
			for (int j = 0; j < maxPow[i]; ++j) {
				ans = 1LL * ans * i % 987654319;
			}
		}

		return ans;
	}
};
//
