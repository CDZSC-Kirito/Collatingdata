#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class InfiniteAddition {
	public:
	string giveExample(int, int, int);
};

const int HASH_MOD = int(1e9) + 7;

typedef long long int64;

int powerMod(int x, int e, int mod) {
	if (!e)
		return 1;
	return e & 1 ? powerMod(x, e - 1, mod) * x % mod : powerMod(x * x % mod, e >> 1, mod);
}

int invMod(int x, int mod) {
	return powerMod(x, mod - 2, mod);
}

struct ModMatrix {
	vector<vector<int> > mat;
	int mod;
	int nVars;
	vector<int> b, at;

	ModMatrix(int _mod, int _nVars) :
			mod(_mod), nVars(_nVars), at(nVars, -1) {
	}

	void adjust(int&x) {
		x %= mod;
		if (x < 0)
			x += mod;
	}

	void addConstraint(vector<int> cof, int v) {
		for (vector<int>::iterator e = cof.begin(); e != cof.end(); ++e) {
			adjust(*e);
		}
		adjust(v);

		for (int c = 0; c < nVars; ++c) {
			if (at[c] != -1) {
				int r = at[c], by = cof[c];
				for (int cc = 0; cc < nVars; ++cc) {
					cof[cc] -= by * mat[r][cc];
					adjust(cof[cc]);
				}
				v -= by * b[r];
				adjust(v);
			}
		}

		for (int c = 0; c < nVars; ++c) {
			if (cof[c] != 0) {
				at[c] = mat.size();
				int by = invMod(cof[c], mod);
				for (int cc = 0; cc < nVars; ++cc) {
					adjust(cof[cc] *= by);
				}
				adjust(v *= by);

				for (int r = 0; r < mat.size(); ++r) {
					int by = mat[r][c];
					for (int cc = 0; cc < nVars; ++cc) {
						adjust(mat[r][cc] -= by * cof[cc]);
					}
					adjust(b[r] -= by * v);
				}

				break;
			}
		}
		mat.push_back(cof);
		b.push_back(v);
	}

	int countSol() {
		int cnt = count(at.begin(), at.end(), -1);
		for (int r = 0; r < mat.size(); ++r) {
			if (b[r] != 0) {
				if (count(mat[r].begin(), mat[r].end(), 0) == nVars)
					return 0;
			}
		}
		int ret = 1;
		for (int i = 0; i < cnt; ++i) {
			ret = 1LL * ret * mod % HASH_MOD;
		}

		return ret;
	}

	void show() {
		cout << "MOD:" << mod << endl;
		for (int r = 0; r < mat.size(); ++r) {
			copy(mat[r].begin(), mat[r].end(), ostream_iterator<int>(cout, " "));
			cout << "=" << b[r] << endl;
		}
	}
};

struct Matrix {
	int mod; //assume no square divide into mod
	vector<ModMatrix> modMatrixes;
	vector<int> ps;
	int nVars;

	Matrix(int _mod, int _nVars) :
			mod(_mod), nVars(_nVars) {
		int x = mod;
		for (int i = 2; i <= x; ++i) {
			if (x % i == 0) {
				ps.push_back(i);
				x /= i;
			}
		}

		for (vector<int>::iterator e = ps.begin(); e != ps.end(); ++e) {
			modMatrixes.push_back(ModMatrix(*e, nVars));
		}

	}

	void addConstraint(vector<int> cof, int v) {
		for (int i = 0; i < ps.size(); ++i) {
			modMatrixes[i].addConstraint(cof, v);
		}
	}

	void makeSame(int a, int b) {
		vector<int> cof(nVars, 0);
		cof[a] = 1, cof[b] = -1;
		addConstraint(cof, 0);
	}

	int countSol() {
		int ret = 1;
		for (vector<ModMatrix>::iterator e = modMatrixes.begin(); e != modMatrixes.end(); ++e) {
			ret = 1LL * ret * e->countSol() % HASH_MOD;
		}
		return ret;
	}

	void show() {
		for (vector<ModMatrix>::iterator e = modMatrixes.begin(); e != modMatrixes.end(); ++e) {
			e->show();
		}
	}
};

int gcd(int a, int b) {
	return b ? gcd(b, a % b) : a;
}

int lcm(int a, int b) {
	return a / gcd(a, b) * b;
}

bool check(vector<Matrix>&withCycle, vector<int>&cofs) {
	int sum = 0;
	for (int i = 0; i < withCycle.size(); ++i) {
		sum += withCycle[i].countSol() * cofs[i];
		sum = (sum % HASH_MOD + HASH_MOD) % HASH_MOD;
	}
	return sum != 0;
}

string InfiniteAddition::giveExample(int sum, int op1, int op2) {
	int nVars = sum + op1 + op2; //<=60

	Matrix orig(26, nVars);
	vector<Matrix> withCycle;
	vector<int> cofs;

	int LCM = lcm(sum, op1);
	if (LCM != lcm(sum, op2) || LCM != lcm(op1, op2))
		return "NO SOLUTION";

	//make the initial constraints
	for (int i = 0; i < LCM; ++i) {
		int s = i % sum, a = i % op1, b = i % op2;
		vector<int> cof(nVars, 0);
		cof[s] = 1;
		cof[a + sum] = -1;
		cof[b + sum + op1] = -1;
		orig.addConstraint(cof, 0);
	}

	//calculate the phi function
	vector<int> phi(nVars, 1);
	for (int i = 2; i < phi.size(); ++i) {
		bool is = true;
		for (int j = 2; j < i; ++j) {
			if (i % j == 0) {
				is = false;
				int cnt = 0;
				int x = i;
				while (x % j == 0)
					x /= j, ++cnt;
				if (cnt > 1) {
					phi[i] = 0;
				} else {
					phi[i] = -1 * phi[i / j];
				}
				break;
			}
		}
		if (is)
			phi[i] = -1;
	}
	//make the cycle constraints
	for (int part1 = 1; part1 <= sum; ++part1) {
		for (int part2 = 1; part2 <= op1; ++part2) {
			for (int part3 = 1; part3 <= op2; ++part3) {
				if (sum % part1 == 0 && op1 % part2 == 0 && op2 % part3 == 0) {
					int l1 = sum / part1, l2 = op1 / part2, l3 = op2 / part3;
					int c = phi[part1] * phi[part2] * phi[part3];
					if (c == 0)
						continue;
					Matrix cur = orig;
					for (int i = 0; i < sum; ++i) {
						if (i + l1 < sum)
							cur.makeSame(i, i + l1);
					}
					for (int i = 0; i < op1; ++i) {
						if (i + l2 < op1)
							cur.makeSame(i + sum, i + l2 + sum);
					}
					for (int i = 0; i < op2; ++i) {
						if (i + l3 < op2)
							cur.makeSame(i + sum + op1, i + l3 + sum + op1);
					}
					withCycle.push_back(cur);
					cofs.push_back(c);
				}
			}
		}
	}
	//let's build answer!
	if (!check(withCycle, cofs))
		return "NO SOLUTION";
	vector<int> val(nVars, -1);
	for (int i = 0; i < nVars; ++i) {
		for (int i = 0; i < withCycle.size(); ++i) {
			if (withCycle[i].countSol() == 0) {
				withCycle.erase(withCycle.begin() + i);
				cofs.erase(cofs.begin() + i);
			}
		}
		vector<Matrix> withCycleCopy = withCycle;
		for (int v = 1; v <= 26; ++v) {
			vector<int> cof(nVars, 0);
			cof[i] = 1;
			for (vector<Matrix>::iterator e = withCycle.begin(); e != withCycle.end(); ++e) {
				e->addConstraint(cof, v);
			}
			if (check(withCycle, cofs)) {
				val[i] = v;
				break;
			}
			withCycle = withCycleCopy;
		}
	}

	string A, B, C;
	for (int i = 0; i < nVars; ++i) {
		char ch = 'A' + val[i] - 1;
		if (i < sum)
			A += ch;
		else if (i < sum + op1)
			B += ch;
		else
			C += ch;
	}
	return "(" + A + ")=(" + B + ")+(" + C + ")";
}

//
double test0() {
	int p0 = 6;
	int p1 = 2;
	int p2 = 3;
	InfiniteAddition * obj = new InfiniteAddition();
	clock_t start = clock();
	string my_answer = obj->giveExample(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "(AAABZB)=(AB)+(ZYZ)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 10;
	int p1 = 5;
	int p2 = 5;
	InfiniteAddition * obj = new InfiniteAddition();
	clock_t start = clock();
	string my_answer = obj->giveExample(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "NO SOLUTION";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 5;
	int p1 = 5;
	int p2 = 5;
	InfiniteAddition * obj = new InfiniteAddition();
	clock_t start = clock();
	string my_answer = obj->giveExample(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "(AAAAB)=(AAAAC)+(ZZZZY)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 1;
	int p1 = 5;
	int p2 = 5;
	InfiniteAddition * obj = new InfiniteAddition();
	clock_t start = clock();
	string my_answer = obj->giveExample(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "(A)=(AAAAB)+(ZZZZY)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
