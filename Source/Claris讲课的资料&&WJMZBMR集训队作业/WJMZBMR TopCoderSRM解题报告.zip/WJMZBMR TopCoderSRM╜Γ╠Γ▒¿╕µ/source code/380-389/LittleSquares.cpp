#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
#define CLR(x,c) memset(x,c,sizeof x)
#define FOR(i,a,b) for(int i=a;i<b;i++)
#define ALL(x) x.begin(),x.end()
#define RREP(i,n) for(int i=n-1;i>=0;i--)
#define RFOR(i,a,b) for(int i=b-1;i>=a;i--)
#define REPS(i,x) REP(i,x.size())
using namespace std;
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef istringstream ISS;
typedef ostringstream OSS;
typedef long long int64;
template<class T> void checkmax(T&x, T c) {
	if (c > x)
		x = c;
}
template<class T> void checkmin(T&x, T c) {
	if (c < x)
		x = c;
}

class LittleSquares {
	public:
	string winner(vector<string>);
};

int memo[1 << 20];
int sg(int mask, int m) {
	int&ret = memo[mask];
	if (ret != -1)
		return ret;
	bool has[50] = { };
	bool map[2][10];
	for (int r = 0; r < 2; ++r) {
		for (int c = 0; c < m; ++c) {
			map[r][c] = (mask >> (r * m + c) & 1);
		}
	}
	for (int r = 0; r < 2; ++r) {
		for (int c = 0; c < m; ++c) {
			if (!map[r][c]) {
				has[sg(mask | (1 << (r * m + c)), m)] = true;
			}
			if (r + 1 < 2 && c + 1 < m && !map[r][c] && !map[r + 1][c] && !map[r][c + 1] && !map[r + 1][c + 1]) {
				int nmask = mask;
				nmask |= 3 << (r * m + c);
				nmask |= 3 << ((r + 1) * m + c);
				has[sg(nmask, m)] = true;
			}
		}
	}
	for (int i = 0;; ++i) {
		if (!has[i]) {
			return ret = i;
		}
	}
}

string LittleSquares::winner(vector<string> state) {
	memset(memo, -1, sizeof memo);
	int n = state.size();
	int m = state[0].size();

	int sg = 0;
	for (int r = 0; r < state.size(); r += 2) {
		int mask = 0;
		for (int rr = 0; rr < 2; ++rr) {
			for (int cc = 0; cc < m; ++cc) {
				if (state[r + rr][cc] == '#')
					mask |= 1 << (rr * m + cc);
			}
		}
		sg ^= ::sg(mask, m);
	}
	cout << sg << endl;
	return sg ? "first" : "second";
}

//
double test0() {
	string t0[] = { "..",
  ".." };
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	LittleSquares * obj = new LittleSquares();
	clock_t start = clock();
	string my_answer = obj->winner(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "first";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = { "...#",
  "..##" };
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	LittleSquares * obj = new LittleSquares();
	clock_t start = clock();
	string my_answer = obj->winner(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "first";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = { "..",
  "..",
  "..",
  ".." };
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	LittleSquares * obj = new LittleSquares();
	clock_t start = clock();
	string my_answer = obj->winner(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "second";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = { "....",
  "...." };
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	LittleSquares * obj = new LittleSquares();
	clock_t start = clock();
	string my_answer = obj->winner(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "first";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = { ".##.",
  "#..#",
  "#..#",
  ".##." };
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	LittleSquares * obj = new LittleSquares();
	clock_t start = clock();
	string my_answer = obj->winner(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "second";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = { "#.......",
  ".....##.",
  ".....##.",
  "........",
  "........",
  "........",
  "........",
  "#......#" };
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	LittleSquares * obj = new LittleSquares();
	clock_t start = clock();
	string my_answer = obj->winner(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "first";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
