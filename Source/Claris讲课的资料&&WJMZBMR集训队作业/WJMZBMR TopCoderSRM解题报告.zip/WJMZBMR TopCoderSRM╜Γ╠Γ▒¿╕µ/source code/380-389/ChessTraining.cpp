#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
#define CLR(x,c) memset(x,c,sizeof x)
#define FOR(i,a,b) for(int i=a;i<b;i++)
#define ALL(x) x.begin(),x.end()
#define RREP(i,n) for(int i=n-1;i>=0;i--)
#define RFOR(i,a,b) for(int i=b-1;i>=a;i--)
#define REPS(i,x) REP(i,x.size())
using namespace std;
typedef vector<int> VI;
typedef vector<VI> VVI;
typedef istringstream ISS;
typedef ostringstream OSS;
typedef long long int64;
template<class T> void checkmax(T&x, T c) {
	if (c > x)
		x = c;
}
template<class T> void checkmin(T&x, T c) {
	if (c < x)
		x = c;
}

class ChessTraining {
	public:
	string game(vector<int>, vector<int>);
};

bool chk(int a, int b) {
	return a > 0 && b > 0 && a != b;
}

string ChessTraining::game(vector<int> x, vector<int> y) {
	const int N = 100;
	int sg[N][N];
	string FIRST = "Alice will win";
	string SECOND = "Bob will win";
	for (int i = 0; i < x.size(); ++i) {
		if (x[i] == 0 || y[i] == 0 || x[i] == y[i])
			return FIRST;
	}
	for (int i = 0; i < N; ++i) {
		for (int j = 0; j < N; ++j) {
			set<int> has;
			for (int k = 1; k < N; ++k) {
				if (chk(i - k, j))
					has.insert(sg[i - k][j]);
				if (chk(i, j - k))
					has.insert(sg[i][j - k]);
				if (chk(i - k, j - k))
					has.insert(sg[i - k][j - k]);
			}
			for (int it = 0;; ++it) {
				if (!has.count(it)) {
					sg[i][j] = it;
					break;
				}
			}
		}
	}

	int s = 0;
	for (int i = 0; i < x.size(); ++i) {
		s ^= sg[x[i]][y[i]];
	}

	return s ? FIRST : SECOND;
}


double test0() {
	int t0[] = {3,4};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {3,5};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	ChessTraining * obj = new ChessTraining();
	clock_t start = clock();
	string my_answer = obj->game(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "Alice will win";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {1};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {2};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	ChessTraining * obj = new ChessTraining();
	clock_t start = clock();
	string my_answer = obj->game(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "Bob will win";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {5,7,3,5};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {8,3,7,8};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	ChessTraining * obj = new ChessTraining();
	clock_t start = clock();
	string my_answer = obj->game(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "Bob will win";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {3,3,18,6,0,14,1};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {4,4,11,9,9,9,9};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	ChessTraining * obj = new ChessTraining();
	clock_t start = clock();
	string my_answer = obj->game(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "Alice will win";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int t0[] = {1,2};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {3,3};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	ChessTraining * obj = new ChessTraining();
	clock_t start = clock();
	string my_answer = obj->game(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "Alice will win";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	int t0[] = {3,4,3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {2,2,1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	ChessTraining * obj = new ChessTraining();
	clock_t start = clock();
	string my_answer = obj->game(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "Bob will win";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
