#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class CharmingTickets {
	public:
	int count(int, string);
};
const int MOD = 999983;

vector<int> eval(int n, int MAX_VALUE, string good) {
	vector<int> can;
	for (int i = 0; i < good.size(); ++i) {
		can.push_back(good[i] - '0');
	}
	vector<int> am(MAX_VALUE, 0);
	am[0] = 1;
	for (int i = 0; i < n; ++i) {
		vector<int> nam(MAX_VALUE, 0);
		for (int j = 0; j < MAX_VALUE; ++j) {
			if (am[j]) {
				for (vector<int>::iterator e = can.begin(); e != can.end(); ++e) {
					nam[j + *e] += am[j];
					if (nam[j + *e] >= MOD)
						nam[j + *e] -= MOD;
				}
			}
		}
		am = nam;
	}
	return am;
}

int CharmingTickets::count(int K, string good) {
	int cnt[2][2] = { };
	for (int i = 0; i < 2 * K; ++i) {
		cnt[i >= K][i % 2]++;
	}

	int maxDigit = *max_element(good.begin(), good.end()) - '0';
	int maxNum = *max_element(cnt[0], cnt[2]);
	const int MAX_VALUE = maxDigit * maxNum + 1;
	vector<int> am[2][2];
	for (int r = 0; r < 2; ++r) {
		for (int c = 0; c < 2; ++c) {
			am[r][c] = eval(cnt[r][c], MAX_VALUE, good);
		}
	}
	//am[0][0] = am[1][1] && am[0][1] == am[1][0]
	int ans = 1;
	{
		int tmp = 0;
		for (int i = 0; i < MAX_VALUE; ++i) {
			tmp += 1LL * am[0][0][i] * am[1][1][i] % MOD;
			if (tmp >= MOD)
				tmp -= MOD;
		}
		ans = 1LL * ans * tmp % MOD;
	}
	{
		int tmp = 0;
		for (int i = 0; i < MAX_VALUE; ++i) {
			tmp += 1LL * am[0][1][i] * am[1][0][i] % MOD;
			if (tmp >= MOD)
				tmp -= MOD;
		}
		ans = 1LL * ans * tmp % MOD;
	}

	vector<int> way = eval(K, K * maxDigit + 1, good);
	{
		int tmp = 0;
		for (int i = 0; i < way.size(); ++i) {
			tmp += 1LL * way[i] * way[i] % MOD;
			if (tmp >= MOD)
				tmp -= MOD;
		}
		ans = tmp * 2 % MOD - ans;
		ans = (ans + MOD) % MOD;
	}
	return ans;
}

//
double test0() {
	int p0 = 1;
	string p1 = "0123456789";
	CharmingTickets * obj = new CharmingTickets();
	clock_t start = clock();
	int my_answer = obj->count(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 10;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 2;
	string p1 = "21";
	CharmingTickets * obj = new CharmingTickets();
	clock_t start = clock();
	int my_answer = obj->count(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 8;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 2;
	string p1 = "0987654321";
	CharmingTickets * obj = new CharmingTickets();
	clock_t start = clock();
	int my_answer = obj->count(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 1240;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 137;
	string p1 = "0123456789";
	CharmingTickets * obj = new CharmingTickets();
	clock_t start = clock();
	int my_answer = obj->count(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 630063;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
