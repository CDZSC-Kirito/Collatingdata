#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class TelephoneNumbers {
	public:
	string kthNumber(int, int);
};

string toHex(int k) {
	char buf[100];
	sprintf(buf, "%07x", k);
	return buf;
}
bitset<1 << 28> mark;
string TelephoneNumbers::kthNumber(int sep, int k) {
	mark.reset();
	int cur = 0;
	int jump = 1 << (4 * (sep - 1));
	int jumpM = 1 << (4 * (sep - 2));
	for (;;) {
		if (mark[cur]) {
			cur = (cur & (~(jumpM - 1))) + jumpM;
			continue;
		}
		if (sep == 3) {
			bool ok = true;
			for (int i = 0; i < 7; ++i) {
				for (int j = 0; j < 16; ++j) {
					int d = cur >> (i * 4) & 15;
					int ncur = cur + ((j - d) << (i * 4));
					if (mark[ncur]) {
						ok = false;
						goto end;
					}
				}
			}
			end: {
			}
			if (!ok) {
				++cur;
				continue;
			}
		}
		if (--k == 0) {
			return toHex(cur);
		}
		if (sep >= 2) {
			for (int i = 0; i < 7; ++i) {
				for (int j = 0; j < 16; ++j) {
					int d = cur >> (i * 4) & 15;
					int ncur = cur + ((j - d) << (i * 4));
					mark[ncur] = true;
				}
			}
		}
		cur = (cur & (~(jump - 1))) + jump;
	}
	return "";
}


double test0() {
	int p0 = 1;
	int p1 = 5;
	TelephoneNumbers * obj = new TelephoneNumbers();
	clock_t start = clock();
	string my_answer = obj->kthNumber(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "0000004";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 2;
	int p1 = 17;
	TelephoneNumbers * obj = new TelephoneNumbers();
	clock_t start = clock();
	string my_answer = obj->kthNumber(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "0000101";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 3;
	int p1 = 33;
	TelephoneNumbers * obj = new TelephoneNumbers();
	clock_t start = clock();
	string my_answer = obj->kthNumber(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p2 = "0002023";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p2 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
