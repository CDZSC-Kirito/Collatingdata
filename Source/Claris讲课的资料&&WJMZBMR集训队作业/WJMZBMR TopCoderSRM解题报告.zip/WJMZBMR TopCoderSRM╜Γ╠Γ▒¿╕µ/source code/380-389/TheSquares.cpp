#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

template<class T>
vector<T> split(vector<string> s) {
	istringstream sin(accumulate(s.begin(), s.end(), string()));
	T x;
	vector<T> ret;
	while (sin >> x)
		ret.push_back(x);
	return ret;
}

struct Square {
	int x, y, l;
	string s;
	Square(int _x, int _y, int _l, string _s) :
			x(_x), y(_y), l(_l), s(_s) {
	}
	bool operator<(const Square&o) const {
		if (l != o.l)
			return l > o.l;
		return s < o.s;
	}
	bool contain(const Square&s) const {
		return x <= s.x && x + l >= s.x + s.l && y <= s.y && y + l >= s.y + s.l;
	}
};

struct TheSquares {
	vector<string> findSequence(vector<string> _x, vector<string> _y, vector<string> lengths, vector<string> names, int k) {
		vector<int> x = split<int>(_x), y = split<int>(_y), l = split<int>(lengths);
		vector<string> s = split<string>(names);
		vector<Square> squares;
		for (int i = 0; i < x.size(); ++i) {
			squares.push_back(Square(x[i], y[i], l[i], s[i]));
		}
		sort(squares.begin(), squares.end());
		int n = x.size();
		vector<int> f(n, -1);
		for (int i = n - 1; i >= 0; --i) {
			f[i] = 1;
			for (int j = i + 1; j < n; ++j) {
				if (squares[i].contain(squares[j]))
					f[i] = max(f[i], f[j] + 1);
			}
		}

		vector<int> canLast;
		canLast.push_back(-1);
		vector<string> ret;

		for (int d = k; d > 0; --d) {
			cout << endl;
			vector<int> cur;
			int w = -1;
			for (int i = 0; i < n; ++i) {
				if (f[i] >= d && (w == -1 || squares[i].s <= squares[w].s)) {
					bool chk = false;
					for (vector<int>::iterator e = canLast.begin(); e != canLast.end(); ++e) {
						if (*e < 0 || (*e < i && squares[*e].contain(squares[i]))) {
							chk = true;
							break;
						}
					}
					if (!chk)
						continue;
					if (w == -1 || squares[i].s < squares[w].s) {
						w = i;
						cur.clear();
					}
					cur.push_back(i);
				}
			}
			if (w == -1)
				return ret;
			ret.push_back(squares[w].s);
			canLast = cur;
		}

		return ret;
	}
};


double test0() {
	string t0[] = {"1 1 1 4 7 8 1000"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"1 1 1 4 7 8 1000"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	string t2[] = {"1 2 3 4 5 1 1000"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"X Y Z ALPHA BETA GAMMA DELTA"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int p4 = 2;
	TheSquares * obj = new TheSquares();
	clock_t start = clock();
	vector <string> my_answer = obj->findSequence(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t5[] = {"BETA", "GAMMA" };
	vector <string> p5(t5, t5+sizeof(t5)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p5.size() > 0) {
		cout <<"\""<<p5[0]<<"\"";
		for (int i=1; i<p5.size(); i++)
			cout <<", \"" <<p5[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p5) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"1 1 1 4 7 8 1000"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"1 1 1 4 7 8 1000"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	string t2[] = {"1 2 3 4 5 1 1000"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"X Y Z ALPHA BETA GAMMA DELTA"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int p4 = 3;
	TheSquares * obj = new TheSquares();
	clock_t start = clock();
	vector <string> my_answer = obj->findSequence(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t5[] = {"Z", "Y", "X" };
	vector <string> p5(t5, t5+sizeof(t5)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p5.size() > 0) {
		cout <<"\""<<p5[0]<<"\"";
		for (int i=1; i<p5.size(); i++)
			cout <<", \"" <<p5[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p5) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"4 4 4 4"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"7 7 7 7"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	string t2[] = {"47 47 47 47"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"GLUK GLUKA GLUKOVI GLUKOM"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int p4 = 4;
	TheSquares * obj = new TheSquares();
	clock_t start = clock();
	vector <string> my_answer = obj->findSequence(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t5[] = {"GLUK", "GLUKA", "GLUKOM", "GLUKOVI" };
	vector <string> p5(t5, t5+sizeof(t5)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p5.size() > 0) {
		cout <<"\""<<p5[0]<<"\"";
		for (int i=1; i<p5.size(); i++)
			cout <<", \"" <<p5[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p5) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"1 15 27 39"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"3 13 22 36"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	string t2[] = {"8 3 5 974"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"ACB DEF GHI JKL"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int p4 = 2;
	TheSquares * obj = new TheSquares();
	clock_t start = clock();
	vector <string> my_answer = obj->findSequence(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	vector <string> p5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p5.size() > 0) {
		cout <<"\""<<p5[0]<<"\"";
		for (int i=1; i<p5.size(); i++)
			cout <<", \"" <<p5[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p5) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"123 453 754"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"119 487 874"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	string t2[] = {"1000 500 1"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"SQUARE SQUARE SQUARE"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int p4 = 3;
	TheSquares * obj = new TheSquares();
	clock_t start = clock();
	vector <string> my_answer = obj->findSequence(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t5[] = {"SQUARE", "SQUARE", "SQUARE" };
	vector <string> p5(t5, t5+sizeof(t5)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p5.size() > 0) {
		cout <<"\""<<p5[0]<<"\"";
		for (int i=1; i<p5.size(); i++)
			cout <<", \"" <<p5[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p5) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string t0[] = {"3 5 10 1"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"5 8 10 1"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	string t2[] = {"974 990 1 1000"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"X Y X Y"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int p4 = 3;
	TheSquares * obj = new TheSquares();
	clock_t start = clock();
	vector <string> my_answer = obj->findSequence(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string t5[] = {"Y", "X", "X" };
	vector <string> p5(t5, t5+sizeof(t5)/sizeof(string));
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p5.size() > 0) {
		cout <<"\""<<p5[0]<<"\"";
		for (int i=1; i<p5.size(); i++)
			cout <<", \"" <<p5[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p5) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test6() {
	string t0[] = {"1 1 1 1"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	string t1[] = {"1 1 1 1"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	string t2[] = {"1 1 1 1"};
	vector <string> p2(t2, t2+sizeof(t2)/sizeof(string));
	string t3[] = {"A A A A"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	int p4 = 1000;
	TheSquares * obj = new TheSquares();
	clock_t start = clock();
	vector <string> my_answer = obj->findSequence(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	vector <string> p5;
	cout <<"Desired answer: " <<endl;
	cout <<"\t{ ";
	if (p5.size() > 0) {
		cout <<"\""<<p5[0]<<"\"";
		for (int i=1; i<p5.size(); i++)
			cout <<", \"" <<p5[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	cout <<endl <<"Your answer: " <<endl;
	cout <<"\t{ ";
	if (my_answer.size() > 0) {
		cout <<"\""<<my_answer[0]<<"\"";
		for (int i=1; i<my_answer.size(); i++)
			cout <<", \"" <<my_answer[i]<<"\"";
		cout <<" }" <<endl;
	}
	else
		cout <<"}" <<endl;
	if (my_answer != p5) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	time = test6();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
