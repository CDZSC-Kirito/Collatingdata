#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

typedef long long int64;

class NestedDiamonds {
	public:
	double minHeight(vector<int> sides) {
		vector<int64> a;
		for (vector<int>::iterator e = sides.begin(); e != sides.end(); ++e) {
			a.push_back(1LL * (*e) * (*e));
		}
		sort(a.rbegin(), a.rend());
		int n = a.size();
		for (int i = 0; i < n - 1; ++i) {
			if (a[i] == a[i + 1])
				return -1;
		}
		int64 l = 0, r = a[0];
		int64 t = 0;
		for (int i = 1; i < n; ++i) {
			int64 L, R;
			if (i % 2 == 1) { //tail
				L = a[i] + t, R = 2 * a[i] + t;
				t += 2 * a[i];
			} else {
				L = t - 2 * a[i], R = t - a[i];
				t -= 2 * a[i];
			}
			l = max(l, L);
			r = min(r, R);
		}
		if (l > r)
			return -1;
		return 2 * sqrt(l * 0.5);
	}
};


double test0() {
	int t0[] = {4, 2};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NestedDiamonds * obj = new NestedDiamonds();
	clock_t start = clock();
	double my_answer = obj->minHeight(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = 2.8284271247461903;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {10, 5, 2}
;
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NestedDiamonds * obj = new NestedDiamonds();
	clock_t start = clock();
	double my_answer = obj->minHeight(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = 9.16515138991168;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {1,2,5,3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NestedDiamonds * obj = new NestedDiamonds();
	clock_t start = clock();
	double my_answer = obj->minHeight(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = 4.69041575982343;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {1, 1};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NestedDiamonds * obj = new NestedDiamonds();
	clock_t start = clock();
	double my_answer = obj->minHeight(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = -1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int t0[] = {1,4,3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	NestedDiamonds * obj = new NestedDiamonds();
	clock_t start = clock();
	double my_answer = obj->minHeight(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p1 = 5.656854249492381;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
