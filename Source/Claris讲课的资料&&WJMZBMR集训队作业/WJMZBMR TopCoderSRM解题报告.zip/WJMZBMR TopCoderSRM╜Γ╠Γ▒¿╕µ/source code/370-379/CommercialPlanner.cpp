#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

//think carefully >_<

typedef long long int64;

struct Commercial {
	int64 l, dur;
	int64 free; //afther
	Commercial*next;
	Commercial(int _l, int _dur) :
			l(_l), dur(_dur) {
	}
	bool operator<(const Commercial&o) const {
		return l < o.l;
	}
};

class CommercialPlanner {
	public:
	int bestMinute(vector<int> starts, vector<int> durations, int ourDuration, int secondsPerDay, int n) {
		int num = starts.size();
		if (num == 0) {
			if (ourDuration <= secondsPerDay)
				return 0;
			return -1;
		}
		vector<Commercial> commercials;
		for (int i = 0; i < num; ++i) {
			commercials.push_back(Commercial(starts[i], durations[i]));
		}
		sort(commercials.begin(), commercials.end());
		for (int i = 0; i < num - 1; ++i) {
			Commercial&cur = commercials[i];
			cur.free = commercials[i + 1].l - (cur.l + cur.dur);
			cur.next = &commercials[i + 1];
		}
		Commercial&cur = commercials.back();
		cur.free = secondsPerDay + commercials[0].l - cur.l - cur.dur;
		cur.next = &commercials[0];

		int64 best = -1, ans = -1;

		for (int i = 0; i < num; ++i) {
			Commercial*cur = &commercials[i];
			if (cur->free >= ourDuration) { //put after cur
				int64 at = (cur->l + cur->dur) % secondsPerDay;
				int64 v = cur->free;
				for (int i = 0; i < n - 1; ++i) {
					cur = cur->next;
					v += cur->dur + cur->free;
				}
				v = min(v, 1LL * secondsPerDay);
				if (v > best) {
					best = v;
					ans = at;
				} else if (v == best && at < ans) {
					ans = at;
				}
			}
		}

		//or start at beginning of the day
		if (commercials.front().l >= ourDuration && commercials.back().l + commercials.back().dur <= secondsPerDay) {
			int64 at = 0;
			int64 v = commercials.front().l;

			Commercial*cur = &commercials.back();
			for (int i = 0; i < n - 1; ++i) {
				cur = cur->next;
				v += cur->dur + cur->free;
			}
			v = min(v, 1LL * secondsPerDay);
			if (v > best) {
				best = v;
				ans = at;
			} else if (v == best && at < ans) {
				ans = at;
			}
		}

		return ans;
	}
};


double test0() {
	int t0[] = {30, 5, 17, 45};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {12, 6, 3, 4};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 6;
	int p3 = 50;
	int p4 = 5;
	CommercialPlanner * obj = new CommercialPlanner();
	clock_t start = clock();
	int my_answer = obj->bestMinute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p5 = 11;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {30, 5, 17};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {12, 6, 3};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 63;
	int p3 = 100;
	int p4 = 4;
	CommercialPlanner * obj = new CommercialPlanner();
	clock_t start = clock();
	int my_answer = obj->bestMinute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p5 = 42;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {30, 5, 51, 17, 49};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {12, 6, 10, 3, 1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 1;
	int p3 = 60;
	int p4 = 2;
	CommercialPlanner * obj = new CommercialPlanner();
	clock_t start = clock();
	int my_answer = obj->bestMinute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p5 = 20;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {30, 5, 51, 17, 49};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {12, 6, 10, 3, 1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 64;
	int p3 = 100;
	int p4 = 4;
	CommercialPlanner * obj = new CommercialPlanner();
	clock_t start = clock();
	int my_answer = obj->bestMinute(p0, p1, p2, p3, p4);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p5 = -1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p5 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p5 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
