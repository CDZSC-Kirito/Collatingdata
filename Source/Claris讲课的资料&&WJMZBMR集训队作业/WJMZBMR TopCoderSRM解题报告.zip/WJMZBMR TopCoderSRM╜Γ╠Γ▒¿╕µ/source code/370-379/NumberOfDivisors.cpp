#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

const int MAX = 20;
typedef long long int64;
const int64 LIMIT = int64(1e18) + 100;

int64 mul(int64 a, int64 b) {
	if (a > LIMIT / b)
		return LIMIT;
	return a * b;
}

int64 power(int64 a, int n) {
	if (!n)
		return 1;
	return n & 1 ? mul(power(a, n - 1), a) : power(mul(a, a), n >> 1);
}

class NumberOfDivisors {
	public:
	vector<int> ps;

	int64 rec(int at, int prev, int k) {
		if (k == 1)
			return 1;
		int64 ret = LIMIT;
		for (int i = 1; i * i <= k; i++) {
			if (k % i == 0) {
				int v = i - 1;
				if (v <= prev && v > 0) {
					int64 c = power(ps[at], v);
					if (c != LIMIT) {
						c = mul(c, rec(at + 1, i, k / (v + 1)));
						ret = min(ret, c);
					}
				}

				if (i * i == k)
					continue;
				v = k / i - 1;
				if (v <= prev && v > 0) {
					int64 c = power(ps[at], v);
					if (c != LIMIT) {
						c = mul(c, rec(at + 1, i, k / (v + 1)));
						ret = min(ret, c);
					}
				}
			}
		}
		return ret;
	}

	long long smallestNumber(int k) {
		for (int i = 2; ps.size() < MAX; ++i) {
			bool chk = true;
			for (int j = 2; j < i; ++j) {
				if (i % j == 0)
					chk = false;
			}
			if (chk)
				ps.push_back(i);
		}
		int64 ans = rec(0, k + 1, k);
		if (ans > int64(1e18))
			return -1;
		else
			return ans;
	}
};

//
double test0() {
	int p0 = 1;
	NumberOfDivisors * obj = new NumberOfDivisors();
	clock_t start = clock();
	long long my_answer = obj->smallestNumber(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 1LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 2;
	NumberOfDivisors * obj = new NumberOfDivisors();
	clock_t start = clock();
	long long my_answer = obj->smallestNumber(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 2LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 6;
	NumberOfDivisors * obj = new NumberOfDivisors();
	clock_t start = clock();
	long long my_answer = obj->smallestNumber(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	long long p1 = 12LL;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
