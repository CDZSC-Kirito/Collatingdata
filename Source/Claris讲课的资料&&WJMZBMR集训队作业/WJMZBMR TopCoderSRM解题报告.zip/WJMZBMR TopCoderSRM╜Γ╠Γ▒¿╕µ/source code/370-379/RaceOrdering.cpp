#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

typedef long long int64;

const int MOD = int(1e6) + 3;

struct Int {
	int x;
	Int() :
			x(0) {
	}
	Int(int _x) :
			x(_x) {
		x %= MOD;
		if (x < 0)
			x += MOD;
	}
	Int(int64 _x) :
			x(_x) {
		x %= MOD;
		if (x < 0)
			x += MOD;
	}
	static Int get(int x) {
		Int a;
		a.x = x;
		return a;
	}

	Int operator+(const Int&o) const {
		int t = x + o.x;
		if (t >= MOD)
			t -= MOD;
		return get(t);
	}
	Int operator*(const Int&o) const {
		return get(1LL * x * o.x % MOD);
	}
	Int operator-(const Int&o) const {
		int t = x - o.x;
		if (t < 0)
			t += MOD;
		return get(t);
	}
	Int operator/(const Int&o) const {
		return (*this) * o.inv();
	}
	Int&operator+=(const Int&o) {
		return (*this) = *this + o;
	}
	Int&operator-=(const Int&o) {
		return (*this) = *this - o;
	}
	Int&operator*=(const Int&o) {
		return (*this) = *this * o;
	}
	Int&operator/=(const Int&o) {
		return (*this) = *this / o;
	}

	Int power(int64 n) const {
		if (!n)
			return get(1);
		const Int&a = *this;
		if (n & 1)
			return power(n - 1) * a;
		else
			return (a * a).power(n >> 1);
	}

	Int inv() const {
		return power(MOD - 2);
	}
};

class RaceOrdering {
	public:
	Int fact(int n) {
		Int a = 1;
		for (int i = 1; i <= n; ++i) {
			a *= i;
		}
		return a;
	}

	vector<vector<int> > E, P;
	vector<bool> vis;

	void dfs(int u, vector<int>&v) {
		if (vis[u])
			return;
		vis[u] = true;
		v.push_back(u);
		for (vector<int>::iterator e = E[u].begin(); e != E[u].end(); ++e) {
			dfs(*e, v);
		}
	}

	Int eval(vector<int> v) {
		int n = v.size();
		map<int, int> id;
		for (int i = 0; i < v.size(); ++i) {
			id[v[i]] = i;
		}

		vector<int> pre(n, 0);
		for (int i = 0; i < n; ++i) {
			for (vector<int>::iterator e = P[v[i]].begin(); e != P[v[i]].end(); ++e) {
				pre[i] |= 1 << id[*e];
			}
		}

		vector<Int> am(1 << n, 0);
		am[0] = 1;
		for (int i = 0; i < n; ++i) {
			vector<Int> nam(1 << n, 0);
			for (int j = 0; j < am.size(); ++j) {
				if (am[j].x == 0)
					continue;
				for (int k = 0; k < n; ++k) {
					if ((~j >> k & 1) && ((pre[k] & j) == pre[k])) {
						nam[j | (1 << k)] += am[j];
					}
				}
			}
			am = nam;
		}

		return am.back();
	}

	int countOrders(int n, vector<int> first, vector<int> second) {
		E.resize(n);
		P.resize(n);
		vis.assign(n, false);
		for (int i = 0; i < first.size(); ++i) {
			int a = first[i], b = second[i];
			E[a].push_back(b), E[b].push_back(a);
			P[b].push_back(a);
		}

		int rem = n;
		Int ret = 1;
		for (int i = 0; i < n; ++i) {
			if (!vis[i]) {
				vector<int> v;
				dfs(i, v);
				ret *= fact(rem) / (fact(v.size()) * fact(rem - v.size()));
				ret *= eval(v);
				rem -= v.size();
			}
		}

		return ret.x;
	}
};


double test0() {
	int p0 = 3;
	int t1[] = {1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {2};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	RaceOrdering * obj = new RaceOrdering();
	clock_t start = clock();
	int my_answer = obj->countOrders(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 4;
	int t1[] = {0, 0};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1, 2};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	RaceOrdering * obj = new RaceOrdering();
	clock_t start = clock();
	int my_answer = obj->countOrders(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 8;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 10;
	int t1[] = {1, 2, 3};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {2, 3, 1};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	RaceOrdering * obj = new RaceOrdering();
	clock_t start = clock();
	int my_answer = obj->countOrders(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 30;
	vector <int> p1;
	vector <int> p2;
	RaceOrdering * obj = new RaceOrdering();
	clock_t start = clock();
	int my_answer = obj->countOrders(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p3 = 90317;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
