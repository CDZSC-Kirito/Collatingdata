#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

const int MAX = 40;
class Unjumpers {
	public:
	set<vector<int> > reach;

	vector<int> get(string s) {
		vector<int> cnt(3, 0);
		for (int i = 0; i < s.size(); ++i) {
			if (s[i] == '*')
				cnt[i % 3]++;
		}
		return cnt;
	}

	void dfs(vector<int> cnt) {
		for (vector<int>::iterator e = cnt.begin(); e != cnt.end(); ++e) {
			if (*e < 0 || *e >= MAX)
				return;
		}
		if (!reach.insert(cnt).second)
			return;
		for (int i = 0; i < 3; ++i) {
			vector<int> nxt = cnt;

			nxt[i]++;
			for (int j = 0; j < 3; ++j) {
				if (i != j)
					nxt[j]--;
			}
			dfs(nxt);

			nxt = cnt;
			nxt[i]--;
			for (int j = 0; j < 3; ++j) {
				if (i != j)
					nxt[j]++;
			}
			dfs(nxt);
		}
	}

	int reachableTargets(string start, vector<string> targets) {
		dfs(get(start));
		int ret = 0;
		for (vector<string>::iterator e = targets.begin(); e != targets.end(); ++e) {
			ret += reach.count(get(*e));
		}
		return ret;
	}
};


double test0() {
	string p0 = "**.";
	string t1[] = {
"..*",
"*.**",
".*.*"}
;
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	Unjumpers * obj = new Unjumpers();
	clock_t start = clock();
	int my_answer = obj->reachableTargets(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string p0 = "..***";
	string t1[] = {
"..****..*",
"..***....",
"..****"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	Unjumpers * obj = new Unjumpers();
	clock_t start = clock();
	int my_answer = obj->reachableTargets(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string p0 = "*..*";
	string t1[] = {
"*..*......",
"*.....*...",
"...*.....*",
"...*..*...",
"*........*",
"*...***..*"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	Unjumpers * obj = new Unjumpers();
	clock_t start = clock();
	int my_answer = obj->reachableTargets(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 6;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string p0 = "...***" ;
	string t1[] = {
"***...",
"..****",
"**....**",
".*.*.*"};
	vector <string> p1(t1, t1+sizeof(t1)/sizeof(string));
	Unjumpers * obj = new Unjumpers();
	clock_t start = clock();
	int my_answer = obj->reachableTargets(p0, p1);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p2 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p2 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p2 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
