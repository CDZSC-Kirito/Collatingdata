#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
const int MAX = 1000000;

class DukeOnLargeChessBoard {
	public:
	vector<int> ly, ry;

	void update(int x, int y) {
		ly[x] = min(ly[x], y);
		ry[x] = max(ry[x], y);
	}

	bool done(int x, int y) {
		if (x < 0 || x >= MAX || y < 0 || y >= MAX)
			return true;
		return ly[x] <= y && ry[x] >= y;
	}

	string get(int x, int y) {
		char buf[100];
		sprintf(buf, "(%06d, %06d)", x, y);
		return buf;
	}

	string lastCell(string initPosition) {
		int x, y;
		{
			string s = initPosition;
			for (int i = 0; i < s.size(); ++i) {
				if (!isdigit(s[i]))
					s[i] = ' ';
			}
			istringstream sin(s);
			sin >> x >> y;
		}
		//c>r
		//right > up > down > left
		ly.assign(MAX, MAX);
		ry.assign(MAX, -1);
		//when we leave a column,all the visited cells in a column is a interval
		for (;;) {
			//go right
			if (!done(x + 1, y)) {
				update(x, y);
				++x;
			} else if (!done(x, y + 1)) { //go up
				int ny;
				if (y + 1 < ly[x])
					ny = ly[x] - 1;
				else
					ny = MAX - 1;
				//ending up and go right?
				if (x + 1 < MAX && ny > ry[x + 1]) {
					ny = ry[x + 1] + 1;
					update(x, y);
					update(x, ny);
					y = ny;
					++x;
				} else {
					update(x, y);
					update(x, ny);
					y = ny;
					if (x > 0 && !done(x - 1, y)) { //go left?
						--x;
					} else {
						return get(x, y);
					}
				}
			} else if (!done(x, y - 1)) { //go down
				int ny;
				if (y - 1 < ly[x])
					ny = 0;
				else
					ny = ry[x] + 1;
				if (x + 1 < MAX && ny < ly[x + 1]) { //go right?
					ny = ly[x + 1] - 1;
					update(x, y);
					update(x, ny);
					y = ny;
					++x;
				} else {
					update(x, y);
					update(x, ny);
					y = ny;
					if (x > 0 && !done(x - 1, y)) { //go left?
						--x;
					} else {
						return get(x, y);
					}
				}
			} else if (!done(x - 1, y)) { //go left
				update(x, y);
				--x;
			} else {
				char buf[100];
				sprintf(buf, "(%06d, %06d)", x, y);
				return buf;
			}
		}
	}
};


double test0() {
	string p0 = "(999999, 999999)";
	DukeOnLargeChessBoard * obj = new DukeOnLargeChessBoard();
	clock_t start = clock();
	string my_answer = obj->lastCell(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "(000000, 999999)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string p0 = "(999999, 000000)";
	DukeOnLargeChessBoard * obj = new DukeOnLargeChessBoard();
	clock_t start = clock();
	string my_answer = obj->lastCell(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "(000000, 000000)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string p0 = "(000000, 999998)";
	DukeOnLargeChessBoard * obj = new DukeOnLargeChessBoard();
	clock_t start = clock();
	string my_answer = obj->lastCell(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "(000000, 999999)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string p0 = "(999998, 000001)";
	DukeOnLargeChessBoard * obj = new DukeOnLargeChessBoard();
	clock_t start = clock();
	string my_answer = obj->lastCell(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "(999999, 000000)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string p0 = "(123456, 235711)";
	DukeOnLargeChessBoard * obj = new DukeOnLargeChessBoard();
	clock_t start = clock();
	string my_answer = obj->lastCell(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "(000000, 112256)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test5() {
	string p0 = "(987654, 123456)";
	DukeOnLargeChessBoard * obj = new DukeOnLargeChessBoard();
	clock_t start = clock();
	string my_answer = obj->lastCell(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "(864197, 000000)";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	time = test5();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
