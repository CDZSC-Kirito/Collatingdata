#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

struct Point {
	int x, y;
	Point(int _x, int _y) :
			x(_x), y(_y) {
	}
	Point operator+(const Point&p) const {
		return Point(x + p.x, y + p.y);
	}
	Point operator-(const Point&p) const {
		return Point(x - p.x, y - p.y);
	}
	Point operator*(int d) const {
		return Point(x * d, y * d);
	}
	Point operator/(int d) const {
		return Point(x / d, y / d);
	}
	int det(const Point&p) const {
		return x * p.y - y * p.x;
	}
	int dot(const Point&p) const {
		return x * p.x + y * p.y;
	}
};

#define cross(p1,p2,p3) ((p2.x-p1.x)*(p3.y-p1.y)-(p3.x-p1.x)*(p2.y-p1.y))

inline int sign(int a) {
	return a < 0 ? -1 : a > 0;
}

#define crossOp(p1,p2,p3) sign(cross(p1,p2,p3))

bool inMid(Point a, Point m, Point b, bool inc = false) {
	return crossOp(a,m,b) == 0 && sign((m - a).dot(m - b)) < (inc ? 1 : 0);
}

class SpiralConstruction {
	public:
	int longestSpiral(vector<string> points) {
		vector<Point> ps;
		for (vector<string>::iterator e = points.begin(); e != points.end(); ++e) {
			istringstream sin(*e);
			int x, y;
			sin >> x >> y;
			ps.push_back(Point(x, y));
		}
		ps.push_back(Point(0, 0));
		int n = ps.size();
		vector<vector<bool> > dp(1 << n, vector<bool>(n, false));
		dp[1 << (n - 1)][n - 1] = true;
		int ans = 0;
		for (int i = 0; i < (1 << n); ++i) {
			for (int j = 0; j < n; ++j) {
				if (dp[i][j]) {
					int cnt = 0;
					for (int k = 0; k < n; ++k) {
						if (i >> k & 1)
							++cnt;
					}
					ans = max(ans, cnt);

					for (int k = 0; k < n; ++k) {
						if (i >> k & 1)
							continue;
						//j->k
						Point pj = ps[j], pk = ps[k];
						bool chk = true;
						for (int l = 0; l < n; ++l) {
							if (i >> l & 1) {
								Point pl = ps[l];
								int op = crossOp(pj,pk,pl);
								if (inMid(pj, pl, pk))
									chk = false;
								if (op == -1) {
									chk = false;
								} else if (op == 0) {
									if ((pl - pk).dot(pk - pj) >= 0) {
										chk = false;
									}
								}
							}
						}
						if (chk) {
							dp[i | (1 << k)][k] = true;
						}
					}
				}
			}
		}
		return ans - 1;
	}
};


double test0() {
	string t0[] = {"0 1", "1 0"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	SpiralConstruction * obj = new SpiralConstruction();
	clock_t start = clock();
	int my_answer = obj->longestSpiral(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"1 1", "2 2", "-1 -1"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	SpiralConstruction * obj = new SpiralConstruction();
	clock_t start = clock();
	int my_answer = obj->longestSpiral(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"0 1", "1 1", "0 2"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	SpiralConstruction * obj = new SpiralConstruction();
	clock_t start = clock();
	int my_answer = obj->longestSpiral(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"0 1", "-1 0", "0 -1", "1 2", "2 -2", "-2 1", "1 0", "-1 -1", "1 3", "-3 -2"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	SpiralConstruction * obj = new SpiralConstruction();
	clock_t start = clock();
	int my_answer = obj->longestSpiral(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 10;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
