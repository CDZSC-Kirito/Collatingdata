#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class BerryPacker {
	public:
	double bestPacking(vector<int> first, vector<int> period, int berries) {
		vector<int> next = first;
		int n = first.size();
		vector<int> cnt(1 << n, 0);
		vector<int> num(n, 0);
		double ret = 0;
		for (int nBox = 1; nBox <= berries; ++nBox) {
			int id = nBox - 1;

			int mask = 0;
			for (int i = 0; i < n; ++i) {
				if (next[i] == id) {
					num[i]++;
					mask |= 1 << i;
					next[i] += period[i];
				}
			}

			cnt[mask]++;

			{
				vector<double> cost(cnt.size(), 0);
				for (int i = 0; i < cost.size(); ++i) {
					for (int j = 0; j < n; ++j) {
						if (i >> j & 1) {
							if (num[j] > 0) {
								cost[i] += 1.0 * nBox / num[j];
							}
						}
					}
				}
				vector<pair<double, int> > costPerm(cost.size());
				for (int i = 0; i < cost.size(); ++i) {
					costPerm[i] = make_pair(cost[i], i);
				}
				sort(costPerm.rbegin(), costPerm.rend());
				double tmp = 0;
				int rem = berries;
				for (int i = 0; i < cost.size(); ++i) {
					tmp += cnt[i] * cost[i];
					rem -= cnt[i];
				}
				for (int i = 0; i < costPerm.size(); ++i) {
					int id = costPerm[i].second;
					int by = min(rem, cnt[id] * 8);
					rem -= by;
					tmp += by * cost[id];
				}

				ret = max(ret, tmp);
			}
		}
		return ret/n;
	}
};

//
double test0() {
	int t0[] = {2};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {500};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 6;
	BerryPacker * obj = new BerryPacker();
	clock_t start = clock();
	double my_answer = obj->bestPacking(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 12.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {0,1};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {2,2};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 7;
	BerryPacker * obj = new BerryPacker();
	clock_t start = clock();
	double my_answer = obj->bestPacking(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 9.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {2,5,9,25};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {1,3,11,7};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 100;
	BerryPacker * obj = new BerryPacker();
	clock_t start = clock();
	double my_answer = obj->bestPacking(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 251.50649350649354;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}
