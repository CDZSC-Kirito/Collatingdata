#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

struct BipartiteMatch {
	static const int MAX_N_VETS = 2500;
	bool edge[MAX_N_VETS][MAX_N_VETS];
	int forbidY;
	int nX, nY;

	void init(int _nX, int _nY) {
		nX = _nX;
		nY = _nY;
		for (int i = 0; i < nX; ++i) {
			for (int j = 0; j < nY; ++j) {
				edge[i][j] = false;
			}
		}
		forbidY = -1;
	}

	void addMatch(int x, int y) {
		edge[x][y] = true;
	}

	int linkY[MAX_N_VETS];
	bool visited[MAX_N_VETS];
	bool dfs(int x) {
		if (visited[x])
			return false;
		visited[x] = true;
		for (int y = 0; y < nY; ++y)
			if (y != forbidY) {
				if (edge[x][y] && (linkY[y] == -1 || dfs(linkY[y])))
					return linkY[y] = x, true;
			}
		return false;
	}

	int calcMaxMatch() {
		memset(linkY, -1, sizeof(int) * nY);
		int cnt = 0;
		for (int x = 0; x < nX; ++x) {
			memset(visited, false, sizeof(bool) * nX);
			if (dfs(x))
				++cnt;
		}

		return cnt;
	}
} bm;

struct Tree {
	char ch;
	vector<Tree*> child;

	bool canStart[256], canEnd[256];

	Tree(char _ch) :
			ch(_ch) {
		memset(canStart, false, sizeof canStart);
		memset(canEnd, false, sizeof canEnd);
	}

	void reduce() {
		for (int i = 0; i < child.size(); ++i) {
			child[i]->reduce();
		}
		vector<Tree*> v;
		for (int i = 0; i < child.size(); ++i) {
			if (child[i]->ch == ch) {
				v.insert(v.end(), child[i]->child.begin(), child[i]->child.end());
			} else {
				v.push_back(child[i]);
			}
		}
		child = v;
	}

	bool canFollow(Tree*o) const {
		for (int i = 0; i < 256; ++i) {
			if (canEnd[i] && o->canStart[i]) {
				return true;
			}
		}
		return false;
	}

	void putStart(Tree*o) {
		for (int i = 0; i < 256; ++i) {
			canStart[i] |= o->canStart[i];
		}
	}

	void showIt() {
		cout << "Can Start:" << endl;
		for (int i = 0; i < 256; ++i) {
			if (canStart[i])
				cout << (char) i << endl;
		}
		cout << "Can End:" << endl;
		for (int i = 0; i < 256; ++i) {
			if (canEnd[i])
				cout << (char) i << endl;
		}
	}

	int solve() {
		if (isalpha(ch)) {
			canStart[ch] = canEnd[ch] = true;
			return 1;
		}

		int ret = 1;
		for (int i = 0; i < child.size(); ++i) {
			ret += child[i]->solve();
		}

		vector<Tree*> x, y;
		bool hasSingleChar[256] = { };
		for (int i = 0; i < child.size(); ++i) {
			char c = child[i]->ch;
			if (isalpha(c)) {
				if (!hasSingleChar[c]) {
					hasSingleChar[c] = true;
					x.push_back(child[i]);
				} else {
					--ret; //get a saving
				}
			} else {
				y.push_back(child[i]);
			}
		}

		bm.init(x.size(), y.size());
		//calc result
		for (int i = 0; i < x.size(); ++i) {
			for (int j = 0; j < y.size(); ++j) {
				if (x[i]->canFollow(y[j])) {
					bm.addMatch(i, j);
				}
			}
		}
		int maxMatch = bm.calcMaxMatch();
		ret -= maxMatch;

		//canStart
		for (int i = 0; i < x.size(); ++i) {
			putStart(x[i]);
		}
		for (int i = 0; i < y.size(); ++i) {
			bm.forbidY = i;
			if (bm.calcMaxMatch() == maxMatch) {
				putStart(y[i]);
			}
		}

		//canEnd
		canEnd[ch] = true;
		return ret;
	}
};

class PostfixRLE {
public:
	int getCompressedSize(vector<string> _expr) {
		string expr = accumulate(_expr.begin(), _expr.end(), string());

		vector<Tree*> stack;
		for (int i = 0; i < expr.size(); ++i) {
			char ch = expr[i];
			if (isalpha(ch)) { //a var
				stack.push_back(new Tree(ch));
			} else { //a op
				Tree*t = new Tree(ch);
				t->child.push_back(stack.back()), stack.pop_back();
				t->child.push_back(stack.back()), stack.pop_back();
				stack.push_back(t);
			}
		}
		Tree*root = stack.back();
		root->reduce();
		return root->solve();
	}
};

//
double test0() {
	string t0[] = {"af+b*cd**"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	PostfixRLE * obj = new PostfixRLE();
	clock_t start = clock();
	int my_answer = obj->getCompressedSize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 7;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string t0[] = {"xy*x*y*x*y*"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	PostfixRLE * obj = new PostfixRLE();
	clock_t start = clock();
	int my_answer = obj->getCompressedSize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 3;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string t0[] = {"abcdefg!@#$%^"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	PostfixRLE * obj = new PostfixRLE();
	clock_t start = clock();
	int my_answer = obj->getCompressedSize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 13;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string t0[] = {"xy@z@ab@c@yc%%%"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	PostfixRLE * obj = new PostfixRLE();
	clock_t start = clock();
	int my_answer = obj->getCompressedSize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 9;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string t0[] = {"abc++",
"abc++",
"abc++",
"a",
"b",
"c",
"*",
"*",
"*",
"*",
"*"};
	vector <string> p0(t0, t0+sizeof(t0)/sizeof(string));
	PostfixRLE * obj = new PostfixRLE();
	clock_t start = clock();
	int my_answer = obj->getCompressedSize(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p1 = 13;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p1 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}
