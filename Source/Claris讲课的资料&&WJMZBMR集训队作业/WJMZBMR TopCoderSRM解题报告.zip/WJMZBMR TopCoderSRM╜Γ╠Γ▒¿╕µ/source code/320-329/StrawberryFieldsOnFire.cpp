#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

typedef long long int64;

template<class T>
struct Index: public vector<T> {
	using vector<T>::erase;
	using vector<T>::begin;
	using vector<T>::end;
	void doit() {
		sort(begin(), end());
		erase(unique(begin(), end()), end());
	}
	int get(T x) {
		return lower_bound(begin(), end(), x) - begin();
	}
};

class StrawberryFieldsOnFire {
	public:
	int timeLimit(int w, int h, string _need, vector<string> fire) {
		istringstream sin(_need);
		int64 need;
		sin >> need;
		int L = -1, R = INT_MAX / 2;
		vector<int> xv(fire.size()), yv(fire.size());
		for (int i = 0; i < fire.size(); ++i) {
			istringstream sin(fire[i]);
			sin >> xv[i] >> yv[i];
		}
		while (L + 1 < R) {
			int M = L + R >> 1;
			Index<int> idx, idy;
			idx.push_back(0);
			idx.push_back(w);
			idy.push_back(0);
			idy.push_back(h);
			for (int i = 0; i < fire.size(); ++i) {
				int x = xv[i], y = yv[i];
				--x, --y;
				if (x - M >= 0)
					idx.push_back(x - M);
				if (x + M + 1 <= w)
					idx.push_back(x + M + 1);
				if (y - M >= 0)
					idy.push_back(y - M);
				if (y + M + 1 <= h)
					idy.push_back(y + M + 1);
			}
			idx.doit(), idy.doit();
			int64 has = 0;
			for (int x = 0; x < idx.size() - 1; ++x) {
				int vx = idx[x];
				for (int y = 0; y < idy.size() - 1; ++y) {
					int vy = idy[y];
					bool chk = true;
					for (int k = 0; k < fire.size(); ++k) {
						int x = xv[k], y = yv[k];
						--x, --y;
						if (x - M <= vx && x + M >= vx && y - M <= vy && y + M >= vy) {
							chk = false;
							break;
						}
					}
					if (chk)
						has += 1LL * (idx[x + 1] - idx[x]) * (idy[y + 1] - idy[y]);
				}
			}
			cout << M << ":" << has << endl;
			if (has >= need)
				L = M;
			else
				R = M;
		}
		return L;
	}
};


double test0() {
	int p0 = 5;
	int p1 = 5;
	string p2 = "12";
	string t3[] = {"1 4","2 2"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	StrawberryFieldsOnFire * obj = new StrawberryFieldsOnFire();
	clock_t start = clock();
	int my_answer = obj->timeLimit(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 5;
	int p1 = 5;
	string p2 = "1";
	string t3[] = {"1 4","2 2"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	StrawberryFieldsOnFire * obj = new StrawberryFieldsOnFire();
	clock_t start = clock();
	int my_answer = obj->timeLimit(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 2;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 5;
	int p1 = 5;
	string p2 = "13";
	string t3[] = {"1 4","2 2"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	StrawberryFieldsOnFire * obj = new StrawberryFieldsOnFire();
	clock_t start = clock();
	int my_answer = obj->timeLimit(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 1000000000;
	int p1 = 1;
	string p2 = "1";
	string t3[] = {"1 1"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	StrawberryFieldsOnFire * obj = new StrawberryFieldsOnFire();
	clock_t start = clock();
	int my_answer = obj->timeLimit(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 999999998;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int p0 = 101;
	int p1 = 101;
	string p2 = "400";
	string t3[] = {"51 51"};
	vector <string> p3(t3, t3+sizeof(t3)/sizeof(string));
	StrawberryFieldsOnFire * obj = new StrawberryFieldsOnFire();
	clock_t start = clock();
	int my_answer = obj->timeLimit(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 49;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
