#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

class RestoreExpression {
	public:
	bool check(string A, string B, string C) {
		reverse(A.begin(), A.end());
		reverse(B.begin(), B.end());
		reverse(C.begin(), C.end());
		vector<bool> can(2, false);
		can[0] = true;
		int mx = max(A.size(), max(B.size(), C.size()));
		for (int i = 0; i < mx; ++i) {
			char ca = i < A.size() ? A[i] : '0';
			char cb = i < B.size() ? B[i] : '0';
			char cc = i < C.size() ? C[i] : '0';
			vector<bool> ncan(2, false);
			for (int carry = 0; carry < 2; ++carry) {
				if (!can[carry])
					continue;
				for (int a = 0; a < 10; ++a) {
					if (a == 0 && A.size() > 1 && i == A.size() - 1)
						continue;
					if ((ca - '0') == a || ca == '?') {
						for (int b = 0; b < 10; ++b) {
							if (b == 0 && B.size() > 1 && i == B.size() - 1)
								continue;
							if ((cb - '0') == b || cb == '?') {
								for (int c = 0; c < 10; ++c) {
									if (c == 0 && C.size() > 1 && i == C.size() - 1)
										continue;
									if ((cc - '0') == c || cc == '?') {
										int d = a + b + carry;
										if (d % 10 != c)
											continue;
										int ncarry = d / 10;
										ncan[ncarry] = true;
									}
								}
							}
						}
					}
				}
			}
			can = ncan;
		}
		return can[0];
	}

	string restore(string expression) {
		string A, B, C;
		replace(expression.begin(), expression.end(), '+', ' ');
		replace(expression.begin(), expression.end(), '=', ' ');
		cout << expression << endl;
		istringstream sin(expression);
		sin >> A >> B >> C;
		if (!check(A, B, C))
			return "no solution";

		{
			string&t = C;
			for (int i = 0; i < t.size(); ++i) {
				if (t[i] == '?') {
					for (int j = 10 - 1; j >= 0; --j) {
						t[i] = '0' + j;
						if (check(A, B, C))
							break;
					}
				}
			}
		}

		{
			string&t = A;
			for (int i = 0; i < t.size(); ++i) {
				if (t[i] == '?') {
					for (int j = 10 - 1; j >= 0; --j) {
						t[i] = '0' + j;
						if (check(A, B, C))
							break;
					}
				}
			}
		}

		{
			string&t = B;
			for (int i = 0; i < t.size(); ++i) {
				if (t[i] == '?') {
					for (int j = 10 - 1; j >= 0; --j) {
						t[i] = '0' + j;
						if (check(A, B, C))
							break;
					}
				}
			}
		}

		return A + "+" + B + "=" + C;
	}
}
;


double test0() {
	string p0 = "5+?=?4";
	RestoreExpression * obj = new RestoreExpression();
	clock_t start = clock();
	string my_answer = obj->restore(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "5+9=14";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	string p0 = "?+?=4";
	RestoreExpression * obj = new RestoreExpression();
	clock_t start = clock();
	string my_answer = obj->restore(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "4+0=4";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	string p0 = "?2+?2=4";
	RestoreExpression * obj = new RestoreExpression();
	clock_t start = clock();
	string my_answer = obj->restore(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "no solution";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	string p0 = "??+1=1?";
	RestoreExpression * obj = new RestoreExpression();
	clock_t start = clock();
	string my_answer = obj->restore(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "18+1=19";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	string p0 = "???+?=???0";
	RestoreExpression * obj = new RestoreExpression();
	clock_t start = clock();
	string my_answer = obj->restore(p0);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p1 = "999+1=1000";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p1 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p1 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
