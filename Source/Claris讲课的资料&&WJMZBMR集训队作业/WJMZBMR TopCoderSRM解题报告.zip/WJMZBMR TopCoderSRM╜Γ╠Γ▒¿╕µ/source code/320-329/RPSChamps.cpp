#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>

using namespace std;

class RPSChamps {
public:
	double numberOfMoves(int);
};

double RPSChamps::numberOfMoves(int N) {
	vector<vector<long double> > C(N + 1, vector<long double> (N + 1, 0));
	for (int i = 0; i <= N; ++i) {
		for (int j = 0; j <= i; ++j) {
			if (i == 0 && j == 0)
				C[i][j] = 1;
			else {
				if (j > 0)
					C[i][j] += C[i - 1][j - 1] / 3;
				C[i][j] += C[i - 1][j] / 3;
			}
		}
	}

	vector<long double> expectTime(N + 1, 0);
	expectTime[1] = 0;
	for (int nComp = 2; nComp <= N; ++nComp) {
		long double sum = 0;
		long double go = 0;
		for (int a = 1; a < nComp; ++a) {
			int b = nComp - a;
			long double prob = 3 * C[nComp][a];
			sum += prob * (expectTime[a] + expectTime[b]);
			go += prob;
		}
		expectTime[nComp] = (sum + 1) / go;
	}
	return expectTime[N];
}


//Powered by [KawigiEdit] 2.0!
