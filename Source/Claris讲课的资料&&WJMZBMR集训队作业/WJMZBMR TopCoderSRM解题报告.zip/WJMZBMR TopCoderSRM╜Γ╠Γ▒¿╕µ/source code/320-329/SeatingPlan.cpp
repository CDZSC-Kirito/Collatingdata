#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;
typedef long long int64;

int64 gcd(int64 a, int64 b) {
	return b ? gcd(b, a % b) : a;
}

class SeatingPlan {
	public:
	int64 comb[100][100];

	string expectedTrial(int m, int n, int k) {
		if (n < m)
			return expectedTrial(n, m, k);
		vector<vector<int64> > am(k + 1, vector<int64>(1 << m, 0));
		am[0][0] = 1;
		for (int r = 0; r < n; ++r) {
			for (int c = 0; c < m; ++c) {
				vector<vector<int64> > nam(k + 1, vector<int64>(1 << m, 0));
				for (int i = 0; i <= k; ++i) {
					for (int j = 0; j < (1 << m); ++j) {
						if (!am[i][j])
							continue;
						int64 v = am[i][j];
						nam[i][j & (~(1 << c))] += v;
						if ((j >> c & 1) || (c > 0 && (j >> (c - 1) & 1)))
							continue;
						if (i + 1 <= k)
							nam[i + 1][j | (1 << c)] += v;
					}
				}
				am = nam;
			}
		}

		int64 ret = accumulate(am[k].begin(), am[k].end(), 0LL);
		if (!ret)
			return "Impossible!";
		memset(comb, 0, sizeof comb);
		for (int i = 0; i < 100; ++i) {
			for (int j = 0; j <= i; ++j) {
				if (!i || !j)
					comb[i][j] = 1;
				else
					comb[i][j] = comb[i - 1][j] + comb[i - 1][j - 1];
			}
		}
		int64 total = comb[n * m][k];
		int64 g = gcd(ret, total);
		ret /= g, total /= g;
		ostringstream oss;
		oss << total << "/" << ret;
		return oss.str();
	}
};


double test0() {
	int p0 = 1;
	int p1 = 4;
	int p2 = 3;
	SeatingPlan * obj = new SeatingPlan();
	clock_t start = clock();
	string my_answer = obj->expectedTrial(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "Impossible!";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int p0 = 2;
	int p1 = 3;
	int p2 = 0;
	SeatingPlan * obj = new SeatingPlan();
	clock_t start = clock();
	string my_answer = obj->expectedTrial(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "1/1";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int p0 = 2;
	int p1 = 3;
	int p2 = 2;
	SeatingPlan * obj = new SeatingPlan();
	clock_t start = clock();
	string my_answer = obj->expectedTrial(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "15/8";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int p0 = 3;
	int p1 = 3;
	int p2 = 2;
	SeatingPlan * obj = new SeatingPlan();
	clock_t start = clock();
	string my_answer = obj->expectedTrial(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "3/2";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test4() {
	int p0 = 8;
	int p1 = 7;
	int p2 = 18;
	SeatingPlan * obj = new SeatingPlan();
	clock_t start = clock();
	string my_answer = obj->expectedTrial(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	string p3 = "70775996591300/172086661";
	cout <<"Desired answer: " <<endl;
	cout <<"\t\"" << p3 <<"\"" <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t\"" << my_answer<<"\"" <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	time = test4();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
