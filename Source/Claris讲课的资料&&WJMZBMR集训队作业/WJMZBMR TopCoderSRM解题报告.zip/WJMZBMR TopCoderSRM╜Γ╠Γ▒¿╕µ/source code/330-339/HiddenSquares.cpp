/*
 * HiddenSquares.cpp
 *
 *  Created on: 2011-10-31
 *      Author: mac
 */
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <iostream>
#include <climits>
#include <numeric>
#include <vector>
#include <map>
#define foreach(e,x) for(__typeof(x.begin()) e=x.begin();e!=x.end();++e)
#define REP(i,n) for(int i=0;i<n;++i)
using namespace std;

template<class T>
struct Index: public vector<T> {
	using vector<T>::erase;
	using vector<T>::begin;
	using vector<T>::end;
	void doit() {
		sort(begin(), end());
		erase(unique(begin(), end()), end());
	}
	int get(T x) {
		return lower_bound(begin(), end(), x) - begin();
	}
};

struct HiddenSquares {
	Index<int> idx, idy;
	bool up[102][102], right[102][102];
	int mxUp[102][102], mxRight[102][102];
	int mxDown[102][102], mxLeft[102][102];

	void addX(int x, int y1, int y2) {
		y1 = idy.get(y1), y2 = idy.get(y2);
		x = idx.get(x);
		for (int y = y1; y < y2; ++y) {
			up[x][y] = true;
		}
	}

	void addY(int y, int x1, int x2) {
		y = idy.get(y);
		x1 = idx.get(x1), x2 = idx.get(x2);
		for (int x = x1; x < x2; ++x) {
			right[x][y] = true;
		}
	}
	int count(vector<int> x1, vector<int> y1, vector<int> x2, vector<int> y2) {
		idx.insert(idx.end(), x1.begin(), x1.end());
		idx.insert(idx.end(), x2.begin(), x2.end());
		idx.doit();
		idy.insert(idy.end(), y1.begin(), y1.end());
		idy.insert(idy.end(), y2.begin(), y2.end());
		idy.doit();
		memset(up, false, sizeof up);
		memset(right, false, sizeof right);
		int n = x1.size();
		for (int i = 0; i < n; ++i) {
			addX(x1[i], y1[i], y2[i]);
			addX(x2[i], y1[i], y2[i]);
			addY(y1[i], x1[i], x2[i]);
			addY(y2[i], x1[i], x2[i]);
		}
		memset(mxUp, 0, sizeof mxUp);
		memset(mxRight, 0, sizeof mxRight);
		for (int i = idx.size() - 1; i >= 0; --i) {
			for (int j = idy.size() - 1; j >= 0; --j) {
				if (up[i][j])
					mxUp[i][j] = mxUp[i][j + 1] + idy[j + 1] - idy[j];
				if (right[i][j])
					mxRight[i][j] = mxRight[i + 1][j] + idx[i + 1] - idx[i];
			}
		}
		memset(mxDown, 0, sizeof mxDown);
		memset(mxLeft, 0, sizeof mxLeft);

		for (int i = 0; i < idx.size(); ++i) {
			for (int j = 0; j < idy.size(); ++j) {
				if (j > 0 && up[i][j - 1])
					mxDown[i][j] = mxDown[i][j - 1] + idy[j] - idy[j - 1];
				if (i > 0 && right[i - 1][j])
					mxLeft[i][j] = mxLeft[i - 1][j] + idx[i] - idx[i - 1];
			}
		}

		map<int, vector<pair<int, int> > > mp;
		for (int i = 0; i < idx.size(); ++i) {
			for (int j = 0; j < idy.size(); ++j) {
				int x = idx[i], y = idy[j];
				mp[x - y].push_back(make_pair(i, j));
			}
		}

		int ans = 0;
		for (map<int, vector<pair<int, int> > >::iterator it = mp.begin(); it != mp.end(); ++it) {
			vector<pair<int, int> > v = it->second;
			sort(v.begin(), v.end());
			for (int i = 0; i < v.size(); ++i) {
				int ix = v[i].first, iy = v[i].second;
				for (int j = i + 1; j < v.size(); ++j) {
					int jx = v[j].first, jy = v[j].second;
					int len = idx[jx] - idx[ix];
					if (mxUp[ix][iy] >= len && mxRight[ix][iy] >= len && mxDown[jx][jy] >= len && mxLeft[jx][jy] >= len)
						++ans;
				}
			}
		}

		return ans;
	}
};

double test0() {
	int t0[] = {0,1,0};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,0,1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {3,2,3};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {3,3,2};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	HiddenSquares * obj = new HiddenSquares();
	clock_t start = clock();
	int my_answer = obj->count(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 14;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {0,2};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,0};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {2,4};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {4,4};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	HiddenSquares * obj = new HiddenSquares();
	clock_t start = clock();
	int my_answer = obj->count(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 1;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {0,0,3};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {0,3,0};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {1,4,4};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {3,4,3};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	HiddenSquares * obj = new HiddenSquares();
	clock_t start = clock();
	int my_answer = obj->count(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {453453463,453453500,453453495,453453512,453453478,453453489,
 453453466,453453500,453453498,453453510,453453472,453453512,
 453453519,453453514,453453521,453453518,453453523,453453517,
 453453466,453453525,453453496,453453495,453453463,453453461,
 453453460,453453522,453453471,453453468,453453479,453453517,
 453453485,453453518,453453499,453453464,453453494};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {364646438,364646402,364646449,364646438,364646415,364646401,
 364646446,364646416,364646456,364646414,364646463,364646407,
 364646436,364646450,364646421,364646411,364646414,364646419,
 364646445,364646427,364646405,364646442,364646418,364646464,
 364646457,364646463,364646432,364646426,364646444,364646431,
 364646450,364646418,364646434,364646458,364646402};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int t2[] = {453453488,453453510,453453525,453453523,453453493,453453500,
 453453470,453453511,453453499,453453521,453453518,453453524,
 453453523,453453523,453453524,453453523,453453525,453453519,
 453453473,453453526,453453511,453453517,453453470,453453464,
 453453511,453453524,453453516,453453516,453453492,453453524,
453453513,453453522,453453520,453453505,453453512};
	vector <int> p2(t2, t2+sizeof(t2)/sizeof(int));
	int t3[] = {364646460,364646454,364646462,364646466,364646464,364646455,
 364646457,364646461,364646457,364646450,364646466,364646453,
 364646441,364646451,364646460,364646461,364646446,364646464,
 364646447,364646460,364646454,364646450,364646444,364646466,
 364646458,364646466,364646455,364646442,364646462,364646435,
 364646464,364646444,364646455,364646459,364646430};
	vector <int> p3(t3, t3+sizeof(t3)/sizeof(int));
	HiddenSquares * obj = new HiddenSquares();
	clock_t start = clock();
	int my_answer = obj->count(p0, p1, p2, p3);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	int p4 = 124;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p4 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p4 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
