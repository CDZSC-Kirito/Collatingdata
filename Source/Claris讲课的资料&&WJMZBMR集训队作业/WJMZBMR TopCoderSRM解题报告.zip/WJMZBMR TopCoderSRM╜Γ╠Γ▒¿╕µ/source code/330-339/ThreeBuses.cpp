#include <vector>
#include <list>
#include <map>
#include <set>
#include <deque>
#include <stack>
#include <bitset>
#include <algorithm>
#include <functional>
#include <numeric>
#include <utility>
#include <sstream>
#include <iostream>
#include <iomanip>
#include <cstdio>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <cstring>
#define REP(i,n) for(int i=0;i<n;i++)
#define TR(e,x) for(typeof(x.begin()) e=x.begin();e!=x.end();++e)
using namespace std;

typedef long long int64;

class ThreeBuses {
	public:

	double getProbability(vector<int> wait, vector<int> travel, int timeLeft) {
		for (vector<int>::iterator e = travel.begin(); e != travel.end(); ++e) {
			timeLeft -= *e;
		}
		if (timeLeft < 0)
			return 0;

		vector<int> w;
		for (vector<int>::iterator e = wait.begin(); e != wait.end(); ++e) {
			if (*e > 0)
				w.push_back(*e);
		}
		if (w.empty())
			return 1;

		int64 total = accumulate(w.begin(), w.end(), 1LL, multiplies<int64>());
		for (int i = 1; i <= w.size(); ++i) {
			total *= i;
		}
		int64 area = 0;
		for (int mask = 0; mask < (1 << w.size()); ++mask) {
			int T = timeLeft, cnt = 0;
			for (int i = 0; i < w.size(); ++i) {
				if (mask >> i & 1)
					T -= w[i], ++cnt;
			}
			if (T <= 0)
				continue;
			int64 cur = 1;
			for (int k = 0; k < w.size(); ++k) {
				cur *= T;
			}
			if (cnt % 2 == 0)
				area += cur;
			else
				area -= cur;
		}
		return 1.0 * area / total;
	}
};


double test0() {
	int t0[] = {0, 0, 0};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {10, 15, 10};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 47;
	ThreeBuses * obj = new ThreeBuses();
	clock_t start = clock();
	double my_answer = obj->getProbability(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test1() {
	int t0[] = {0, 0, 0};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {10, 15, 10};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 35;
	ThreeBuses * obj = new ThreeBuses();
	clock_t start = clock();
	double my_answer = obj->getProbability(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 1.0;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test2() {
	int t0[] = {1, 100, 1};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {10, 10, 10};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 52;
	ThreeBuses * obj = new ThreeBuses();
	clock_t start = clock();
	double my_answer = obj->getProbability(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.21;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}
double test3() {
	int t0[] = {100, 100, 70};
	vector <int> p0(t0, t0+sizeof(t0)/sizeof(int));
	int t1[] = {1, 1, 1};
	vector <int> p1(t1, t1+sizeof(t1)/sizeof(int));
	int p2 = 47;
	ThreeBuses * obj = new ThreeBuses();
	clock_t start = clock();
	double my_answer = obj->getProbability(p0, p1, p2);
	clock_t end = clock();
	delete obj;
	cout <<"Time: " <<(double)(end-start)/CLOCKS_PER_SEC <<" seconds" <<endl;
	double p3 = 0.020281904761904737;
	cout <<"Desired answer: " <<endl;
	cout <<"\t" << p3 <<endl;
	cout <<"Your answer: " <<endl;
	cout <<"\t" << my_answer <<endl;
	if (p3 != my_answer) {
		cout <<"DOESN'T MATCH!!!!" <<endl <<endl;
		return -1;
	}
	else {
		cout <<"Match :-)" <<endl <<endl;
		return (double)(end-start)/CLOCKS_PER_SEC;
	}
}

int main() {
	int time;
	bool errors = false;
	
	time = test0();
	if (time < 0)
		errors = true;
	
	time = test1();
	if (time < 0)
		errors = true;
	
	time = test2();
	if (time < 0)
		errors = true;
	
	time = test3();
	if (time < 0)
		errors = true;
	
	if (!errors)
		cout <<"You're a stud (at least on the example cases)!" <<endl;
	else
		cout <<"Some of the test cases had errors." <<endl;
}

//Powered by [KawigiEdit] 2.0!
